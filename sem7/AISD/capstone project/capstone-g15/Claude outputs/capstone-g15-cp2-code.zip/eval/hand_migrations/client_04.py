"""Shop checkout."""
from libv.v2 import Money, charge, make_receipt


def checkout(account_id, cart):
    """cart is a list of (unit_price, quantity) pairs."""
    total = sum(price * qty for price, qty in cart)
    tx = charge(account_id, Money(total, "INR"))
    return make_receipt(tx)
