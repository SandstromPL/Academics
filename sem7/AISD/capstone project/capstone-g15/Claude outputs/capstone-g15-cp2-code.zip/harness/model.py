"""One function for every model call: call_model(messages, model) -> dict.

Talks to the course gateway's OpenAI-compatible /chat/completions endpoint with
your OWN key. Env vars (same ones aider uses):
    OPENAI_API_BASE  (or OPENAI_BASE_URL)  e.g. https://<gateway>/v1
    OPENAI_API_KEY
If your lab-07a code has its own gateway helper, you can call it here instead;
keep the return shape the same.
"""
import json
import os
import time
import urllib.error
import urllib.request

DEFAULT_TIMEOUT = 60
RETRIES = 2


def _base():
    base = os.environ.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")
    if not base:
        raise RuntimeError("set OPENAI_API_BASE to the gateway URL (the one aider uses)")
    base = base.rstrip("/")
    return base if base.endswith("/v1") else base + "/v1"


def call_model(messages, model="main", max_tokens=1500, temperature=0.0, timeout=DEFAULT_TIMEOUT):
    """Returns {"text", "prompt_tokens", "completion_tokens", "latency_ms", "model", "attempts"}."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("set OPENAI_API_KEY to your own gateway key")
    body = json.dumps({"model": model, "messages": messages,
                       "max_tokens": max_tokens, "temperature": temperature}).encode()
    last_err = None
    for attempt in range(1, RETRIES + 2):
        req = urllib.request.Request(_base() + "/chat/completions", data=body, method="POST",
                                     headers={"Content-Type": "application/json",
                                              "Authorization": f"Bearer {key}"})
        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read().decode())
            usage = data.get("usage") or {}
            return {
                "text": data["choices"][0]["message"].get("content") or "",
                "prompt_tokens": int(usage.get("prompt_tokens", 0)),
                "completion_tokens": int(usage.get("completion_tokens", 0)),
                "latency_ms": int((time.time() - t0) * 1000),
                "model": data.get("model", model),
                "attempts": attempt,
            }
        except (urllib.error.URLError, TimeoutError, KeyError, ValueError) as e:
            last_err = e
            code = getattr(e, "code", None)
            if code is not None and code < 500 and code != 429:
                break  # 4xx other than rate limit: retrying will not help
            time.sleep(2 * attempt)
    raise RuntimeError(f"model call failed after retries: {last_err}")
