# libv v1 -> v2 breaking changes (Day 0 design)

One change per guide section. "Inferable" = can a model guess it from v2 signatures alone?

| ID | Kind | v1 | v2 | Inferable from signatures? |
|---|---|---|---|---|
| G01 | renamed function | `get_balance(account_id)` | `fetch_balance(account_id)` | partly (name guess) |
| G02 | argument order | `transfer(amount, from_id, to_id)` | `transfer(from_id, to_id, amount)` | yes, if it reads param names |
| G03 | return type -> dataclass | `get_transaction()` -> dict, key `id` | -> `Transaction`, attribute `tx_id` | partly (`id` -> `tx_id`) |
| G04 | removed function | `charge_and_receipt(acc, amount)` | `make_receipt(charge(acc, Money(amount, "INR")))` | partly |
| G05 | renamed exception | `InsufficientFunds` | `BalanceTooLow` | no (mapping) |
| G06 | renamed exception | `AccountNotFound` | `UnknownAccount` | no (mapping) |
| G07 | argument -> value object | `charge(acc, amount, currency="INR")` -> dict | `charge(acc, Money)` -> `Transaction` | partly |
| G08 | unit change | `format_amount(rupees: float)` | `format_amount(value: int)` in paise | no |
| G09 | removed default | `list_transactions(acc, limit=10)` | `list_transactions(acc, limit)`, items `Transaction` | yes |
| G10 | keyword-only + renamed param | `open_account(name, balance=0.0)` | `open_account(name, *, opening_balance=0.0)` | yes |
| G11 | value object in/out | `convert(amount, to_currency)` -> float | `convert(Money, to)` -> `Money` | partly |
| G12 | renamed base exception | `PaymentError` | `PayError` | partly |

Unchanged in both: `reset()`, `withdraw(account_id, amount)`, `RATES`.
