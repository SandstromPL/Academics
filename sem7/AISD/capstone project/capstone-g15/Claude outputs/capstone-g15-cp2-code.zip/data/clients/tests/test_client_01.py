import pytest
from libv import v2

import client_01


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_balance_line():
    a = v2.open_account("asha", opening_balance=250.0)
    assert client_01.balance_line(a) == f"{a}: 250.00"


def test_is_low():
    rich = v2.open_account("r", opening_balance=500.0)
    poor = v2.open_account("p", opening_balance=20.0)
    assert client_01.is_low(rich) is False
    assert client_01.is_low(poor) is True
