"""Shop checkout."""
from libv.v1 import charge_and_receipt


def checkout(account_id, cart):
    """cart is a list of (unit_price, quantity) pairs."""
    total = sum(price * qty for price, qty in cart)
    return charge_and_receipt(account_id, total)
