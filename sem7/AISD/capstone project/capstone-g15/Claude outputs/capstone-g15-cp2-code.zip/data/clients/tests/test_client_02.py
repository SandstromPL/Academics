import pytest
from libv import v2

import client_02


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_pay_rent_moves_money_tenant_to_landlord():
    tenant = v2.open_account("t", opening_balance=1000.0)
    landlord = v2.open_account("l")
    assert client_02.pay_rent(tenant, landlord, 600.0) is True
    assert v2.fetch_balance(tenant) == 400.0
    assert v2.fetch_balance(landlord) == 600.0


def test_split_bill():
    payer = v2.open_account("p")
    f1 = v2.open_account("f1", opening_balance=100.0)
    f2 = v2.open_account("f2", opening_balance=100.0)
    assert client_02.split_bill(payer, [f1, f2], 90.0) == 30.0
    assert v2.fetch_balance(payer) == 60.0
    assert v2.fetch_balance(f1) == 70.0
