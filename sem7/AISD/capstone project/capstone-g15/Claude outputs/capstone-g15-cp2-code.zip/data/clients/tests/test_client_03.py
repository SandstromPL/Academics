import pytest
from libv import v2

import client_03


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def _tx(amount):
    a = v2.open_account("a", opening_balance=5000.0)
    return v2.charge(a, v2.Money(amount, "INR")).tx_id


def test_tx_summary():
    t = _tx(1500.0)
    assert client_03.tx_summary(t) == f"{t} ok 1500.00"


def test_is_large():
    assert client_03.is_large(_tx(1500.0)) is True
    assert client_03.is_large(_tx(10.0)) is False
