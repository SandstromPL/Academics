import pytest
from libv import v2

import client_05


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_sweep_keeps_floor():
    cur = v2.open_account("cur", opening_balance=800.0)
    sav = v2.open_account("sav")
    assert client_05.sweep(cur, sav, keep=300.0) == 500.0
    assert v2.fetch_balance(cur) == 300.0
    assert v2.fetch_balance(sav) == 500.0


def test_sweep_nothing_to_move():
    cur = v2.open_account("cur", opening_balance=100.0)
    sav = v2.open_account("sav")
    assert client_05.sweep(cur, sav, keep=300.0) == -200.0
    assert v2.fetch_balance(sav) == 0.0


def test_tx_amount_and_ref():
    a = v2.open_account("a", opening_balance=100.0)
    tx = v2.charge(a, v2.Money(42.0))
    assert client_05.tx_amount(tx.tx_id) == 42.0
    assert client_05.tx_ref(tx.tx_id) == "REF-" + tx.tx_id
