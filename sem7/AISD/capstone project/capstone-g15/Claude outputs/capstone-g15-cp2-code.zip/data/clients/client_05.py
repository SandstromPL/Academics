"""Treasury sweep: move spare balance to savings and report."""
from libv.v1 import get_balance, get_transaction, transfer


def sweep(from_id, to_id, keep=0.0):
    amount = get_balance(from_id) - keep
    if amount > 0:
        transfer(amount, from_id, to_id)
    return amount


def tx_amount(tx_id):
    return get_transaction(tx_id)["amount"]


def tx_ref(tx_id):
    return "REF-" + get_transaction(tx_id)["id"]
