import pytest
from libv import v2

import client_06


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_withdraw_ok():
    a = v2.open_account("a", opening_balance=500.0)
    assert client_06.atm_withdraw(a, 200.0) == "Cash dispensed"
    assert v2.fetch_balance(a) == 300.0


def test_withdraw_declined_label_unchanged():
    a = v2.open_account("a", opening_balance=50.0)
    assert client_06.atm_withdraw(a, 200.0) == "Balance check failed"


def test_labels_and_help_text_untouched():
    assert set(client_06.LABELS) == {"get_balance", "withdraw"}
    assert client_06.legacy_call_example == "get_balance(acct)"
