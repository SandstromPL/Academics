import os
import sys

# data/ (for "import libv") and data/clients/ (for "import client_NN") go on sys.path
HERE = os.path.dirname(os.path.abspath(__file__))
for p in (os.path.join(HERE, "..", ".."), os.path.join(HERE, "..")):
    p = os.path.abspath(p)
    if p not in sys.path:
        sys.path.insert(0, p)
