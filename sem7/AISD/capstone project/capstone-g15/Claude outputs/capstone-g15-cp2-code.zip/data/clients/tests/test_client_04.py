import pytest
from libv import v2

import client_04


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_checkout_receipt_and_balance():
    a = v2.open_account("a", opening_balance=100.0)
    receipt = client_04.checkout(a, [(20.0, 2), (15.0, 2)])
    assert receipt.startswith("RECEIPT tx_")
    assert receipt.endswith(" INR 70.00")
    assert v2.fetch_balance(a) == 30.0
    assert len(v2.list_transactions(a, 10)) == 1
