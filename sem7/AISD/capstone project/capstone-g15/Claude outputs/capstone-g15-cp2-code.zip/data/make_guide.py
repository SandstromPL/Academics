"""Writes data/guide.json: one section per v1 -> v2 breaking change.

Run: python data/make_guide.py   (hand-written content, script only serialises it)
"""
import json
import os

SECTIONS = [
    ("G01", "get_balance() renamed to fetch_balance()",
     "v1 get_balance(account_id) is renamed to fetch_balance(account_id) in v2. "
     "Arguments and the return value (balance in rupees, float) are unchanged. "
     "Replace every call and every import of get_balance with fetch_balance.",
     "from libv.v1 import get_balance\nbal = get_balance(acc)",
     "from libv.v2 import fetch_balance\nbal = fetch_balance(acc)"),
    ("G02", "transfer() argument order is now (from_id, to_id, amount)",
     "v1 transfer(amount, from_id, to_id) took the amount first. v2 transfer(from_id, to_id, amount) "
     "takes the source account, then the destination account, then the amount. The function name is "
     "the same, so old calls fail with UnknownAccount at run time. Reorder the arguments of every transfer call.",
     "transfer(500.0, src, dst)",
     "transfer(src, dst, 500.0)"),
    ("G03", "get_transaction() returns a Transaction dataclass, not a dict",
     "v1 get_transaction(tx_id) returned a dict with keys 'id', 'account_id', 'amount', 'currency', 'status'. "
     "v2 returns a frozen Transaction dataclass. Use attributes, not subscripts: tx['amount'] becomes tx.amount, "
     "tx['status'] becomes tx.status, and the 'id' key is now the attribute tx.tx_id (renamed).",
     "tx = get_transaction(t)\nprint(tx['id'], tx['amount'])",
     "tx = get_transaction(t)\nprint(tx.tx_id, tx.amount)"),
    ("G04", "charge_and_receipt() removed: call charge() then make_receipt()",
     "v1 charge_and_receipt(account_id, amount) is removed. In v2 do it in two calls: "
     "tx = charge(account_id, Money(amount, 'INR')) and then make_receipt(tx). make_receipt returns the "
     "same 'RECEIPT <tx_id> INR <amount>' string. Import Money, charge and make_receipt from libv.v2.",
     "receipt = charge_and_receipt(acc, 70.0)",
     "tx = charge(acc, Money(70.0, \"INR\"))\nreceipt = make_receipt(tx)"),
    ("G05", "Exception InsufficientFunds renamed to BalanceTooLow",
     "v1 raised InsufficientFunds when a withdraw, transfer or charge needed more money than the balance. "
     "v2 raises BalanceTooLow instead. InsufficientFunds does not exist in v2: update except clauses, "
     "raise statements and imports. Behaviour is otherwise identical.",
     "except InsufficientFunds:\n    return 'declined'",
     "except BalanceTooLow:\n    return 'declined'"),
    ("G06", "Exception AccountNotFound renamed to UnknownAccount",
     "v1 raised AccountNotFound for an account id that does not exist. v2 raises UnknownAccount. "
     "AccountNotFound does not exist in v2: rename it in except clauses and imports.",
     "except AccountNotFound:\n    return None",
     "except UnknownAccount:\n    return None"),
    ("G07", "charge() takes Money, not amount and currency",
     "v1 charge(account_id, amount, currency='INR') is replaced by v2 charge(account_id, money) where money "
     "is Money(amount, currency). The currency argument is removed; pass Money(12.5, 'INR'). charge now returns "
     "a Transaction dataclass instead of a dict (see the get_transaction section).",
     "tx = charge(acc, 12.5, \"INR\")\ntx_id = tx['id']",
     "tx = charge(acc, Money(12.5, \"INR\"))\ntx_id = tx.tx_id"),
    ("G08", "format_amount() takes integer paise, not rupees",
     "Unit change. v1 format_amount(rupees) took a float in rupees. v2 format_amount(value) takes an int in "
     "paise (1 rupee = 100 paise) and raises TypeError on a float. Convert first: "
     "format_amount(round(rupees * 100)). The output string 'INR 12.50' is unchanged.",
     "format_amount(12.5)",
     "format_amount(round(12.5 * 100))"),
    ("G09", "list_transactions() limit is required, items are Transaction",
     "v1 list_transactions(account_id, limit=10) had a default limit. v2 list_transactions(account_id, limit) "
     "has no default: pass limit=10 to keep the old behaviour. Each item is a Transaction dataclass, so use "
     "t.amount instead of t['amount'].",
     "rows = list_transactions(acc)\ntotal = sum(r['amount'] for r in rows)",
     "rows = list_transactions(acc, limit=10)\ntotal = sum(r.amount for r in rows)"),
    ("G10", "open_account() opening_balance is keyword-only",
     "v1 open_account(name, balance=0.0) accepted the balance positionally. v2 open_account(name, *, "
     "opening_balance=0.0) renames the parameter and makes it keyword-only; a positional balance raises TypeError.",
     "acc = open_account(\"asha\", 500.0)",
     "acc = open_account(\"asha\", opening_balance=500.0)"),
    ("G11", "convert() takes and returns Money",
     "v1 convert(amount, to_currency) took rupees and returned a float. v2 convert(money, to) takes a Money "
     "and returns a new Money in the target currency. Read the number with .amount.",
     "usd = convert(1000.0, \"USD\")",
     "usd = convert(Money(1000.0, \"INR\"), \"USD\").amount"),
    ("G12", "Base exception PaymentError renamed to PayError",
     "v1's base class for all library errors was PaymentError. v2 renames it PayError; BalanceTooLow and "
     "UnknownAccount subclass it. Catch-all handlers must use except PayError.",
     "except PaymentError as e:\n    log(e)",
     "except PayError as e:\n    log(e)"),
]


def main():
    out = [dict(zip(("id", "title", "text", "before", "after"), s)) for s in SECTIONS]
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "guide.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=2)
        f.write("\n")
    print(f"wrote {len(out)} sections to {path}")


if __name__ == "__main__":
    main()
