"""libv v1 -- DEPRECATED tiny payments API.

All amounts are rupees as float. State is in memory; call reset() in tests.
"""

RATES = {"INR": 1.0, "USD": 0.012, "EUR": 0.011}

_accounts = {}   # account_id -> balance in rupees (float)
_txs = {}        # tx_id -> dict
_counter = [0]


class PaymentError(Exception):
    """Base class for every libv v1 error."""


class InsufficientFunds(PaymentError):
    """Balance too small for the debit."""


class AccountNotFound(PaymentError):
    """No account with that id."""


def _next(prefix):
    _counter[0] += 1
    return f"{prefix}_{_counter[0]}"


def _acct(account_id):
    if account_id not in _accounts:
        raise AccountNotFound(account_id)
    return _accounts[account_id]


def _debit(account_id, amount):
    if _acct(account_id) < amount:
        raise InsufficientFunds(account_id)
    _accounts[account_id] -= amount


def reset():
    _accounts.clear()
    _txs.clear()
    _counter[0] = 0


def open_account(name, balance=0.0):
    account_id = _next("acc")
    _accounts[account_id] = float(balance)
    return account_id


def get_balance(account_id):
    return _acct(account_id)


def withdraw(account_id, amount):
    _debit(account_id, amount)
    return _accounts[account_id]


def transfer(amount, from_id, to_id):
    _acct(to_id)
    _debit(from_id, amount)
    _accounts[to_id] += amount
    return True


def charge(account_id, amount, currency="INR"):
    if currency != "INR":
        raise PaymentError("only INR charges are supported")
    _debit(account_id, amount)
    tx_id = _next("tx")
    _txs[tx_id] = {"id": tx_id, "account_id": account_id, "amount": float(amount),
                   "currency": currency, "status": "ok"}
    return dict(_txs[tx_id])


def charge_and_receipt(account_id, amount):
    tx = charge(account_id, amount)
    return f"RECEIPT {tx['id']} {format_amount(tx['amount'])}"


def get_transaction(tx_id):
    if tx_id not in _txs:
        raise PaymentError(f"no transaction {tx_id}")
    return dict(_txs[tx_id])


def list_transactions(account_id, limit=10):
    _acct(account_id)
    rows = [dict(t) for t in _txs.values() if t["account_id"] == account_id]
    return rows[-limit:]


def convert(amount, to_currency):
    return round(amount * RATES[to_currency], 2)


def format_amount(rupees):
    return f"INR {rupees:.2f}"
