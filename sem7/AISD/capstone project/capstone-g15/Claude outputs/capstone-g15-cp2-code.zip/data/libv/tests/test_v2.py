import pytest

from libv import v2


@pytest.fixture(autouse=True)
def clean():
    v2.reset()


def test_open_and_fetch_balance():
    a = v2.open_account("asha", opening_balance=500.0)
    assert v2.fetch_balance(a) == 500.0


def test_open_account_is_keyword_only():
    with pytest.raises(TypeError):
        v2.open_account("asha", 500.0)


def test_transfer_from_to_amount():
    a = v2.open_account("a", opening_balance=100.0)
    b = v2.open_account("b")
    assert v2.transfer(a, b, 40.0) is True
    assert v2.fetch_balance(a) == 60.0
    assert v2.fetch_balance(b) == 40.0


def test_transfer_too_much_raises_balance_too_low():
    a = v2.open_account("a", opening_balance=10.0)
    b = v2.open_account("b")
    with pytest.raises(v2.BalanceTooLow):
        v2.transfer(a, b, 50.0)


def test_unknown_account():
    with pytest.raises(v2.UnknownAccount):
        v2.fetch_balance("acc_999")


def test_errors_share_base_payerror():
    assert issubclass(v2.BalanceTooLow, v2.PayError)
    assert issubclass(v2.UnknownAccount, v2.PayError)


def test_charge_takes_money_and_returns_transaction():
    a = v2.open_account("a", opening_balance=100.0)
    tx = v2.charge(a, v2.Money(12.5, "INR"))
    assert isinstance(tx, v2.Transaction)
    assert tx.amount == 12.5 and tx.status == "ok"
    assert v2.fetch_balance(a) == 87.5
    with pytest.raises(TypeError):
        v2.charge(a, 12.5)


def test_get_transaction_is_dataclass():
    a = v2.open_account("a", opening_balance=100.0)
    tx = v2.charge(a, v2.Money(30.0))
    got = v2.get_transaction(tx.tx_id)
    assert got.tx_id == tx.tx_id and got.amount == 30.0


def test_make_receipt():
    a = v2.open_account("a", opening_balance=100.0)
    tx = v2.charge(a, v2.Money(12.5))
    assert v2.make_receipt(tx) == f"RECEIPT {tx.tx_id} INR 12.50"


def test_list_transactions_needs_limit():
    a = v2.open_account("a", opening_balance=100.0)
    for _ in range(3):
        v2.charge(a, v2.Money(1.0))
    assert len(v2.list_transactions(a, 2)) == 2
    with pytest.raises(TypeError):
        v2.list_transactions(a)


def test_convert_money():
    assert v2.convert(v2.Money(1000.0), "USD") == v2.Money(12.0, "USD")


def test_format_amount_takes_paise():
    assert v2.format_amount(1250) == "INR 12.50"
    with pytest.raises(TypeError):
        v2.format_amount(12.5)
