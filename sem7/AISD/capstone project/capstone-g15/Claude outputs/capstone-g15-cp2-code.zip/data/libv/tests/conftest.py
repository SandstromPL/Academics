import os
import sys

# make "import libv" work: data/ goes on sys.path
DATA = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if DATA not in sys.path:
    sys.path.insert(0, DATA)
