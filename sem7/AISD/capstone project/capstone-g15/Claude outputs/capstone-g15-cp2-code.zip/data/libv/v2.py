"""libv v2 -- tiny payments API.

Account balances and transaction amounts are rupees (float).
Display helpers (format_amount) take integer paise.
State is in memory; call reset() in tests.
"""
from dataclasses import dataclass

RATES = {"INR": 1.0, "USD": 0.012, "EUR": 0.011}

_accounts = {}   # account_id -> balance in rupees (float)
_txs = {}        # tx_id -> Transaction
_counter = [0]


class PayError(Exception):
    """Base class for every libv v2 error."""


class BalanceTooLow(PayError):
    """Balance too small for the debit."""


class UnknownAccount(PayError):
    """No account with that id."""


@dataclass(frozen=True)
class Money:
    amount: float
    currency: str = "INR"


@dataclass(frozen=True)
class Transaction:
    tx_id: str
    account_id: str
    amount: float
    currency: str
    status: str


def _next(prefix):
    _counter[0] += 1
    return f"{prefix}_{_counter[0]}"


def _acct(account_id):
    if account_id not in _accounts:
        raise UnknownAccount(account_id)
    return _accounts[account_id]


def _debit(account_id, amount):
    if _acct(account_id) < amount:
        raise BalanceTooLow(account_id)
    _accounts[account_id] -= amount


def reset():
    _accounts.clear()
    _txs.clear()
    _counter[0] = 0


def open_account(name: str, *, opening_balance: float = 0.0) -> str:
    account_id = _next("acc")
    _accounts[account_id] = float(opening_balance)
    return account_id


def fetch_balance(account_id: str) -> float:
    return _acct(account_id)


def withdraw(account_id: str, amount: float) -> float:
    _debit(account_id, amount)
    return _accounts[account_id]


def transfer(from_id: str, to_id: str, amount: float) -> bool:
    _acct(to_id)
    _debit(from_id, amount)
    _accounts[to_id] += amount
    return True


def charge(account_id: str, money: Money) -> Transaction:
    if not isinstance(money, Money):
        raise TypeError("charge() takes a Money, not a number")
    if money.currency != "INR":
        raise PayError("only INR charges are supported")
    _debit(account_id, money.amount)
    tx = Transaction(_next("tx"), account_id, float(money.amount), money.currency, "ok")
    _txs[tx.tx_id] = tx
    return tx


def make_receipt(tx: Transaction) -> str:
    return f"RECEIPT {tx.tx_id} {format_amount(round(tx.amount * 100))}"


def get_transaction(tx_id: str) -> Transaction:
    if tx_id not in _txs:
        raise PayError(f"no transaction {tx_id}")
    return _txs[tx_id]


def list_transactions(account_id: str, limit: int) -> list:
    _acct(account_id)
    rows = [t for t in _txs.values() if t.account_id == account_id]
    return rows[-limit:]


def convert(money: Money, to: str) -> Money:
    return Money(round(money.amount * RATES[to], 2), to)


def format_amount(value: int) -> str:
    if not isinstance(value, int):
        raise TypeError("format_amount() takes integer paise")
    return f"INR {value // 100}.{value % 100:02d}"
