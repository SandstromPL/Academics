"""Validates data/guide.json. Exit code 0 = valid.  Run: python data/validate_guide.py"""
import json
import os
import re
import sys

KEYS = {"id", "title", "text", "before", "after"}
MAX_TEXT = 600


def validate(path):
    errors = []
    sections = json.load(open(path))
    if not 12 <= len(sections) <= 20:
        errors.append(f"expected 12-20 sections, found {len(sections)}")
    seen = set()
    for i, s in enumerate(sections):
        if set(s) != KEYS:
            errors.append(f"section {i}: keys {sorted(s)} != {sorted(KEYS)}")
            continue
        if not re.fullmatch(r"G\d{2}", s["id"]):
            errors.append(f"section {i}: bad id {s['id']!r}")
        if s["id"] in seen:
            errors.append(f"duplicate id {s['id']}")
        seen.add(s["id"])
        if len(s["text"]) > MAX_TEXT:
            errors.append(f"{s['id']}: text is {len(s['text'])} chars (max {MAX_TEXT})")
        for k in KEYS:
            if not str(s[k]).strip():
                errors.append(f"{s['id']}: empty {k}")
    return sections, errors


if __name__ == "__main__":
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "guide.json")
    sections, errors = validate(p)
    for e in errors:
        print("ERROR", e)
    print(f"{len(sections)} sections, {len(errors)} errors")
    sys.exit(1 if errors else 0)
