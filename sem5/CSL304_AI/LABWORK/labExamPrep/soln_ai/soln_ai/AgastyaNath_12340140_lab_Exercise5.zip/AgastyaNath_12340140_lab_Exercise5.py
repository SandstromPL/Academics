import matplotlib.pyplot as plt
import networkx as nx
from queue import Queue

variables = [
    "AP","AR","AS","BR","CG","GA","GJ","HR","HP","JH",
    "KA","KL","MP","MH","MN","ML","MZ","NL","OD","PB",
    "RJ","SK","TN","TS","TR","UP","UK","WB","JK"
]
colors = ['Red','Green','Blue','Yellow']

neighbors = {
"AP": ["TS","OD","TN","KA"],
"AR": ["AS","NL"],
"AS": ["AR","NL","ML","TR","MZ","MN","WB"],
"BR": ["UP","JH","WB"],
"CG": ["UP","JH","OD","MH"],
"GA": ["MH","KA"],
"GJ": ["MH","RJ"],
"HR": ["PB","HP","UK","RJ"],
"HP": ["JK","PB","HR","UK"],
"JH": ["BR","UP","CG","OD","WB"],
"KA": ["MH","AP","TS","TN","KL","GA"],
"KL": ["KA","TN"],
"MP": ["RJ","UP","CG","MH","GJ"],
"MH": ["GJ","MP","CG","TS","KA","GA"],
"MN": ["AS","MZ","NL"],
"ML": ["AS","TR"],
"MZ": ["AS","MN","TR"],
"NL": ["AR","AS","MN"],
"OD": ["WB","JH","CG","AP","TS"],
"PB": ["JK","HP","HR","RJ"],
"RJ": ["PB","HR","MP","GJ","UP"],
"SK": ["WB"],
"TN": ["AP","KA","KL"],
"TS": ["MH","KA","AP","OD"],
"TR": ["AS","ML","MZ"],
"UP": ["UK","HR","RJ","MP","CG","JH","BR"],
"UK": ["HP","HR","UP"],
"WB": ["BR","JH","OD","AS","SK"],
"JK": ["HP","PB"]
}


def is_valid(assignment, var, value):
    for n in neighbors[var]:
        if n in assignment and assignment[n] == value:
            return False
    return True

def visualize_coloring(solution, title):
    G = nx.Graph()

    for var in variables:
        G.add_node(var)
    for var, neighs in neighbors.items():
        for n in neighs:
            G.add_edge(var, n)

def select_unassigned_var(assignment):
    unassigned = [v for v in variables if v not in assignment]
    return min(unassigned, key=lambda var: sum(is_valid(assignment, var, c) for c in colors))

def order_domain_values(var, assignment):
    def conflicts(val):
        return sum(1 for n in neighbors[var] if n not in assignment and not is_valid({**assignment, var: val}, n, val))
    return sorted(colors, key=conflicts)

heuristic_steps = 0

def remove_inconsistent_values(elem, domain, neighbors):
    removed = False
    for x in domain[elem[0]]:
        for y in domain[elem[1]]:
            if x == y:
                domain[elem[0]].remove(x)
                removed = True
    return removed

domain_vars = {}
for i in variables:
    domain_vars[i] = colors


def ac_3(domain, variables, neighbors):
    q = Queue(maxsize=10)
    while not q.empty():
        elem = q.get()
        if remove_inconsistent_values(elem, domain, neighbors):
            for x_k in neighbors[elem[0]]:
                q.put((x_k, elem[0]))

def backtract_heuristic(assignment, variables, neighbors, domain_vars):
    global heuristic_steps
    heuristic_steps += 1

    if len(assignment) == len(variables):
        return assignment

    var = select_unassigned_var(assignment)

    ac_3(domain_vars, variables, neighbors)
    
    for value in order_domain_values(var, assignment):
        if value in domain_vars[var] and is_valid(assignment, var, value):
            assignment[var] = value
            temp = domain_vars[var]
            domain_vars[var] = [value]
            ac_3(domain_vars, variables, neighbors)
            result = backtract_heuristic(assignment, variables, neighbors, domain_vars)
            if result:
                return result
            del assignment[var]
            domain_vars[var] = temp

    return None

if __name__ == "__main__":
    heuristic_solution = backtract_heuristic({}, variables, neighbors, domain_vars)
    print("Backtracking with MRV + LCV + AC-3 Solution: ",  heuristic_solution)
    print("Backtracking with MRV + LCV + AC-3 Steps: ",  heuristic_steps)
    visualize_coloring(heuristic_solution, f"MRV + LCV + Ac-3 Heuristic ({heuristic_steps} steps)")
