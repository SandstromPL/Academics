import math
import heapq


class TaxiRouting:
    def __init__(self, n, m, p, w, s, coords, edges, trips):
        self.n = n
        self.m = m
        self.p = p
        self.w = w
        self.s = s
        self.coords = coords
        self.graph = {i: [] for i in range(1, n + 1)}
        for u, v, d in edges:
            self.graph[u].append((v, d))
            self.graph[v].append((u, d))
        self.trips = trips
        self.time_per_km = 60.0 / s
        self.edge_usage = {}

    def heuristic(self, a, b):
        (x1, y1) = self.coords[a - 1]
        (x2, y2) = self.coords[b - 1]
        return math.dist((x1, y1), (x2, y2)) * self.time_per_km

    def astar(self, start, goal, start_time=0):
        pq = [(0, start_time, start, [])]
        dist = {start: 0}
        while pq:
            est_cost, t, node, path = heapq.heappop(pq)
            if node == goal:
                return path + [goal], t
            for nxt, d in self.graph[node]:
                edge_time = d * self.time_per_km
                wait = 0
                edge = tuple(sorted((node, nxt)))
                if edge not in self.edge_usage:
                    self.edge_usage[edge] = []
                conflicts = [
                    interval
                    for interval in self.edge_usage[edge]
                    if not (t + edge_time <= interval[0] or t >= interval[1])
                ]
                if len(conflicts) >= 2:
                    wait = self.w
                new_time = t + edge_time + wait
                if nxt not in dist or new_time < dist[nxt]:
                    dist[nxt] = new_time
                    heapq.heappush(
                        pq,
                        (
                            new_time + self.heuristic(nxt, goal),
                            new_time,
                            nxt,
                            path + [node],
                        ),
                    )
                self.edge_usage[edge].append((t + wait, t + wait + edge_time))
        return None, None

    def solve(self):
        results = []
        total = 0
        for i, (src, dst) in enumerate(self.trips, 1):
            path, time = self.astar(src, dst, 0)
            results.append((i, src, dst, path, time))
            total += time
        print("\n--- Problem 1 Results ---")
        for i, src, dst, path, time in results:
            print(f"Taxi {i}: Passenger {src}->{dst}")
            print(f"Route: {' -> '.join(map(str,path))}")
            print(f"Total time = {time:.1f} minutes\n")
        print(f"Overall Completion Time = {total:.1f} minutes")

str1 = input()
n, m, p, w, s = list(map(int, str1.split(" ")))

coords = []
for i in range(n):
    str1 = input()
    x, y = list(map(int, str1.split(" ")))
    temp = [x, y]
    coords.append(temp)

edges = []
for i in range(m):
    str1 = input()
    u, v, d = list(map(int, str1.split(" ")))
    temp = [u, v, d]
    edges.append(temp)

trips = []
for i in range(p):
    str1 = input()
    s, t = list(map(int, str1.split(" ")))
    temp = [s, t]
    trips.append(temp)

example = TaxiRouting(n, m, p, w, s, coords, edges, trips)
example.solve()

'''
test case:
8 9 3 30 40
0 0
30 0
80 0
30 60
120 0
30 120
60 120
110 120
1 2 30
2 3 50
2 4 60
3 5 40
4 6 70
5 7 20
6 7 30
7 8 50
3 6 90
2 7
1 8
3 4
'''