testproc.o: testproc.c /usr/include/stdc-predef.h user.h procinfo.h \
 types.h
