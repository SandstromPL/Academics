grep.o: grep.c /usr/include/stdc-predef.h types.h stat.h user.h \
 procinfo.h
