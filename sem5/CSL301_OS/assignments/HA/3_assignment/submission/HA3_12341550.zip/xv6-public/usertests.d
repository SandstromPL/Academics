usertests.o: usertests.c /usr/include/stdc-predef.h param.h types.h \
 stat.h user.h procinfo.h fs.h fcntl.h syscall.h traps.h memlayout.h
