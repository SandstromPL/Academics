stressfs.o: stressfs.c /usr/include/stdc-predef.h types.h stat.h user.h \
 procinfo.h fs.h fcntl.h
