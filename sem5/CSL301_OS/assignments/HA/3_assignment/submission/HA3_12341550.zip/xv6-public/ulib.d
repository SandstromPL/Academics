ulib.o: ulib.c /usr/include/stdc-predef.h types.h stat.h fcntl.h user.h \
 procinfo.h x86.h
