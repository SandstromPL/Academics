#include<stdio.h>
#include<stdlib.h>
int main(){

	int * mem = (int *)malloc(sizeof(int));

	return 0;

}
