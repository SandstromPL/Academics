#include<stdio.h>


int main(){

	int * val = NULL;
	//int deref = &val;
	printf("value of val : %p\ndereference value of val : %p\n",val,&val);
	return 0;

}
