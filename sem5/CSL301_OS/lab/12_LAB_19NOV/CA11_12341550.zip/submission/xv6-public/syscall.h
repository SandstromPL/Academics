// System call numbers
#define SYS_fork    1
#define SYS_exit    2
#define SYS_wait    3
#define SYS_pipe    4
#define SYS_read    5
#define SYS_kill    6
#define SYS_exec    7
#define SYS_fstat   8
#define SYS_chdir   9
#define SYS_dup    10
#define SYS_getpid 11
#define SYS_sbrk   12
#define SYS_sleep  13
#define SYS_uptime 14
#define SYS_open   15
#define SYS_write  16
#define SYS_mknod  17
#define SYS_unlink 18
#define SYS_link   19
#define SYS_mkdir  20
#define SYS_close  21
#define SYS_strrev 22   // CA1->step1
#define SYS_setflag 23  // HA1->step2
#define SYS_getflag 24  // HA1->step2
#define SYS_getstats 25 // LAB4-TA5-gmeet
#define SYS_get_proc_info 26  // HA2
#define SYS_numvp 27    //LAB5-CA4-step1
#define SYS_numpp 28    //LAB5-CA4-step1
#define SYS_getptsize 29    //LAB5-CA4-step1
#define SYS_setpriority 30  //HA3->step3
#define SYS_getpagefaults 31    //LAB6->part1->step3
#define SYS_twostrike 32    //LAB12->Q1

