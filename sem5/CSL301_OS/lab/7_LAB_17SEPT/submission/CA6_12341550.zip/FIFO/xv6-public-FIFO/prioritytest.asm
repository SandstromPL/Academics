
_prioritytest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
// HA3->step5
#include "types.h"
#include "stat.h"
#include "user.h"
int main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	83 ec 0c             	sub    $0xc,%esp
    int pid1, pid2, pid3, pid4, pid5;
    printf(1, " Starting priority scheduling test ...\n ");
  11:	68 68 08 00 00       	push   $0x868
  16:	6a 01                	push   $0x1
  18:	e8 43 05 00 00       	call   560 <printf>

    pid1 = fork();
  1d:	e8 99 03 00 00       	call   3bb <fork>
    if (pid1 == 0)
  22:	83 c4 10             	add    $0x10,%esp
  25:	85 c0                	test   %eax,%eax
  27:	75 32                	jne    5b <main+0x5b>
    {
        setpriority(10);
  29:	83 ec 0c             	sub    $0xc,%esp
  2c:	6a 0a                	push   $0xa
  2e:	e8 70 04 00 00       	call   4a3 <setpriority>
        printf(1, " Child 1 (pid %d) with priority (10) started .\n ",
  33:	e8 0b 04 00 00       	call   443 <getpid>
  38:	83 c4 0c             	add    $0xc,%esp
  3b:	50                   	push   %eax
  3c:	68 94 08 00 00       	push   $0x894
  41:	6a 01                	push   $0x1
  43:	e8 18 05 00 00       	call   560 <printf>
               getpid());
        for (int i = 0; i < 50000000; i++)
        {
        } // Busy loop
        printf(1, " Child 1 finished .\n ");
  48:	59                   	pop    %ecx
  49:	58                   	pop    %eax
  4a:	68 bb 09 00 00       	push   $0x9bb
  4f:	6a 01                	push   $0x1
  51:	e8 0a 05 00 00       	call   560 <printf>
        exit();
  56:	e8 68 03 00 00       	call   3c3 <exit>
    }

    pid2 = fork();
  5b:	e8 5b 03 00 00       	call   3bb <fork>
    if (pid2 == 0)
  60:	85 c0                	test   %eax,%eax
  62:	75 32                	jne    96 <main+0x96>
    {
        setpriority(50);
  64:	83 ec 0c             	sub    $0xc,%esp
  67:	6a 32                	push   $0x32
  69:	e8 35 04 00 00       	call   4a3 <setpriority>
        printf(1, " Child 2 (pid %d) with priority (50) started .\n ",
  6e:	e8 d0 03 00 00       	call   443 <getpid>
  73:	83 c4 0c             	add    $0xc,%esp
  76:	50                   	push   %eax
  77:	68 c8 08 00 00       	push   $0x8c8
  7c:	6a 01                	push   $0x1
  7e:	e8 dd 04 00 00       	call   560 <printf>
               getpid());
        for (int i = 0; i < 50000000; i++)
        {
        } // Busy loop
        printf(1, " Child 2 finished .\n ");
  83:	58                   	pop    %eax
  84:	5a                   	pop    %edx
  85:	68 d1 09 00 00       	push   $0x9d1
  8a:	6a 01                	push   $0x1
  8c:	e8 cf 04 00 00       	call   560 <printf>
        exit();
  91:	e8 2d 03 00 00       	call   3c3 <exit>
    }

    pid3 = fork();
  96:	e8 20 03 00 00       	call   3bb <fork>
    if (pid3 == 0)
  9b:	85 c0                	test   %eax,%eax
  9d:	74 3b                	je     da <main+0xda>
        } // Busy loop
        printf(1, " Child 3 finished .\n ");
        exit();
    }

    pid4 = fork();
  9f:	e8 17 03 00 00       	call   3bb <fork>
    if (pid4 == 0)
  a4:	85 c0                	test   %eax,%eax
  a6:	75 64                	jne    10c <main+0x10c>
    {
        setpriority(30); // Low priority
  a8:	83 ec 0c             	sub    $0xc,%esp
  ab:	6a 1e                	push   $0x1e
  ad:	e8 f1 03 00 00       	call   4a3 <setpriority>
        printf(1, " Child 4 (pid %d) with priority (30) started .\n ",
  b2:	e8 8c 03 00 00       	call   443 <getpid>
  b7:	83 c4 0c             	add    $0xc,%esp
  ba:	50                   	push   %eax
  bb:	68 30 09 00 00       	push   $0x930
  c0:	6a 01                	push   $0x1
  c2:	e8 99 04 00 00       	call   560 <printf>
               getpid());
        for (int i = 0; i < 50000000; i++)
        {
        } // Busy loop
        printf(1, " Child 4 finished .\n ");
  c7:	58                   	pop    %eax
  c8:	5a                   	pop    %edx
  c9:	68 fd 09 00 00       	push   $0x9fd
  ce:	6a 01                	push   $0x1
  d0:	e8 8b 04 00 00       	call   560 <printf>
        exit();
  d5:	e8 e9 02 00 00       	call   3c3 <exit>
        setpriority(70); // Low priority
  da:	83 ec 0c             	sub    $0xc,%esp
  dd:	6a 46                	push   $0x46
  df:	e8 bf 03 00 00       	call   4a3 <setpriority>
        printf(1, " Child 3 (pid %d) with priority (70) started .\n ",
  e4:	e8 5a 03 00 00       	call   443 <getpid>
  e9:	83 c4 0c             	add    $0xc,%esp
  ec:	50                   	push   %eax
  ed:	68 fc 08 00 00       	push   $0x8fc
  f2:	6a 01                	push   $0x1
  f4:	e8 67 04 00 00       	call   560 <printf>
        printf(1, " Child 3 finished .\n ");
  f9:	59                   	pop    %ecx
  fa:	58                   	pop    %eax
  fb:	68 e7 09 00 00       	push   $0x9e7
 100:	6a 01                	push   $0x1
 102:	e8 59 04 00 00       	call   560 <printf>
        exit();
 107:	e8 b7 02 00 00       	call   3c3 <exit>
    }

    pid5 = fork();
 10c:	e8 aa 02 00 00       	call   3bb <fork>
    if (pid5 == 0)
 111:	85 c0                	test   %eax,%eax
 113:	75 32                	jne    147 <main+0x147>
    {
        setpriority(5); // Low priority
 115:	83 ec 0c             	sub    $0xc,%esp
 118:	6a 05                	push   $0x5
 11a:	e8 84 03 00 00       	call   4a3 <setpriority>
        printf(1, " Child 5 (pid %d) with priority (5) started .\n ",
 11f:	e8 1f 03 00 00       	call   443 <getpid>
 124:	83 c4 0c             	add    $0xc,%esp
 127:	50                   	push   %eax
 128:	68 64 09 00 00       	push   $0x964
 12d:	6a 01                	push   $0x1
 12f:	e8 2c 04 00 00       	call   560 <printf>
               getpid());
        for (int i = 0; i < 50000000; i++)
        {
        } // Busy loop
        printf(1, " Child 5 finished .\n ");
 134:	5a                   	pop    %edx
 135:	59                   	pop    %ecx
 136:	68 13 0a 00 00       	push   $0xa13
 13b:	6a 01                	push   $0x1
 13d:	e8 1e 04 00 00       	call   560 <printf>
        exit();
 142:	e8 7c 02 00 00       	call   3c3 <exit>
    }
    wait();
 147:	e8 7f 02 00 00       	call   3cb <wait>
    wait();
 14c:	e8 7a 02 00 00       	call   3cb <wait>
    wait();
 151:	e8 75 02 00 00       	call   3cb <wait>
    wait();
 156:	e8 70 02 00 00       	call   3cb <wait>
    wait();
 15b:	e8 6b 02 00 00       	call   3cb <wait>
    printf(1, " Priority scheduling test complete .\n ");
 160:	50                   	push   %eax
 161:	50                   	push   %eax
 162:	68 94 09 00 00       	push   $0x994
 167:	6a 01                	push   $0x1
 169:	e8 f2 03 00 00       	call   560 <printf>
    exit();
 16e:	e8 50 02 00 00       	call   3c3 <exit>
 173:	66 90                	xchg   %ax,%ax
 175:	66 90                	xchg   %ax,%ax
 177:	66 90                	xchg   %ax,%ax
 179:	66 90                	xchg   %ax,%ax
 17b:	66 90                	xchg   %ax,%ax
 17d:	66 90                	xchg   %ax,%ax
 17f:	90                   	nop

00000180 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 180:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 181:	31 c0                	xor    %eax,%eax
{
 183:	89 e5                	mov    %esp,%ebp
 185:	53                   	push   %ebx
 186:	8b 4d 08             	mov    0x8(%ebp),%ecx
 189:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 18c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 190:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 194:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 197:	83 c0 01             	add    $0x1,%eax
 19a:	84 d2                	test   %dl,%dl
 19c:	75 f2                	jne    190 <strcpy+0x10>
    ;
  return os;
}
 19e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1a1:	89 c8                	mov    %ecx,%eax
 1a3:	c9                   	leave
 1a4:	c3                   	ret
 1a5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1ac:	00 
 1ad:	8d 76 00             	lea    0x0(%esi),%esi

000001b0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1b0:	55                   	push   %ebp
 1b1:	89 e5                	mov    %esp,%ebp
 1b3:	53                   	push   %ebx
 1b4:	8b 55 08             	mov    0x8(%ebp),%edx
 1b7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 1ba:	0f b6 02             	movzbl (%edx),%eax
 1bd:	84 c0                	test   %al,%al
 1bf:	75 17                	jne    1d8 <strcmp+0x28>
 1c1:	eb 3a                	jmp    1fd <strcmp+0x4d>
 1c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 1c8:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 1cc:	83 c2 01             	add    $0x1,%edx
 1cf:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
 1d2:	84 c0                	test   %al,%al
 1d4:	74 1a                	je     1f0 <strcmp+0x40>
 1d6:	89 d9                	mov    %ebx,%ecx
 1d8:	0f b6 19             	movzbl (%ecx),%ebx
 1db:	38 c3                	cmp    %al,%bl
 1dd:	74 e9                	je     1c8 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
 1df:	29 d8                	sub    %ebx,%eax
}
 1e1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1e4:	c9                   	leave
 1e5:	c3                   	ret
 1e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1ed:	00 
 1ee:	66 90                	xchg   %ax,%ax
  return (uchar)*p - (uchar)*q;
 1f0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 1f4:	31 c0                	xor    %eax,%eax
 1f6:	29 d8                	sub    %ebx,%eax
}
 1f8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1fb:	c9                   	leave
 1fc:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 1fd:	0f b6 19             	movzbl (%ecx),%ebx
 200:	31 c0                	xor    %eax,%eax
 202:	eb db                	jmp    1df <strcmp+0x2f>
 204:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 20b:	00 
 20c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000210 <strlen>:

uint
strlen(const char *s)
{
 210:	55                   	push   %ebp
 211:	89 e5                	mov    %esp,%ebp
 213:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 216:	80 3a 00             	cmpb   $0x0,(%edx)
 219:	74 15                	je     230 <strlen+0x20>
 21b:	31 c0                	xor    %eax,%eax
 21d:	8d 76 00             	lea    0x0(%esi),%esi
 220:	83 c0 01             	add    $0x1,%eax
 223:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 227:	89 c1                	mov    %eax,%ecx
 229:	75 f5                	jne    220 <strlen+0x10>
    ;
  return n;
}
 22b:	89 c8                	mov    %ecx,%eax
 22d:	5d                   	pop    %ebp
 22e:	c3                   	ret
 22f:	90                   	nop
  for(n = 0; s[n]; n++)
 230:	31 c9                	xor    %ecx,%ecx
}
 232:	5d                   	pop    %ebp
 233:	89 c8                	mov    %ecx,%eax
 235:	c3                   	ret
 236:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 23d:	00 
 23e:	66 90                	xchg   %ax,%ax

00000240 <memset>:

void*
memset(void *dst, int c, uint n)
{
 240:	55                   	push   %ebp
 241:	89 e5                	mov    %esp,%ebp
 243:	57                   	push   %edi
 244:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 247:	8b 4d 10             	mov    0x10(%ebp),%ecx
 24a:	8b 45 0c             	mov    0xc(%ebp),%eax
 24d:	89 d7                	mov    %edx,%edi
 24f:	fc                   	cld
 250:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 252:	8b 7d fc             	mov    -0x4(%ebp),%edi
 255:	89 d0                	mov    %edx,%eax
 257:	c9                   	leave
 258:	c3                   	ret
 259:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000260 <strchr>:

char*
strchr(const char *s, char c)
{
 260:	55                   	push   %ebp
 261:	89 e5                	mov    %esp,%ebp
 263:	8b 45 08             	mov    0x8(%ebp),%eax
 266:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 26a:	0f b6 10             	movzbl (%eax),%edx
 26d:	84 d2                	test   %dl,%dl
 26f:	75 12                	jne    283 <strchr+0x23>
 271:	eb 1d                	jmp    290 <strchr+0x30>
 273:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 278:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 27c:	83 c0 01             	add    $0x1,%eax
 27f:	84 d2                	test   %dl,%dl
 281:	74 0d                	je     290 <strchr+0x30>
    if(*s == c)
 283:	38 d1                	cmp    %dl,%cl
 285:	75 f1                	jne    278 <strchr+0x18>
      return (char*)s;
  return 0;
}
 287:	5d                   	pop    %ebp
 288:	c3                   	ret
 289:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 290:	31 c0                	xor    %eax,%eax
}
 292:	5d                   	pop    %ebp
 293:	c3                   	ret
 294:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 29b:	00 
 29c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000002a0 <gets>:

char*
gets(char *buf, int max)
{
 2a0:	55                   	push   %ebp
 2a1:	89 e5                	mov    %esp,%ebp
 2a3:	57                   	push   %edi
 2a4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 2a5:	8d 75 e7             	lea    -0x19(%ebp),%esi
{
 2a8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 2a9:	31 db                	xor    %ebx,%ebx
{
 2ab:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 2ae:	eb 27                	jmp    2d7 <gets+0x37>
    cc = read(0, &c, 1);
 2b0:	83 ec 04             	sub    $0x4,%esp
 2b3:	6a 01                	push   $0x1
 2b5:	56                   	push   %esi
 2b6:	6a 00                	push   $0x0
 2b8:	e8 1e 01 00 00       	call   3db <read>
    if(cc < 1)
 2bd:	83 c4 10             	add    $0x10,%esp
 2c0:	85 c0                	test   %eax,%eax
 2c2:	7e 1d                	jle    2e1 <gets+0x41>
      break;
    buf[i++] = c;
 2c4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 2c8:	8b 55 08             	mov    0x8(%ebp),%edx
 2cb:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 2cf:	3c 0a                	cmp    $0xa,%al
 2d1:	74 10                	je     2e3 <gets+0x43>
 2d3:	3c 0d                	cmp    $0xd,%al
 2d5:	74 0c                	je     2e3 <gets+0x43>
  for(i=0; i+1 < max; ){
 2d7:	89 df                	mov    %ebx,%edi
 2d9:	83 c3 01             	add    $0x1,%ebx
 2dc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 2df:	7c cf                	jl     2b0 <gets+0x10>
 2e1:	89 fb                	mov    %edi,%ebx
      break;
  }
  buf[i] = '\0';
 2e3:	8b 45 08             	mov    0x8(%ebp),%eax
 2e6:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
  return buf;
}
 2ea:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2ed:	5b                   	pop    %ebx
 2ee:	5e                   	pop    %esi
 2ef:	5f                   	pop    %edi
 2f0:	5d                   	pop    %ebp
 2f1:	c3                   	ret
 2f2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2f9:	00 
 2fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000300 <stat>:

int
stat(const char *n, struct stat *st)
{
 300:	55                   	push   %ebp
 301:	89 e5                	mov    %esp,%ebp
 303:	56                   	push   %esi
 304:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 305:	83 ec 08             	sub    $0x8,%esp
 308:	6a 00                	push   $0x0
 30a:	ff 75 08             	push   0x8(%ebp)
 30d:	e8 f1 00 00 00       	call   403 <open>
  if(fd < 0)
 312:	83 c4 10             	add    $0x10,%esp
 315:	85 c0                	test   %eax,%eax
 317:	78 27                	js     340 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 319:	83 ec 08             	sub    $0x8,%esp
 31c:	ff 75 0c             	push   0xc(%ebp)
 31f:	89 c3                	mov    %eax,%ebx
 321:	50                   	push   %eax
 322:	e8 f4 00 00 00       	call   41b <fstat>
  close(fd);
 327:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 32a:	89 c6                	mov    %eax,%esi
  close(fd);
 32c:	e8 ba 00 00 00       	call   3eb <close>
  return r;
 331:	83 c4 10             	add    $0x10,%esp
}
 334:	8d 65 f8             	lea    -0x8(%ebp),%esp
 337:	89 f0                	mov    %esi,%eax
 339:	5b                   	pop    %ebx
 33a:	5e                   	pop    %esi
 33b:	5d                   	pop    %ebp
 33c:	c3                   	ret
 33d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 340:	be ff ff ff ff       	mov    $0xffffffff,%esi
 345:	eb ed                	jmp    334 <stat+0x34>
 347:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 34e:	00 
 34f:	90                   	nop

00000350 <atoi>:

int
atoi(const char *s)
{
 350:	55                   	push   %ebp
 351:	89 e5                	mov    %esp,%ebp
 353:	53                   	push   %ebx
 354:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 357:	0f be 02             	movsbl (%edx),%eax
 35a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 35d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 360:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 365:	77 1e                	ja     385 <atoi+0x35>
 367:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 36e:	00 
 36f:	90                   	nop
    n = n*10 + *s++ - '0';
 370:	83 c2 01             	add    $0x1,%edx
 373:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 376:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 37a:	0f be 02             	movsbl (%edx),%eax
 37d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 380:	80 fb 09             	cmp    $0x9,%bl
 383:	76 eb                	jbe    370 <atoi+0x20>
  return n;
}
 385:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 388:	89 c8                	mov    %ecx,%eax
 38a:	c9                   	leave
 38b:	c3                   	ret
 38c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000390 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 390:	55                   	push   %ebp
 391:	89 e5                	mov    %esp,%ebp
 393:	57                   	push   %edi
 394:	8b 45 10             	mov    0x10(%ebp),%eax
 397:	8b 55 08             	mov    0x8(%ebp),%edx
 39a:	56                   	push   %esi
 39b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 39e:	85 c0                	test   %eax,%eax
 3a0:	7e 13                	jle    3b5 <memmove+0x25>
 3a2:	01 d0                	add    %edx,%eax
  dst = vdst;
 3a4:	89 d7                	mov    %edx,%edi
 3a6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3ad:	00 
 3ae:	66 90                	xchg   %ax,%ax
    *dst++ = *src++;
 3b0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 3b1:	39 f8                	cmp    %edi,%eax
 3b3:	75 fb                	jne    3b0 <memmove+0x20>
  return vdst;
}
 3b5:	5e                   	pop    %esi
 3b6:	89 d0                	mov    %edx,%eax
 3b8:	5f                   	pop    %edi
 3b9:	5d                   	pop    %ebp
 3ba:	c3                   	ret

000003bb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 3bb:	b8 01 00 00 00       	mov    $0x1,%eax
 3c0:	cd 40                	int    $0x40
 3c2:	c3                   	ret

000003c3 <exit>:
SYSCALL(exit)
 3c3:	b8 02 00 00 00       	mov    $0x2,%eax
 3c8:	cd 40                	int    $0x40
 3ca:	c3                   	ret

000003cb <wait>:
SYSCALL(wait)
 3cb:	b8 03 00 00 00       	mov    $0x3,%eax
 3d0:	cd 40                	int    $0x40
 3d2:	c3                   	ret

000003d3 <pipe>:
SYSCALL(pipe)
 3d3:	b8 04 00 00 00       	mov    $0x4,%eax
 3d8:	cd 40                	int    $0x40
 3da:	c3                   	ret

000003db <read>:
SYSCALL(read)
 3db:	b8 05 00 00 00       	mov    $0x5,%eax
 3e0:	cd 40                	int    $0x40
 3e2:	c3                   	ret

000003e3 <write>:
SYSCALL(write)
 3e3:	b8 10 00 00 00       	mov    $0x10,%eax
 3e8:	cd 40                	int    $0x40
 3ea:	c3                   	ret

000003eb <close>:
SYSCALL(close)
 3eb:	b8 15 00 00 00       	mov    $0x15,%eax
 3f0:	cd 40                	int    $0x40
 3f2:	c3                   	ret

000003f3 <kill>:
SYSCALL(kill)
 3f3:	b8 06 00 00 00       	mov    $0x6,%eax
 3f8:	cd 40                	int    $0x40
 3fa:	c3                   	ret

000003fb <exec>:
SYSCALL(exec)
 3fb:	b8 07 00 00 00       	mov    $0x7,%eax
 400:	cd 40                	int    $0x40
 402:	c3                   	ret

00000403 <open>:
SYSCALL(open)
 403:	b8 0f 00 00 00       	mov    $0xf,%eax
 408:	cd 40                	int    $0x40
 40a:	c3                   	ret

0000040b <mknod>:
SYSCALL(mknod)
 40b:	b8 11 00 00 00       	mov    $0x11,%eax
 410:	cd 40                	int    $0x40
 412:	c3                   	ret

00000413 <unlink>:
SYSCALL(unlink)
 413:	b8 12 00 00 00       	mov    $0x12,%eax
 418:	cd 40                	int    $0x40
 41a:	c3                   	ret

0000041b <fstat>:
SYSCALL(fstat)
 41b:	b8 08 00 00 00       	mov    $0x8,%eax
 420:	cd 40                	int    $0x40
 422:	c3                   	ret

00000423 <link>:
SYSCALL(link)
 423:	b8 13 00 00 00       	mov    $0x13,%eax
 428:	cd 40                	int    $0x40
 42a:	c3                   	ret

0000042b <mkdir>:
SYSCALL(mkdir)
 42b:	b8 14 00 00 00       	mov    $0x14,%eax
 430:	cd 40                	int    $0x40
 432:	c3                   	ret

00000433 <chdir>:
SYSCALL(chdir)
 433:	b8 09 00 00 00       	mov    $0x9,%eax
 438:	cd 40                	int    $0x40
 43a:	c3                   	ret

0000043b <dup>:
SYSCALL(dup)
 43b:	b8 0a 00 00 00       	mov    $0xa,%eax
 440:	cd 40                	int    $0x40
 442:	c3                   	ret

00000443 <getpid>:
SYSCALL(getpid)
 443:	b8 0b 00 00 00       	mov    $0xb,%eax
 448:	cd 40                	int    $0x40
 44a:	c3                   	ret

0000044b <sbrk>:
SYSCALL(sbrk)
 44b:	b8 0c 00 00 00       	mov    $0xc,%eax
 450:	cd 40                	int    $0x40
 452:	c3                   	ret

00000453 <sleep>:
SYSCALL(sleep)
 453:	b8 0d 00 00 00       	mov    $0xd,%eax
 458:	cd 40                	int    $0x40
 45a:	c3                   	ret

0000045b <uptime>:
SYSCALL(uptime)
 45b:	b8 0e 00 00 00       	mov    $0xe,%eax
 460:	cd 40                	int    $0x40
 462:	c3                   	ret

00000463 <strrev>:
SYSCALL(strrev)
 463:	b8 16 00 00 00       	mov    $0x16,%eax
 468:	cd 40                	int    $0x40
 46a:	c3                   	ret

0000046b <setflag>:
SYSCALL(setflag)
 46b:	b8 17 00 00 00       	mov    $0x17,%eax
 470:	cd 40                	int    $0x40
 472:	c3                   	ret

00000473 <getflag>:
SYSCALL(getflag)
 473:	b8 18 00 00 00       	mov    $0x18,%eax
 478:	cd 40                	int    $0x40
 47a:	c3                   	ret

0000047b <getstats>:
SYSCALL(getstats)
 47b:	b8 19 00 00 00       	mov    $0x19,%eax
 480:	cd 40                	int    $0x40
 482:	c3                   	ret

00000483 <get_proc_info>:
SYSCALL(get_proc_info)
 483:	b8 1a 00 00 00       	mov    $0x1a,%eax
 488:	cd 40                	int    $0x40
 48a:	c3                   	ret

0000048b <numvp>:
SYSCALL(numvp)
 48b:	b8 1b 00 00 00       	mov    $0x1b,%eax
 490:	cd 40                	int    $0x40
 492:	c3                   	ret

00000493 <numpp>:
SYSCALL(numpp)
 493:	b8 1c 00 00 00       	mov    $0x1c,%eax
 498:	cd 40                	int    $0x40
 49a:	c3                   	ret

0000049b <getptsize>:
SYSCALL(getptsize)
 49b:	b8 1d 00 00 00       	mov    $0x1d,%eax
 4a0:	cd 40                	int    $0x40
 4a2:	c3                   	ret

000004a3 <setpriority>:
SYSCALL(setpriority)
 4a3:	b8 1e 00 00 00       	mov    $0x1e,%eax
 4a8:	cd 40                	int    $0x40
 4aa:	c3                   	ret

000004ab <getpagefaults>:
 4ab:	b8 1f 00 00 00       	mov    $0x1f,%eax
 4b0:	cd 40                	int    $0x40
 4b2:	c3                   	ret
 4b3:	66 90                	xchg   %ax,%ax
 4b5:	66 90                	xchg   %ax,%ax
 4b7:	66 90                	xchg   %ax,%ax
 4b9:	66 90                	xchg   %ax,%ax
 4bb:	66 90                	xchg   %ax,%ax
 4bd:	66 90                	xchg   %ax,%ax
 4bf:	90                   	nop

000004c0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 4c0:	55                   	push   %ebp
 4c1:	89 e5                	mov    %esp,%ebp
 4c3:	57                   	push   %edi
 4c4:	56                   	push   %esi
 4c5:	53                   	push   %ebx
 4c6:	89 cb                	mov    %ecx,%ebx
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 4c8:	89 d1                	mov    %edx,%ecx
{
 4ca:	83 ec 3c             	sub    $0x3c,%esp
 4cd:	89 45 c0             	mov    %eax,-0x40(%ebp)
  if(sgn && xx < 0){
 4d0:	85 d2                	test   %edx,%edx
 4d2:	0f 89 80 00 00 00    	jns    558 <printint+0x98>
 4d8:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 4dc:	74 7a                	je     558 <printint+0x98>
    x = -xx;
 4de:	f7 d9                	neg    %ecx
    neg = 1;
 4e0:	b8 01 00 00 00       	mov    $0x1,%eax
  } else {
    x = xx;
  }

  i = 0;
 4e5:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 4e8:	31 f6                	xor    %esi,%esi
 4ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 4f0:	89 c8                	mov    %ecx,%eax
 4f2:	31 d2                	xor    %edx,%edx
 4f4:	89 f7                	mov    %esi,%edi
 4f6:	f7 f3                	div    %ebx
 4f8:	8d 76 01             	lea    0x1(%esi),%esi
 4fb:	0f b6 92 88 0a 00 00 	movzbl 0xa88(%edx),%edx
 502:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 506:	89 ca                	mov    %ecx,%edx
 508:	89 c1                	mov    %eax,%ecx
 50a:	39 da                	cmp    %ebx,%edx
 50c:	73 e2                	jae    4f0 <printint+0x30>
  if(neg)
 50e:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 511:	85 c0                	test   %eax,%eax
 513:	74 07                	je     51c <printint+0x5c>
    buf[i++] = '-';
 515:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)

  while(--i >= 0)
 51a:	89 f7                	mov    %esi,%edi
 51c:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 51f:	8b 75 c0             	mov    -0x40(%ebp),%esi
 522:	01 df                	add    %ebx,%edi
 524:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    putc(fd, buf[i]);
 528:	0f b6 07             	movzbl (%edi),%eax
  write(fd, &c, 1);
 52b:	83 ec 04             	sub    $0x4,%esp
 52e:	88 45 d7             	mov    %al,-0x29(%ebp)
 531:	8d 45 d7             	lea    -0x29(%ebp),%eax
 534:	6a 01                	push   $0x1
 536:	50                   	push   %eax
 537:	56                   	push   %esi
 538:	e8 a6 fe ff ff       	call   3e3 <write>
  while(--i >= 0)
 53d:	89 f8                	mov    %edi,%eax
 53f:	83 c4 10             	add    $0x10,%esp
 542:	83 ef 01             	sub    $0x1,%edi
 545:	39 c3                	cmp    %eax,%ebx
 547:	75 df                	jne    528 <printint+0x68>
}
 549:	8d 65 f4             	lea    -0xc(%ebp),%esp
 54c:	5b                   	pop    %ebx
 54d:	5e                   	pop    %esi
 54e:	5f                   	pop    %edi
 54f:	5d                   	pop    %ebp
 550:	c3                   	ret
 551:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 558:	31 c0                	xor    %eax,%eax
 55a:	eb 89                	jmp    4e5 <printint+0x25>
 55c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000560 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 560:	55                   	push   %ebp
 561:	89 e5                	mov    %esp,%ebp
 563:	57                   	push   %edi
 564:	56                   	push   %esi
 565:	53                   	push   %ebx
 566:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 569:	8b 75 0c             	mov    0xc(%ebp),%esi
{
 56c:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i = 0; fmt[i]; i++){
 56f:	0f b6 1e             	movzbl (%esi),%ebx
 572:	83 c6 01             	add    $0x1,%esi
 575:	84 db                	test   %bl,%bl
 577:	74 67                	je     5e0 <printf+0x80>
 579:	8d 4d 10             	lea    0x10(%ebp),%ecx
 57c:	31 d2                	xor    %edx,%edx
 57e:	89 4d d0             	mov    %ecx,-0x30(%ebp)
 581:	eb 34                	jmp    5b7 <printf+0x57>
 583:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 588:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 58b:	ba 25 00 00 00       	mov    $0x25,%edx
      if(c == '%'){
 590:	83 f8 25             	cmp    $0x25,%eax
 593:	74 18                	je     5ad <printf+0x4d>
  write(fd, &c, 1);
 595:	83 ec 04             	sub    $0x4,%esp
 598:	8d 45 e7             	lea    -0x19(%ebp),%eax
 59b:	88 5d e7             	mov    %bl,-0x19(%ebp)
 59e:	6a 01                	push   $0x1
 5a0:	50                   	push   %eax
 5a1:	57                   	push   %edi
 5a2:	e8 3c fe ff ff       	call   3e3 <write>
 5a7:	8b 55 d4             	mov    -0x2c(%ebp),%edx
      } else {
        putc(fd, c);
 5aa:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 5ad:	0f b6 1e             	movzbl (%esi),%ebx
 5b0:	83 c6 01             	add    $0x1,%esi
 5b3:	84 db                	test   %bl,%bl
 5b5:	74 29                	je     5e0 <printf+0x80>
    c = fmt[i] & 0xff;
 5b7:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 5ba:	85 d2                	test   %edx,%edx
 5bc:	74 ca                	je     588 <printf+0x28>
      }
    } else if(state == '%'){
 5be:	83 fa 25             	cmp    $0x25,%edx
 5c1:	75 ea                	jne    5ad <printf+0x4d>
      if(c == 'd'){
 5c3:	83 f8 25             	cmp    $0x25,%eax
 5c6:	0f 84 04 01 00 00    	je     6d0 <printf+0x170>
 5cc:	83 e8 63             	sub    $0x63,%eax
 5cf:	83 f8 15             	cmp    $0x15,%eax
 5d2:	77 1c                	ja     5f0 <printf+0x90>
 5d4:	ff 24 85 30 0a 00 00 	jmp    *0xa30(,%eax,4)
 5db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 5e0:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5e3:	5b                   	pop    %ebx
 5e4:	5e                   	pop    %esi
 5e5:	5f                   	pop    %edi
 5e6:	5d                   	pop    %ebp
 5e7:	c3                   	ret
 5e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5ef:	00 
  write(fd, &c, 1);
 5f0:	83 ec 04             	sub    $0x4,%esp
 5f3:	8d 55 e7             	lea    -0x19(%ebp),%edx
 5f6:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 5fa:	6a 01                	push   $0x1
 5fc:	52                   	push   %edx
 5fd:	89 55 d4             	mov    %edx,-0x2c(%ebp)
 600:	57                   	push   %edi
 601:	e8 dd fd ff ff       	call   3e3 <write>
 606:	83 c4 0c             	add    $0xc,%esp
 609:	88 5d e7             	mov    %bl,-0x19(%ebp)
 60c:	6a 01                	push   $0x1
 60e:	8b 55 d4             	mov    -0x2c(%ebp),%edx
 611:	52                   	push   %edx
 612:	57                   	push   %edi
 613:	e8 cb fd ff ff       	call   3e3 <write>
        putc(fd, c);
 618:	83 c4 10             	add    $0x10,%esp
      state = 0;
 61b:	31 d2                	xor    %edx,%edx
 61d:	eb 8e                	jmp    5ad <printf+0x4d>
 61f:	90                   	nop
        printint(fd, *ap, 16, 0);
 620:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 623:	83 ec 0c             	sub    $0xc,%esp
 626:	b9 10 00 00 00       	mov    $0x10,%ecx
 62b:	8b 13                	mov    (%ebx),%edx
 62d:	6a 00                	push   $0x0
 62f:	89 f8                	mov    %edi,%eax
        ap++;
 631:	83 c3 04             	add    $0x4,%ebx
        printint(fd, *ap, 16, 0);
 634:	e8 87 fe ff ff       	call   4c0 <printint>
        ap++;
 639:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 63c:	83 c4 10             	add    $0x10,%esp
      state = 0;
 63f:	31 d2                	xor    %edx,%edx
 641:	e9 67 ff ff ff       	jmp    5ad <printf+0x4d>
        s = (char*)*ap;
 646:	8b 45 d0             	mov    -0x30(%ebp),%eax
 649:	8b 18                	mov    (%eax),%ebx
        ap++;
 64b:	83 c0 04             	add    $0x4,%eax
 64e:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 651:	85 db                	test   %ebx,%ebx
 653:	0f 84 87 00 00 00    	je     6e0 <printf+0x180>
        while(*s != 0){
 659:	0f b6 03             	movzbl (%ebx),%eax
      state = 0;
 65c:	31 d2                	xor    %edx,%edx
        while(*s != 0){
 65e:	84 c0                	test   %al,%al
 660:	0f 84 47 ff ff ff    	je     5ad <printf+0x4d>
 666:	8d 55 e7             	lea    -0x19(%ebp),%edx
 669:	89 75 d4             	mov    %esi,-0x2c(%ebp)
 66c:	89 de                	mov    %ebx,%esi
 66e:	89 d3                	mov    %edx,%ebx
  write(fd, &c, 1);
 670:	83 ec 04             	sub    $0x4,%esp
 673:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 676:	83 c6 01             	add    $0x1,%esi
  write(fd, &c, 1);
 679:	6a 01                	push   $0x1
 67b:	53                   	push   %ebx
 67c:	57                   	push   %edi
 67d:	e8 61 fd ff ff       	call   3e3 <write>
        while(*s != 0){
 682:	0f b6 06             	movzbl (%esi),%eax
 685:	83 c4 10             	add    $0x10,%esp
 688:	84 c0                	test   %al,%al
 68a:	75 e4                	jne    670 <printf+0x110>
      state = 0;
 68c:	8b 75 d4             	mov    -0x2c(%ebp),%esi
 68f:	31 d2                	xor    %edx,%edx
 691:	e9 17 ff ff ff       	jmp    5ad <printf+0x4d>
        printint(fd, *ap, 10, 1);
 696:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 699:	83 ec 0c             	sub    $0xc,%esp
 69c:	b9 0a 00 00 00       	mov    $0xa,%ecx
 6a1:	8b 13                	mov    (%ebx),%edx
 6a3:	6a 01                	push   $0x1
 6a5:	eb 88                	jmp    62f <printf+0xcf>
        putc(fd, *ap);
 6a7:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  write(fd, &c, 1);
 6aa:	83 ec 04             	sub    $0x4,%esp
 6ad:	8d 55 e7             	lea    -0x19(%ebp),%edx
        putc(fd, *ap);
 6b0:	8b 03                	mov    (%ebx),%eax
        ap++;
 6b2:	83 c3 04             	add    $0x4,%ebx
        putc(fd, *ap);
 6b5:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6b8:	6a 01                	push   $0x1
 6ba:	52                   	push   %edx
 6bb:	57                   	push   %edi
 6bc:	e8 22 fd ff ff       	call   3e3 <write>
        ap++;
 6c1:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 6c4:	83 c4 10             	add    $0x10,%esp
      state = 0;
 6c7:	31 d2                	xor    %edx,%edx
 6c9:	e9 df fe ff ff       	jmp    5ad <printf+0x4d>
 6ce:	66 90                	xchg   %ax,%ax
  write(fd, &c, 1);
 6d0:	83 ec 04             	sub    $0x4,%esp
 6d3:	88 5d e7             	mov    %bl,-0x19(%ebp)
 6d6:	8d 55 e7             	lea    -0x19(%ebp),%edx
 6d9:	6a 01                	push   $0x1
 6db:	e9 31 ff ff ff       	jmp    611 <printf+0xb1>
 6e0:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 6e5:	bb 29 0a 00 00       	mov    $0xa29,%ebx
 6ea:	e9 77 ff ff ff       	jmp    666 <printf+0x106>
 6ef:	90                   	nop

000006f0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 6f0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 6f1:	a1 24 0d 00 00       	mov    0xd24,%eax
{
 6f6:	89 e5                	mov    %esp,%ebp
 6f8:	57                   	push   %edi
 6f9:	56                   	push   %esi
 6fa:	53                   	push   %ebx
 6fb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 6fe:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 701:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 708:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 70a:	39 c8                	cmp    %ecx,%eax
 70c:	73 32                	jae    740 <free+0x50>
 70e:	39 d1                	cmp    %edx,%ecx
 710:	72 04                	jb     716 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 712:	39 d0                	cmp    %edx,%eax
 714:	72 32                	jb     748 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
 716:	8b 73 fc             	mov    -0x4(%ebx),%esi
 719:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 71c:	39 fa                	cmp    %edi,%edx
 71e:	74 30                	je     750 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 720:	89 53 f8             	mov    %edx,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 723:	8b 50 04             	mov    0x4(%eax),%edx
 726:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 729:	39 f1                	cmp    %esi,%ecx
 72b:	74 3a                	je     767 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 72d:	89 08                	mov    %ecx,(%eax)
  } else
    p->s.ptr = bp;
  freep = p;
}
 72f:	5b                   	pop    %ebx
  freep = p;
 730:	a3 24 0d 00 00       	mov    %eax,0xd24
}
 735:	5e                   	pop    %esi
 736:	5f                   	pop    %edi
 737:	5d                   	pop    %ebp
 738:	c3                   	ret
 739:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 740:	39 d0                	cmp    %edx,%eax
 742:	72 04                	jb     748 <free+0x58>
 744:	39 d1                	cmp    %edx,%ecx
 746:	72 ce                	jb     716 <free+0x26>
{
 748:	89 d0                	mov    %edx,%eax
 74a:	eb bc                	jmp    708 <free+0x18>
 74c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 750:	03 72 04             	add    0x4(%edx),%esi
 753:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 756:	8b 10                	mov    (%eax),%edx
 758:	8b 12                	mov    (%edx),%edx
 75a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 75d:	8b 50 04             	mov    0x4(%eax),%edx
 760:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 763:	39 f1                	cmp    %esi,%ecx
 765:	75 c6                	jne    72d <free+0x3d>
    p->s.size += bp->s.size;
 767:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 76a:	a3 24 0d 00 00       	mov    %eax,0xd24
    p->s.size += bp->s.size;
 76f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 772:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 775:	89 08                	mov    %ecx,(%eax)
}
 777:	5b                   	pop    %ebx
 778:	5e                   	pop    %esi
 779:	5f                   	pop    %edi
 77a:	5d                   	pop    %ebp
 77b:	c3                   	ret
 77c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000780 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 780:	55                   	push   %ebp
 781:	89 e5                	mov    %esp,%ebp
 783:	57                   	push   %edi
 784:	56                   	push   %esi
 785:	53                   	push   %ebx
 786:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 789:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 78c:	8b 15 24 0d 00 00    	mov    0xd24,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 792:	8d 78 07             	lea    0x7(%eax),%edi
 795:	c1 ef 03             	shr    $0x3,%edi
 798:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 79b:	85 d2                	test   %edx,%edx
 79d:	0f 84 8d 00 00 00    	je     830 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7a3:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 7a5:	8b 48 04             	mov    0x4(%eax),%ecx
 7a8:	39 f9                	cmp    %edi,%ecx
 7aa:	73 64                	jae    810 <malloc+0x90>
  if(nu < 4096)
 7ac:	bb 00 10 00 00       	mov    $0x1000,%ebx
 7b1:	39 df                	cmp    %ebx,%edi
 7b3:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 7b6:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 7bd:	eb 0a                	jmp    7c9 <malloc+0x49>
 7bf:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7c0:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 7c2:	8b 48 04             	mov    0x4(%eax),%ecx
 7c5:	39 f9                	cmp    %edi,%ecx
 7c7:	73 47                	jae    810 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7c9:	89 c2                	mov    %eax,%edx
 7cb:	3b 05 24 0d 00 00    	cmp    0xd24,%eax
 7d1:	75 ed                	jne    7c0 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 7d3:	83 ec 0c             	sub    $0xc,%esp
 7d6:	56                   	push   %esi
 7d7:	e8 6f fc ff ff       	call   44b <sbrk>
  if(p == (char*)-1)
 7dc:	83 c4 10             	add    $0x10,%esp
 7df:	83 f8 ff             	cmp    $0xffffffff,%eax
 7e2:	74 1c                	je     800 <malloc+0x80>
  hp->s.size = nu;
 7e4:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 7e7:	83 ec 0c             	sub    $0xc,%esp
 7ea:	83 c0 08             	add    $0x8,%eax
 7ed:	50                   	push   %eax
 7ee:	e8 fd fe ff ff       	call   6f0 <free>
  return freep;
 7f3:	8b 15 24 0d 00 00    	mov    0xd24,%edx
      if((p = morecore(nunits)) == 0)
 7f9:	83 c4 10             	add    $0x10,%esp
 7fc:	85 d2                	test   %edx,%edx
 7fe:	75 c0                	jne    7c0 <malloc+0x40>
        return 0;
  }
}
 800:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 803:	31 c0                	xor    %eax,%eax
}
 805:	5b                   	pop    %ebx
 806:	5e                   	pop    %esi
 807:	5f                   	pop    %edi
 808:	5d                   	pop    %ebp
 809:	c3                   	ret
 80a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 810:	39 cf                	cmp    %ecx,%edi
 812:	74 4c                	je     860 <malloc+0xe0>
        p->s.size -= nunits;
 814:	29 f9                	sub    %edi,%ecx
 816:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 819:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 81c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 81f:	89 15 24 0d 00 00    	mov    %edx,0xd24
}
 825:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 828:	83 c0 08             	add    $0x8,%eax
}
 82b:	5b                   	pop    %ebx
 82c:	5e                   	pop    %esi
 82d:	5f                   	pop    %edi
 82e:	5d                   	pop    %ebp
 82f:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 830:	c7 05 24 0d 00 00 28 	movl   $0xd28,0xd24
 837:	0d 00 00 
    base.s.size = 0;
 83a:	b8 28 0d 00 00       	mov    $0xd28,%eax
    base.s.ptr = freep = prevp = &base;
 83f:	c7 05 28 0d 00 00 28 	movl   $0xd28,0xd28
 846:	0d 00 00 
    base.s.size = 0;
 849:	c7 05 2c 0d 00 00 00 	movl   $0x0,0xd2c
 850:	00 00 00 
    if(p->s.size >= nunits){
 853:	e9 54 ff ff ff       	jmp    7ac <malloc+0x2c>
 858:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 85f:	00 
        prevp->s.ptr = p->s.ptr;
 860:	8b 08                	mov    (%eax),%ecx
 862:	89 0a                	mov    %ecx,(%edx)
 864:	eb b9                	jmp    81f <malloc+0x9f>
