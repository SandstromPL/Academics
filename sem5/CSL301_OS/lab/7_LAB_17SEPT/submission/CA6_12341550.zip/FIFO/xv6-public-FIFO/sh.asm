
_sh:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  return 0;
}

int
main(void)
{
       0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
       4:	83 e4 f0             	and    $0xfffffff0,%esp
       7:	ff 71 fc             	push   -0x4(%ecx)
       a:	55                   	push   %ebp
       b:	89 e5                	mov    %esp,%ebp
       d:	51                   	push   %ecx
       e:	83 ec 04             	sub    $0x4,%esp
  static char buf[100];
  int fd;

  // Ensure that three file descriptors are open.
  while((fd = open("console", O_RDWR)) >= 0){
      11:	eb 0e                	jmp    21 <main+0x21>
      13:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(fd >= 3){
      18:	83 f8 02             	cmp    $0x2,%eax
      1b:	0f 8f 96 00 00 00    	jg     b7 <main+0xb7>
  while((fd = open("console", O_RDWR)) >= 0){
      21:	83 ec 08             	sub    $0x8,%esp
      24:	6a 02                	push   $0x2
      26:	68 f5 13 00 00       	push   $0x13f5
      2b:	e8 a3 0e 00 00       	call   ed3 <open>
      30:	83 c4 10             	add    $0x10,%esp
      33:	85 c0                	test   %eax,%eax
      35:	79 e1                	jns    18 <main+0x18>
      37:	eb 2e                	jmp    67 <main+0x67>
      39:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    }
  }

  // Read and run input commands.
  while(getcmd(buf, sizeof(buf)) >= 0){
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
      40:	80 3d 42 1b 00 00 20 	cmpb   $0x20,0x1b42
      47:	0f 84 8d 00 00 00    	je     da <main+0xda>
      4d:	8d 76 00             	lea    0x0(%esi),%esi
int
fork1(void)
{
  int pid;

  pid = fork();
      50:	e8 36 0e 00 00       	call   e8b <fork>
  if(pid == -1)
      55:	83 f8 ff             	cmp    $0xffffffff,%eax
      58:	0f 84 c1 00 00 00    	je     11f <main+0x11f>
    if(fork1() == 0)
      5e:	85 c0                	test   %eax,%eax
      60:	74 63                	je     c5 <main+0xc5>
    wait();
      62:	e8 34 0e 00 00       	call   e9b <wait>
  printf(2, "12341550$ "); // CA2-part2-Q1
      67:	83 ec 08             	sub    $0x8,%esp
      6a:	68 38 13 00 00       	push   $0x1338
      6f:	6a 02                	push   $0x2
      71:	e8 ba 0f 00 00       	call   1030 <printf>
  memset(buf, 0, nbuf);
      76:	83 c4 0c             	add    $0xc,%esp
      79:	6a 64                	push   $0x64
      7b:	6a 00                	push   $0x0
      7d:	68 40 1b 00 00       	push   $0x1b40
      82:	e8 89 0c 00 00       	call   d10 <memset>
  gets(buf, nbuf);
      87:	58                   	pop    %eax
      88:	5a                   	pop    %edx
      89:	6a 64                	push   $0x64
      8b:	68 40 1b 00 00       	push   $0x1b40
      90:	e8 db 0c 00 00       	call   d70 <gets>
  if(buf[0] == 0) // EOF
      95:	0f b6 05 40 1b 00 00 	movzbl 0x1b40,%eax
      9c:	83 c4 10             	add    $0x10,%esp
      9f:	84 c0                	test   %al,%al
      a1:	74 0f                	je     b2 <main+0xb2>
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
      a3:	3c 63                	cmp    $0x63,%al
      a5:	75 a9                	jne    50 <main+0x50>
      a7:	80 3d 41 1b 00 00 64 	cmpb   $0x64,0x1b41
      ae:	75 a0                	jne    50 <main+0x50>
      b0:	eb 8e                	jmp    40 <main+0x40>
  exit();
      b2:	e8 dc 0d 00 00       	call   e93 <exit>
      close(fd);
      b7:	83 ec 0c             	sub    $0xc,%esp
      ba:	50                   	push   %eax
      bb:	e8 fb 0d 00 00       	call   ebb <close>
      break;
      c0:	83 c4 10             	add    $0x10,%esp
      c3:	eb a2                	jmp    67 <main+0x67>
      runcmd(parsecmd(buf));
      c5:	83 ec 0c             	sub    $0xc,%esp
      c8:	68 40 1b 00 00       	push   $0x1b40
      cd:	e8 0e 0b 00 00       	call   be0 <parsecmd>
      d2:	89 04 24             	mov    %eax,(%esp)
      d5:	e8 d6 00 00 00       	call   1b0 <runcmd>
      buf[strlen(buf)-1] = 0;  // chop \n
      da:	83 ec 0c             	sub    $0xc,%esp
      dd:	68 40 1b 00 00       	push   $0x1b40
      e2:	e8 f9 0b 00 00       	call   ce0 <strlen>
      if(chdir(buf+3) < 0)
      e7:	c7 04 24 43 1b 00 00 	movl   $0x1b43,(%esp)
      buf[strlen(buf)-1] = 0;  // chop \n
      ee:	c6 80 3f 1b 00 00 00 	movb   $0x0,0x1b3f(%eax)
      if(chdir(buf+3) < 0)
      f5:	e8 09 0e 00 00       	call   f03 <chdir>
      fa:	83 c4 10             	add    $0x10,%esp
      fd:	85 c0                	test   %eax,%eax
      ff:	0f 89 62 ff ff ff    	jns    67 <main+0x67>
        printf(2, "cannot cd %s\n", buf+3);
     105:	51                   	push   %ecx
     106:	68 43 1b 00 00       	push   $0x1b43
     10b:	68 fd 13 00 00       	push   $0x13fd
     110:	6a 02                	push   $0x2
     112:	e8 19 0f 00 00       	call   1030 <printf>
     117:	83 c4 10             	add    $0x10,%esp
     11a:	e9 48 ff ff ff       	jmp    67 <main+0x67>
    panic("fork");
     11f:	83 ec 0c             	sub    $0xc,%esp
     122:	68 43 13 00 00       	push   $0x1343
     127:	e8 44 00 00 00       	call   170 <panic>
     12c:	66 90                	xchg   %ax,%ax
     12e:	66 90                	xchg   %ax,%ax

00000130 <getcmd>:
{
     130:	55                   	push   %ebp
     131:	89 e5                	mov    %esp,%ebp
     133:	56                   	push   %esi
     134:	53                   	push   %ebx
     135:	8b 5d 08             	mov    0x8(%ebp),%ebx
     138:	8b 75 0c             	mov    0xc(%ebp),%esi
  printf(2, "12341550$ "); // CA2-part2-Q1
     13b:	83 ec 08             	sub    $0x8,%esp
     13e:	68 38 13 00 00       	push   $0x1338
     143:	6a 02                	push   $0x2
     145:	e8 e6 0e 00 00       	call   1030 <printf>
  memset(buf, 0, nbuf);
     14a:	83 c4 0c             	add    $0xc,%esp
     14d:	56                   	push   %esi
     14e:	6a 00                	push   $0x0
     150:	53                   	push   %ebx
     151:	e8 ba 0b 00 00       	call   d10 <memset>
  gets(buf, nbuf);
     156:	58                   	pop    %eax
     157:	5a                   	pop    %edx
     158:	56                   	push   %esi
     159:	53                   	push   %ebx
     15a:	e8 11 0c 00 00       	call   d70 <gets>
  if(buf[0] == 0) // EOF
     15f:	83 c4 10             	add    $0x10,%esp
     162:	80 3b 01             	cmpb   $0x1,(%ebx)
     165:	19 c0                	sbb    %eax,%eax
}
     167:	8d 65 f8             	lea    -0x8(%ebp),%esp
     16a:	5b                   	pop    %ebx
     16b:	5e                   	pop    %esi
     16c:	5d                   	pop    %ebp
     16d:	c3                   	ret
     16e:	66 90                	xchg   %ax,%ax

00000170 <panic>:
{
     170:	55                   	push   %ebp
     171:	89 e5                	mov    %esp,%ebp
     173:	83 ec 0c             	sub    $0xc,%esp
  printf(2, "%s\n", s);
     176:	ff 75 08             	push   0x8(%ebp)
     179:	68 f1 13 00 00       	push   $0x13f1
     17e:	6a 02                	push   $0x2
     180:	e8 ab 0e 00 00       	call   1030 <printf>
  exit();
     185:	e8 09 0d 00 00       	call   e93 <exit>
     18a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000190 <fork1>:
{
     190:	55                   	push   %ebp
     191:	89 e5                	mov    %esp,%ebp
     193:	83 ec 08             	sub    $0x8,%esp
  pid = fork();
     196:	e8 f0 0c 00 00       	call   e8b <fork>
  if(pid == -1)
     19b:	83 f8 ff             	cmp    $0xffffffff,%eax
     19e:	74 02                	je     1a2 <fork1+0x12>
  return pid;
}
     1a0:	c9                   	leave
     1a1:	c3                   	ret
    panic("fork");
     1a2:	83 ec 0c             	sub    $0xc,%esp
     1a5:	68 43 13 00 00       	push   $0x1343
     1aa:	e8 c1 ff ff ff       	call   170 <panic>
     1af:	90                   	nop

000001b0 <runcmd>:
{
     1b0:	55                   	push   %ebp
     1b1:	89 e5                	mov    %esp,%ebp
     1b3:	53                   	push   %ebx
     1b4:	83 ec 14             	sub    $0x14,%esp
     1b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(cmd == 0)
     1ba:	85 db                	test   %ebx,%ebx
     1bc:	74 1f                	je     1dd <runcmd+0x2d>
  switch(cmd->type){
     1be:	83 3b 05             	cmpl   $0x5,(%ebx)
     1c1:	0f 87 04 01 00 00    	ja     2cb <runcmd+0x11b>
     1c7:	8b 03                	mov    (%ebx),%eax
     1c9:	ff 24 85 c4 14 00 00 	jmp    *0x14c4(,%eax,4)
    if(fork1() == 0)
     1d0:	e8 bb ff ff ff       	call   190 <fork1>
     1d5:	85 c0                	test   %eax,%eax
     1d7:	0f 84 e3 00 00 00    	je     2c0 <runcmd+0x110>
    exit();
     1dd:	e8 b1 0c 00 00       	call   e93 <exit>
    if(ecmd->argv[0] == 0)
     1e2:	8b 43 04             	mov    0x4(%ebx),%eax
     1e5:	85 c0                	test   %eax,%eax
     1e7:	74 f4                	je     1dd <runcmd+0x2d>
    if(strcmp(ecmd->argv[0],"touch") == 0){
     1e9:	52                   	push   %edx
     1ea:	52                   	push   %edx
     1eb:	68 4f 13 00 00       	push   $0x134f
     1f0:	50                   	push   %eax
     1f1:	e8 8a 0a 00 00       	call   c80 <strcmp>
     1f6:	83 c4 10             	add    $0x10,%esp
     1f9:	85 c0                	test   %eax,%eax
     1fb:	0f 85 f9 00 00 00    	jne    2fa <runcmd+0x14a>
      int fd = open(ecmd->argv[1], O_CREATE | O_WRONLY);
     201:	50                   	push   %eax
     202:	50                   	push   %eax
     203:	68 01 02 00 00       	push   $0x201
     208:	ff 73 08             	push   0x8(%ebx)
     20b:	e8 c3 0c 00 00       	call   ed3 <open>
        if(fd < 0){
     210:	83 c4 10             	add    $0x10,%esp
     213:	85 c0                	test   %eax,%eax
     215:	0f 88 84 01 00 00    	js     39f <runcmd+0x1ef>
        close(fd);
     21b:	83 ec 0c             	sub    $0xc,%esp
     21e:	50                   	push   %eax
     21f:	e8 97 0c 00 00       	call   ebb <close>
        exit();
     224:	e8 6a 0c 00 00       	call   e93 <exit>
    if(pipe(p) < 0)
     229:	83 ec 0c             	sub    $0xc,%esp
     22c:	8d 45 f0             	lea    -0x10(%ebp),%eax
     22f:	50                   	push   %eax
     230:	e8 6e 0c 00 00       	call   ea3 <pipe>
     235:	83 c4 10             	add    $0x10,%esp
     238:	85 c0                	test   %eax,%eax
     23a:	0f 88 ad 00 00 00    	js     2ed <runcmd+0x13d>
    if(fork1() == 0){
     240:	e8 4b ff ff ff       	call   190 <fork1>
     245:	85 c0                	test   %eax,%eax
     247:	0f 84 d6 00 00 00    	je     323 <runcmd+0x173>
    if(fork1() == 0){
     24d:	e8 3e ff ff ff       	call   190 <fork1>
     252:	85 c0                	test   %eax,%eax
     254:	0f 85 1f 01 00 00    	jne    379 <runcmd+0x1c9>
      close(0);
     25a:	83 ec 0c             	sub    $0xc,%esp
     25d:	6a 00                	push   $0x0
     25f:	e8 57 0c 00 00       	call   ebb <close>
      dup(p[0]);
     264:	5a                   	pop    %edx
     265:	ff 75 f0             	push   -0x10(%ebp)
     268:	e8 9e 0c 00 00       	call   f0b <dup>
      close(p[0]);
     26d:	59                   	pop    %ecx
     26e:	ff 75 f0             	push   -0x10(%ebp)
     271:	e8 45 0c 00 00       	call   ebb <close>
      close(p[1]);
     276:	58                   	pop    %eax
     277:	ff 75 f4             	push   -0xc(%ebp)
     27a:	e8 3c 0c 00 00       	call   ebb <close>
      runcmd(pcmd->right);
     27f:	58                   	pop    %eax
     280:	ff 73 08             	push   0x8(%ebx)
     283:	e8 28 ff ff ff       	call   1b0 <runcmd>
    if(fork1() == 0)
     288:	e8 03 ff ff ff       	call   190 <fork1>
     28d:	85 c0                	test   %eax,%eax
     28f:	74 2f                	je     2c0 <runcmd+0x110>
    wait();
     291:	e8 05 0c 00 00       	call   e9b <wait>
    runcmd(lcmd->right);
     296:	83 ec 0c             	sub    $0xc,%esp
     299:	ff 73 08             	push   0x8(%ebx)
     29c:	e8 0f ff ff ff       	call   1b0 <runcmd>
    close(rcmd->fd);
     2a1:	83 ec 0c             	sub    $0xc,%esp
     2a4:	ff 73 14             	push   0x14(%ebx)
     2a7:	e8 0f 0c 00 00       	call   ebb <close>
    if(open(rcmd->file, rcmd->mode) < 0){
     2ac:	58                   	pop    %eax
     2ad:	5a                   	pop    %edx
     2ae:	ff 73 10             	push   0x10(%ebx)
     2b1:	ff 73 08             	push   0x8(%ebx)
     2b4:	e8 1a 0c 00 00       	call   ed3 <open>
     2b9:	83 c4 10             	add    $0x10,%esp
     2bc:	85 c0                	test   %eax,%eax
     2be:	78 18                	js     2d8 <runcmd+0x128>
      runcmd(bcmd->cmd);
     2c0:	83 ec 0c             	sub    $0xc,%esp
     2c3:	ff 73 04             	push   0x4(%ebx)
     2c6:	e8 e5 fe ff ff       	call   1b0 <runcmd>
    panic("runcmd");
     2cb:	83 ec 0c             	sub    $0xc,%esp
     2ce:	68 48 13 00 00       	push   $0x1348
     2d3:	e8 98 fe ff ff       	call   170 <panic>
      printf(2, "open %s failed\n", rcmd->file);
     2d8:	51                   	push   %ecx
     2d9:	ff 73 08             	push   0x8(%ebx)
     2dc:	68 73 13 00 00       	push   $0x1373
     2e1:	6a 02                	push   $0x2
     2e3:	e8 48 0d 00 00       	call   1030 <printf>
      exit();
     2e8:	e8 a6 0b 00 00       	call   e93 <exit>
      panic("pipe");
     2ed:	83 ec 0c             	sub    $0xc,%esp
     2f0:	68 83 13 00 00       	push   $0x1383
     2f5:	e8 76 fe ff ff       	call   170 <panic>
    if(strcmp(ecmd->argv[0],"help") == 0){
     2fa:	50                   	push   %eax
     2fb:	50                   	push   %eax
     2fc:	68 6e 13 00 00       	push   $0x136e
     301:	ff 73 04             	push   0x4(%ebx)
     304:	e8 77 09 00 00       	call   c80 <strcmp>
     309:	83 c4 10             	add    $0x10,%esp
     30c:	85 c0                	test   %eax,%eax
     30e:	75 41                	jne    351 <runcmd+0x1a1>
      printf(1,
     310:	53                   	push   %ebx
     311:	53                   	push   %ebx
     312:	68 14 14 00 00       	push   $0x1414
     317:	6a 01                	push   $0x1
     319:	e8 12 0d 00 00       	call   1030 <printf>
      exit();
     31e:	e8 70 0b 00 00       	call   e93 <exit>
      close(1);
     323:	83 ec 0c             	sub    $0xc,%esp
     326:	6a 01                	push   $0x1
     328:	e8 8e 0b 00 00       	call   ebb <close>
      dup(p[1]);
     32d:	58                   	pop    %eax
     32e:	ff 75 f4             	push   -0xc(%ebp)
     331:	e8 d5 0b 00 00       	call   f0b <dup>
      close(p[0]);
     336:	58                   	pop    %eax
     337:	ff 75 f0             	push   -0x10(%ebp)
     33a:	e8 7c 0b 00 00       	call   ebb <close>
      close(p[1]);
     33f:	58                   	pop    %eax
     340:	ff 75 f4             	push   -0xc(%ebp)
     343:	e8 73 0b 00 00       	call   ebb <close>
      runcmd(pcmd->left);
     348:	5a                   	pop    %edx
     349:	ff 73 04             	push   0x4(%ebx)
     34c:	e8 5f fe ff ff       	call   1b0 <runcmd>
    exec(ecmd->argv[0], ecmd->argv);
     351:	8d 43 04             	lea    0x4(%ebx),%eax
     354:	51                   	push   %ecx
     355:	51                   	push   %ecx
     356:	50                   	push   %eax
     357:	ff 73 04             	push   0x4(%ebx)
     35a:	e8 6c 0b 00 00       	call   ecb <exec>
    printf(2, "Unknown command or exec falied : %s\n", ecmd->argv[0]); // CA2-part2-Q3
     35f:	83 c4 0c             	add    $0xc,%esp
     362:	ff 73 04             	push   0x4(%ebx)
     365:	68 9c 14 00 00       	push   $0x149c
     36a:	6a 02                	push   $0x2
     36c:	e8 bf 0c 00 00       	call   1030 <printf>
    break;
     371:	83 c4 10             	add    $0x10,%esp
     374:	e9 64 fe ff ff       	jmp    1dd <runcmd+0x2d>
    close(p[0]);
     379:	83 ec 0c             	sub    $0xc,%esp
     37c:	ff 75 f0             	push   -0x10(%ebp)
     37f:	e8 37 0b 00 00       	call   ebb <close>
    close(p[1]);
     384:	58                   	pop    %eax
     385:	ff 75 f4             	push   -0xc(%ebp)
     388:	e8 2e 0b 00 00       	call   ebb <close>
    wait();
     38d:	e8 09 0b 00 00       	call   e9b <wait>
    wait();
     392:	e8 04 0b 00 00       	call   e9b <wait>
    break;
     397:	83 c4 10             	add    $0x10,%esp
     39a:	e9 3e fe ff ff       	jmp    1dd <runcmd+0x2d>
            printf(2, "touch: cannot create %s\n", ecmd->argv[1]);
     39f:	50                   	push   %eax
     3a0:	ff 73 08             	push   0x8(%ebx)
     3a3:	68 55 13 00 00       	push   $0x1355
     3a8:	6a 02                	push   $0x2
     3aa:	e8 81 0c 00 00       	call   1030 <printf>
            exit();
     3af:	e8 df 0a 00 00       	call   e93 <exit>
     3b4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     3bb:	00 
     3bc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003c0 <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
     3c0:	55                   	push   %ebp
     3c1:	89 e5                	mov    %esp,%ebp
     3c3:	53                   	push   %ebx
     3c4:	83 ec 10             	sub    $0x10,%esp
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     3c7:	6a 54                	push   $0x54
     3c9:	e8 82 0e 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     3ce:	83 c4 0c             	add    $0xc,%esp
     3d1:	6a 54                	push   $0x54
  cmd = malloc(sizeof(*cmd));
     3d3:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
     3d5:	6a 00                	push   $0x0
     3d7:	50                   	push   %eax
     3d8:	e8 33 09 00 00       	call   d10 <memset>
  cmd->type = EXEC;
     3dd:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  return (struct cmd*)cmd;
}
     3e3:	89 d8                	mov    %ebx,%eax
     3e5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     3e8:	c9                   	leave
     3e9:	c3                   	ret
     3ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

000003f0 <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
     3f0:	55                   	push   %ebp
     3f1:	89 e5                	mov    %esp,%ebp
     3f3:	53                   	push   %ebx
     3f4:	83 ec 10             	sub    $0x10,%esp
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
     3f7:	6a 18                	push   $0x18
     3f9:	e8 52 0e 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     3fe:	83 c4 0c             	add    $0xc,%esp
     401:	6a 18                	push   $0x18
  cmd = malloc(sizeof(*cmd));
     403:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
     405:	6a 00                	push   $0x0
     407:	50                   	push   %eax
     408:	e8 03 09 00 00       	call   d10 <memset>
  cmd->type = REDIR;
  cmd->cmd = subcmd;
     40d:	8b 45 08             	mov    0x8(%ebp),%eax
  cmd->type = REDIR;
     410:	c7 03 02 00 00 00    	movl   $0x2,(%ebx)
  cmd->cmd = subcmd;
     416:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->file = file;
     419:	8b 45 0c             	mov    0xc(%ebp),%eax
     41c:	89 43 08             	mov    %eax,0x8(%ebx)
  cmd->efile = efile;
     41f:	8b 45 10             	mov    0x10(%ebp),%eax
     422:	89 43 0c             	mov    %eax,0xc(%ebx)
  cmd->mode = mode;
     425:	8b 45 14             	mov    0x14(%ebp),%eax
     428:	89 43 10             	mov    %eax,0x10(%ebx)
  cmd->fd = fd;
     42b:	8b 45 18             	mov    0x18(%ebp),%eax
     42e:	89 43 14             	mov    %eax,0x14(%ebx)
  return (struct cmd*)cmd;
}
     431:	89 d8                	mov    %ebx,%eax
     433:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     436:	c9                   	leave
     437:	c3                   	ret
     438:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     43f:	00 

00000440 <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
     440:	55                   	push   %ebp
     441:	89 e5                	mov    %esp,%ebp
     443:	53                   	push   %ebx
     444:	83 ec 10             	sub    $0x10,%esp
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
     447:	6a 0c                	push   $0xc
     449:	e8 02 0e 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     44e:	83 c4 0c             	add    $0xc,%esp
     451:	6a 0c                	push   $0xc
  cmd = malloc(sizeof(*cmd));
     453:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
     455:	6a 00                	push   $0x0
     457:	50                   	push   %eax
     458:	e8 b3 08 00 00       	call   d10 <memset>
  cmd->type = PIPE;
  cmd->left = left;
     45d:	8b 45 08             	mov    0x8(%ebp),%eax
  cmd->type = PIPE;
     460:	c7 03 03 00 00 00    	movl   $0x3,(%ebx)
  cmd->left = left;
     466:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->right = right;
     469:	8b 45 0c             	mov    0xc(%ebp),%eax
     46c:	89 43 08             	mov    %eax,0x8(%ebx)
  return (struct cmd*)cmd;
}
     46f:	89 d8                	mov    %ebx,%eax
     471:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     474:	c9                   	leave
     475:	c3                   	ret
     476:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     47d:	00 
     47e:	66 90                	xchg   %ax,%ax

00000480 <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
     480:	55                   	push   %ebp
     481:	89 e5                	mov    %esp,%ebp
     483:	53                   	push   %ebx
     484:	83 ec 10             	sub    $0x10,%esp
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     487:	6a 0c                	push   $0xc
     489:	e8 c2 0d 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     48e:	83 c4 0c             	add    $0xc,%esp
     491:	6a 0c                	push   $0xc
  cmd = malloc(sizeof(*cmd));
     493:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
     495:	6a 00                	push   $0x0
     497:	50                   	push   %eax
     498:	e8 73 08 00 00       	call   d10 <memset>
  cmd->type = LIST;
  cmd->left = left;
     49d:	8b 45 08             	mov    0x8(%ebp),%eax
  cmd->type = LIST;
     4a0:	c7 03 04 00 00 00    	movl   $0x4,(%ebx)
  cmd->left = left;
     4a6:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->right = right;
     4a9:	8b 45 0c             	mov    0xc(%ebp),%eax
     4ac:	89 43 08             	mov    %eax,0x8(%ebx)
  return (struct cmd*)cmd;
}
     4af:	89 d8                	mov    %ebx,%eax
     4b1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     4b4:	c9                   	leave
     4b5:	c3                   	ret
     4b6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     4bd:	00 
     4be:	66 90                	xchg   %ax,%ax

000004c0 <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
     4c0:	55                   	push   %ebp
     4c1:	89 e5                	mov    %esp,%ebp
     4c3:	53                   	push   %ebx
     4c4:	83 ec 10             	sub    $0x10,%esp
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     4c7:	6a 08                	push   $0x8
     4c9:	e8 82 0d 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     4ce:	83 c4 0c             	add    $0xc,%esp
     4d1:	6a 08                	push   $0x8
  cmd = malloc(sizeof(*cmd));
     4d3:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
     4d5:	6a 00                	push   $0x0
     4d7:	50                   	push   %eax
     4d8:	e8 33 08 00 00       	call   d10 <memset>
  cmd->type = BACK;
  cmd->cmd = subcmd;
     4dd:	8b 45 08             	mov    0x8(%ebp),%eax
  cmd->type = BACK;
     4e0:	c7 03 05 00 00 00    	movl   $0x5,(%ebx)
  cmd->cmd = subcmd;
     4e6:	89 43 04             	mov    %eax,0x4(%ebx)
  return (struct cmd*)cmd;
}
     4e9:	89 d8                	mov    %ebx,%eax
     4eb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     4ee:	c9                   	leave
     4ef:	c3                   	ret

000004f0 <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
     4f0:	55                   	push   %ebp
     4f1:	89 e5                	mov    %esp,%ebp
     4f3:	57                   	push   %edi
     4f4:	56                   	push   %esi
     4f5:	53                   	push   %ebx
     4f6:	83 ec 0c             	sub    $0xc,%esp
  char *s;
  int ret;

  s = *ps;
     4f9:	8b 45 08             	mov    0x8(%ebp),%eax
{
     4fc:	8b 5d 0c             	mov    0xc(%ebp),%ebx
     4ff:	8b 75 10             	mov    0x10(%ebp),%esi
  s = *ps;
     502:	8b 38                	mov    (%eax),%edi
  while(s < es && strchr(whitespace, *s))
     504:	39 df                	cmp    %ebx,%edi
     506:	72 0f                	jb     517 <gettoken+0x27>
     508:	eb 25                	jmp    52f <gettoken+0x3f>
     50a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    s++;
     510:	83 c7 01             	add    $0x1,%edi
  while(s < es && strchr(whitespace, *s))
     513:	39 fb                	cmp    %edi,%ebx
     515:	74 18                	je     52f <gettoken+0x3f>
     517:	0f be 07             	movsbl (%edi),%eax
     51a:	83 ec 08             	sub    $0x8,%esp
     51d:	50                   	push   %eax
     51e:	68 1c 1b 00 00       	push   $0x1b1c
     523:	e8 08 08 00 00       	call   d30 <strchr>
     528:	83 c4 10             	add    $0x10,%esp
     52b:	85 c0                	test   %eax,%eax
     52d:	75 e1                	jne    510 <gettoken+0x20>
  if(q)
     52f:	85 f6                	test   %esi,%esi
     531:	74 02                	je     535 <gettoken+0x45>
    *q = s;
     533:	89 3e                	mov    %edi,(%esi)
  ret = *s;
     535:	0f b6 07             	movzbl (%edi),%eax
  switch(*s){
     538:	3c 3c                	cmp    $0x3c,%al
     53a:	0f 8f c8 00 00 00    	jg     608 <gettoken+0x118>
     540:	3c 3a                	cmp    $0x3a,%al
     542:	7f 5a                	jg     59e <gettoken+0xae>
     544:	84 c0                	test   %al,%al
     546:	75 48                	jne    590 <gettoken+0xa0>
     548:	31 f6                	xor    %esi,%esi
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if(eq)
     54a:	8b 4d 14             	mov    0x14(%ebp),%ecx
     54d:	85 c9                	test   %ecx,%ecx
     54f:	74 05                	je     556 <gettoken+0x66>
    *eq = s;
     551:	8b 45 14             	mov    0x14(%ebp),%eax
     554:	89 38                	mov    %edi,(%eax)

  while(s < es && strchr(whitespace, *s))
     556:	39 df                	cmp    %ebx,%edi
     558:	72 0d                	jb     567 <gettoken+0x77>
     55a:	eb 23                	jmp    57f <gettoken+0x8f>
     55c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    s++;
     560:	83 c7 01             	add    $0x1,%edi
  while(s < es && strchr(whitespace, *s))
     563:	39 fb                	cmp    %edi,%ebx
     565:	74 18                	je     57f <gettoken+0x8f>
     567:	0f be 07             	movsbl (%edi),%eax
     56a:	83 ec 08             	sub    $0x8,%esp
     56d:	50                   	push   %eax
     56e:	68 1c 1b 00 00       	push   $0x1b1c
     573:	e8 b8 07 00 00       	call   d30 <strchr>
     578:	83 c4 10             	add    $0x10,%esp
     57b:	85 c0                	test   %eax,%eax
     57d:	75 e1                	jne    560 <gettoken+0x70>
  *ps = s;
     57f:	8b 45 08             	mov    0x8(%ebp),%eax
     582:	89 38                	mov    %edi,(%eax)
  return ret;
}
     584:	8d 65 f4             	lea    -0xc(%ebp),%esp
     587:	89 f0                	mov    %esi,%eax
     589:	5b                   	pop    %ebx
     58a:	5e                   	pop    %esi
     58b:	5f                   	pop    %edi
     58c:	5d                   	pop    %ebp
     58d:	c3                   	ret
     58e:	66 90                	xchg   %ax,%ax
  switch(*s){
     590:	78 22                	js     5b4 <gettoken+0xc4>
     592:	3c 26                	cmp    $0x26,%al
     594:	74 08                	je     59e <gettoken+0xae>
     596:	8d 48 d8             	lea    -0x28(%eax),%ecx
     599:	80 f9 01             	cmp    $0x1,%cl
     59c:	77 16                	ja     5b4 <gettoken+0xc4>
  ret = *s;
     59e:	0f be f0             	movsbl %al,%esi
    s++;
     5a1:	83 c7 01             	add    $0x1,%edi
    break;
     5a4:	eb a4                	jmp    54a <gettoken+0x5a>
     5a6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     5ad:	00 
     5ae:	66 90                	xchg   %ax,%ax
  switch(*s){
     5b0:	3c 7c                	cmp    $0x7c,%al
     5b2:	74 ea                	je     59e <gettoken+0xae>
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     5b4:	39 df                	cmp    %ebx,%edi
     5b6:	72 27                	jb     5df <gettoken+0xef>
     5b8:	e9 87 00 00 00       	jmp    644 <gettoken+0x154>
     5bd:	8d 76 00             	lea    0x0(%esi),%esi
     5c0:	0f be 07             	movsbl (%edi),%eax
     5c3:	83 ec 08             	sub    $0x8,%esp
     5c6:	50                   	push   %eax
     5c7:	68 14 1b 00 00       	push   $0x1b14
     5cc:	e8 5f 07 00 00       	call   d30 <strchr>
     5d1:	83 c4 10             	add    $0x10,%esp
     5d4:	85 c0                	test   %eax,%eax
     5d6:	75 1f                	jne    5f7 <gettoken+0x107>
      s++;
     5d8:	83 c7 01             	add    $0x1,%edi
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     5db:	39 fb                	cmp    %edi,%ebx
     5dd:	74 4d                	je     62c <gettoken+0x13c>
     5df:	0f be 07             	movsbl (%edi),%eax
     5e2:	83 ec 08             	sub    $0x8,%esp
     5e5:	50                   	push   %eax
     5e6:	68 1c 1b 00 00       	push   $0x1b1c
     5eb:	e8 40 07 00 00       	call   d30 <strchr>
     5f0:	83 c4 10             	add    $0x10,%esp
     5f3:	85 c0                	test   %eax,%eax
     5f5:	74 c9                	je     5c0 <gettoken+0xd0>
    ret = 'a';
     5f7:	be 61 00 00 00       	mov    $0x61,%esi
     5fc:	e9 49 ff ff ff       	jmp    54a <gettoken+0x5a>
     601:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  switch(*s){
     608:	3c 3e                	cmp    $0x3e,%al
     60a:	75 a4                	jne    5b0 <gettoken+0xc0>
    if(*s == '>'){
     60c:	80 7f 01 3e          	cmpb   $0x3e,0x1(%edi)
     610:	74 0d                	je     61f <gettoken+0x12f>
    s++;
     612:	83 c7 01             	add    $0x1,%edi
  ret = *s;
     615:	be 3e 00 00 00       	mov    $0x3e,%esi
     61a:	e9 2b ff ff ff       	jmp    54a <gettoken+0x5a>
      s++;
     61f:	83 c7 02             	add    $0x2,%edi
      ret = '+';
     622:	be 2b 00 00 00       	mov    $0x2b,%esi
     627:	e9 1e ff ff ff       	jmp    54a <gettoken+0x5a>
  if(eq)
     62c:	8b 45 14             	mov    0x14(%ebp),%eax
     62f:	85 c0                	test   %eax,%eax
     631:	74 05                	je     638 <gettoken+0x148>
    *eq = s;
     633:	8b 45 14             	mov    0x14(%ebp),%eax
     636:	89 18                	mov    %ebx,(%eax)
  while(s < es && strchr(whitespace, *s))
     638:	89 df                	mov    %ebx,%edi
    ret = 'a';
     63a:	be 61 00 00 00       	mov    $0x61,%esi
     63f:	e9 3b ff ff ff       	jmp    57f <gettoken+0x8f>
  if(eq)
     644:	8b 55 14             	mov    0x14(%ebp),%edx
     647:	85 d2                	test   %edx,%edx
     649:	74 ef                	je     63a <gettoken+0x14a>
    *eq = s;
     64b:	8b 45 14             	mov    0x14(%ebp),%eax
     64e:	89 38                	mov    %edi,(%eax)
  while(s < es && strchr(whitespace, *s))
     650:	eb e8                	jmp    63a <gettoken+0x14a>
     652:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     659:	00 
     65a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000660 <peek>:

int
peek(char **ps, char *es, char *toks)
{
     660:	55                   	push   %ebp
     661:	89 e5                	mov    %esp,%ebp
     663:	57                   	push   %edi
     664:	56                   	push   %esi
     665:	53                   	push   %ebx
     666:	83 ec 0c             	sub    $0xc,%esp
     669:	8b 7d 08             	mov    0x8(%ebp),%edi
     66c:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *s;

  s = *ps;
     66f:	8b 1f                	mov    (%edi),%ebx
  while(s < es && strchr(whitespace, *s))
     671:	39 f3                	cmp    %esi,%ebx
     673:	72 12                	jb     687 <peek+0x27>
     675:	eb 28                	jmp    69f <peek+0x3f>
     677:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     67e:	00 
     67f:	90                   	nop
    s++;
     680:	83 c3 01             	add    $0x1,%ebx
  while(s < es && strchr(whitespace, *s))
     683:	39 de                	cmp    %ebx,%esi
     685:	74 18                	je     69f <peek+0x3f>
     687:	0f be 03             	movsbl (%ebx),%eax
     68a:	83 ec 08             	sub    $0x8,%esp
     68d:	50                   	push   %eax
     68e:	68 1c 1b 00 00       	push   $0x1b1c
     693:	e8 98 06 00 00       	call   d30 <strchr>
     698:	83 c4 10             	add    $0x10,%esp
     69b:	85 c0                	test   %eax,%eax
     69d:	75 e1                	jne    680 <peek+0x20>
  *ps = s;
     69f:	89 1f                	mov    %ebx,(%edi)
  return *s && strchr(toks, *s);
     6a1:	0f be 03             	movsbl (%ebx),%eax
     6a4:	31 d2                	xor    %edx,%edx
     6a6:	84 c0                	test   %al,%al
     6a8:	75 0e                	jne    6b8 <peek+0x58>
}
     6aa:	8d 65 f4             	lea    -0xc(%ebp),%esp
     6ad:	89 d0                	mov    %edx,%eax
     6af:	5b                   	pop    %ebx
     6b0:	5e                   	pop    %esi
     6b1:	5f                   	pop    %edi
     6b2:	5d                   	pop    %ebp
     6b3:	c3                   	ret
     6b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return *s && strchr(toks, *s);
     6b8:	83 ec 08             	sub    $0x8,%esp
     6bb:	50                   	push   %eax
     6bc:	ff 75 10             	push   0x10(%ebp)
     6bf:	e8 6c 06 00 00       	call   d30 <strchr>
     6c4:	83 c4 10             	add    $0x10,%esp
     6c7:	31 d2                	xor    %edx,%edx
     6c9:	85 c0                	test   %eax,%eax
     6cb:	0f 95 c2             	setne  %dl
}
     6ce:	8d 65 f4             	lea    -0xc(%ebp),%esp
     6d1:	5b                   	pop    %ebx
     6d2:	89 d0                	mov    %edx,%eax
     6d4:	5e                   	pop    %esi
     6d5:	5f                   	pop    %edi
     6d6:	5d                   	pop    %ebp
     6d7:	c3                   	ret
     6d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     6df:	00 

000006e0 <parseredirs>:
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
     6e0:	55                   	push   %ebp
     6e1:	89 e5                	mov    %esp,%ebp
     6e3:	57                   	push   %edi
     6e4:	56                   	push   %esi
     6e5:	53                   	push   %ebx
     6e6:	83 ec 2c             	sub    $0x2c,%esp
     6e9:	8b 75 0c             	mov    0xc(%ebp),%esi
     6ec:	8b 5d 10             	mov    0x10(%ebp),%ebx
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
     6ef:	90                   	nop
     6f0:	83 ec 04             	sub    $0x4,%esp
     6f3:	68 a5 13 00 00       	push   $0x13a5
     6f8:	53                   	push   %ebx
     6f9:	56                   	push   %esi
     6fa:	e8 61 ff ff ff       	call   660 <peek>
     6ff:	83 c4 10             	add    $0x10,%esp
     702:	85 c0                	test   %eax,%eax
     704:	0f 84 f6 00 00 00    	je     800 <parseredirs+0x120>
    tok = gettoken(ps, es, 0, 0);
     70a:	6a 00                	push   $0x0
     70c:	6a 00                	push   $0x0
     70e:	53                   	push   %ebx
     70f:	56                   	push   %esi
     710:	e8 db fd ff ff       	call   4f0 <gettoken>
     715:	89 c7                	mov    %eax,%edi
    if(gettoken(ps, es, &q, &eq) != 'a')
     717:	8d 45 e4             	lea    -0x1c(%ebp),%eax
     71a:	50                   	push   %eax
     71b:	8d 45 e0             	lea    -0x20(%ebp),%eax
     71e:	50                   	push   %eax
     71f:	53                   	push   %ebx
     720:	56                   	push   %esi
     721:	e8 ca fd ff ff       	call   4f0 <gettoken>
     726:	83 c4 20             	add    $0x20,%esp
     729:	83 f8 61             	cmp    $0x61,%eax
     72c:	0f 85 d9 00 00 00    	jne    80b <parseredirs+0x12b>
      panic("missing file for redirection");
    switch(tok){
     732:	83 ff 3c             	cmp    $0x3c,%edi
     735:	74 69                	je     7a0 <parseredirs+0xc0>
     737:	83 ff 3e             	cmp    $0x3e,%edi
     73a:	74 05                	je     741 <parseredirs+0x61>
     73c:	83 ff 2b             	cmp    $0x2b,%edi
     73f:	75 af                	jne    6f0 <parseredirs+0x10>
      break;
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     741:	8b 55 e4             	mov    -0x1c(%ebp),%edx
     744:	8b 4d e0             	mov    -0x20(%ebp),%ecx
  cmd = malloc(sizeof(*cmd));
     747:	83 ec 0c             	sub    $0xc,%esp
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     74a:	89 55 d0             	mov    %edx,-0x30(%ebp)
     74d:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
  cmd = malloc(sizeof(*cmd));
     750:	6a 18                	push   $0x18
     752:	e8 f9 0a 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     757:	83 c4 0c             	add    $0xc,%esp
     75a:	6a 18                	push   $0x18
  cmd = malloc(sizeof(*cmd));
     75c:	89 c7                	mov    %eax,%edi
  memset(cmd, 0, sizeof(*cmd));
     75e:	6a 00                	push   $0x0
     760:	50                   	push   %eax
     761:	e8 aa 05 00 00       	call   d10 <memset>
  cmd->type = REDIR;
     766:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
  cmd->cmd = subcmd;
     76c:	8b 45 08             	mov    0x8(%ebp),%eax
      break;
     76f:	83 c4 10             	add    $0x10,%esp
  cmd->cmd = subcmd;
     772:	89 47 04             	mov    %eax,0x4(%edi)
  cmd->file = file;
     775:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
     778:	89 4f 08             	mov    %ecx,0x8(%edi)
  cmd->efile = efile;
     77b:	8b 55 d0             	mov    -0x30(%ebp),%edx
  cmd->mode = mode;
     77e:	c7 47 10 01 02 00 00 	movl   $0x201,0x10(%edi)
  cmd->efile = efile;
     785:	89 57 0c             	mov    %edx,0xc(%edi)
  cmd->fd = fd;
     788:	c7 47 14 01 00 00 00 	movl   $0x1,0x14(%edi)
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     78f:	89 7d 08             	mov    %edi,0x8(%ebp)
      break;
     792:	e9 59 ff ff ff       	jmp    6f0 <parseredirs+0x10>
     797:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     79e:	00 
     79f:	90                   	nop
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     7a0:	8b 55 e4             	mov    -0x1c(%ebp),%edx
     7a3:	8b 4d e0             	mov    -0x20(%ebp),%ecx
  cmd = malloc(sizeof(*cmd));
     7a6:	83 ec 0c             	sub    $0xc,%esp
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     7a9:	89 55 d0             	mov    %edx,-0x30(%ebp)
     7ac:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
  cmd = malloc(sizeof(*cmd));
     7af:	6a 18                	push   $0x18
     7b1:	e8 9a 0a 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     7b6:	83 c4 0c             	add    $0xc,%esp
     7b9:	6a 18                	push   $0x18
  cmd = malloc(sizeof(*cmd));
     7bb:	89 c7                	mov    %eax,%edi
  memset(cmd, 0, sizeof(*cmd));
     7bd:	6a 00                	push   $0x0
     7bf:	50                   	push   %eax
     7c0:	e8 4b 05 00 00       	call   d10 <memset>
  cmd->cmd = subcmd;
     7c5:	8b 45 08             	mov    0x8(%ebp),%eax
  cmd->file = file;
     7c8:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
      break;
     7cb:	83 c4 10             	add    $0x10,%esp
  cmd->efile = efile;
     7ce:	8b 55 d0             	mov    -0x30(%ebp),%edx
  cmd->type = REDIR;
     7d1:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
  cmd->cmd = subcmd;
     7d7:	89 47 04             	mov    %eax,0x4(%edi)
  cmd->file = file;
     7da:	89 4f 08             	mov    %ecx,0x8(%edi)
  cmd->efile = efile;
     7dd:	89 57 0c             	mov    %edx,0xc(%edi)
  cmd->mode = mode;
     7e0:	c7 47 10 00 00 00 00 	movl   $0x0,0x10(%edi)
  cmd->fd = fd;
     7e7:	c7 47 14 00 00 00 00 	movl   $0x0,0x14(%edi)
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     7ee:	89 7d 08             	mov    %edi,0x8(%ebp)
      break;
     7f1:	e9 fa fe ff ff       	jmp    6f0 <parseredirs+0x10>
     7f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     7fd:	00 
     7fe:	66 90                	xchg   %ax,%ax
    }
  }
  return cmd;
}
     800:	8b 45 08             	mov    0x8(%ebp),%eax
     803:	8d 65 f4             	lea    -0xc(%ebp),%esp
     806:	5b                   	pop    %ebx
     807:	5e                   	pop    %esi
     808:	5f                   	pop    %edi
     809:	5d                   	pop    %ebp
     80a:	c3                   	ret
      panic("missing file for redirection");
     80b:	83 ec 0c             	sub    $0xc,%esp
     80e:	68 88 13 00 00       	push   $0x1388
     813:	e8 58 f9 ff ff       	call   170 <panic>
     818:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     81f:	00 

00000820 <parseexec>:
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
     820:	55                   	push   %ebp
     821:	89 e5                	mov    %esp,%ebp
     823:	57                   	push   %edi
     824:	56                   	push   %esi
     825:	53                   	push   %ebx
     826:	83 ec 30             	sub    $0x30,%esp
     829:	8b 5d 08             	mov    0x8(%ebp),%ebx
     82c:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
     82f:	68 a8 13 00 00       	push   $0x13a8
     834:	56                   	push   %esi
     835:	53                   	push   %ebx
     836:	e8 25 fe ff ff       	call   660 <peek>
     83b:	83 c4 10             	add    $0x10,%esp
     83e:	85 c0                	test   %eax,%eax
     840:	0f 85 aa 00 00 00    	jne    8f0 <parseexec+0xd0>
  cmd = malloc(sizeof(*cmd));
     846:	83 ec 0c             	sub    $0xc,%esp
     849:	89 c7                	mov    %eax,%edi
     84b:	6a 54                	push   $0x54
     84d:	e8 fe 09 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     852:	83 c4 0c             	add    $0xc,%esp
     855:	6a 54                	push   $0x54
     857:	6a 00                	push   $0x0
     859:	89 45 d0             	mov    %eax,-0x30(%ebp)
     85c:	50                   	push   %eax
     85d:	e8 ae 04 00 00       	call   d10 <memset>
  cmd->type = EXEC;
     862:	8b 45 d0             	mov    -0x30(%ebp),%eax

  ret = execcmd();
  cmd = (struct execcmd*)ret;

  argc = 0;
  ret = parseredirs(ret, ps, es);
     865:	83 c4 0c             	add    $0xc,%esp
  cmd->type = EXEC;
     868:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  ret = parseredirs(ret, ps, es);
     86e:	56                   	push   %esi
     86f:	53                   	push   %ebx
     870:	50                   	push   %eax
     871:	e8 6a fe ff ff       	call   6e0 <parseredirs>
  while(!peek(ps, es, "|)&;")){
     876:	83 c4 10             	add    $0x10,%esp
  ret = parseredirs(ret, ps, es);
     879:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  while(!peek(ps, es, "|)&;")){
     87c:	eb 15                	jmp    893 <parseexec+0x73>
     87e:	66 90                	xchg   %ax,%ax
    cmd->argv[argc] = q;
    cmd->eargv[argc] = eq;
    argc++;
    if(argc >= MAXARGS)
      panic("too many args");
    ret = parseredirs(ret, ps, es);
     880:	83 ec 04             	sub    $0x4,%esp
     883:	56                   	push   %esi
     884:	53                   	push   %ebx
     885:	ff 75 d4             	push   -0x2c(%ebp)
     888:	e8 53 fe ff ff       	call   6e0 <parseredirs>
     88d:	83 c4 10             	add    $0x10,%esp
     890:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  while(!peek(ps, es, "|)&;")){
     893:	83 ec 04             	sub    $0x4,%esp
     896:	68 bf 13 00 00       	push   $0x13bf
     89b:	56                   	push   %esi
     89c:	53                   	push   %ebx
     89d:	e8 be fd ff ff       	call   660 <peek>
     8a2:	83 c4 10             	add    $0x10,%esp
     8a5:	85 c0                	test   %eax,%eax
     8a7:	75 5f                	jne    908 <parseexec+0xe8>
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
     8a9:	8d 45 e4             	lea    -0x1c(%ebp),%eax
     8ac:	50                   	push   %eax
     8ad:	8d 45 e0             	lea    -0x20(%ebp),%eax
     8b0:	50                   	push   %eax
     8b1:	56                   	push   %esi
     8b2:	53                   	push   %ebx
     8b3:	e8 38 fc ff ff       	call   4f0 <gettoken>
     8b8:	83 c4 10             	add    $0x10,%esp
     8bb:	85 c0                	test   %eax,%eax
     8bd:	74 49                	je     908 <parseexec+0xe8>
    if(tok != 'a')
     8bf:	83 f8 61             	cmp    $0x61,%eax
     8c2:	75 62                	jne    926 <parseexec+0x106>
    cmd->argv[argc] = q;
     8c4:	8b 45 e0             	mov    -0x20(%ebp),%eax
     8c7:	8b 55 d0             	mov    -0x30(%ebp),%edx
     8ca:	89 44 ba 04          	mov    %eax,0x4(%edx,%edi,4)
    cmd->eargv[argc] = eq;
     8ce:	8b 45 e4             	mov    -0x1c(%ebp),%eax
     8d1:	89 44 ba 2c          	mov    %eax,0x2c(%edx,%edi,4)
    argc++;
     8d5:	83 c7 01             	add    $0x1,%edi
    if(argc >= MAXARGS)
     8d8:	83 ff 0a             	cmp    $0xa,%edi
     8db:	75 a3                	jne    880 <parseexec+0x60>
      panic("too many args");
     8dd:	83 ec 0c             	sub    $0xc,%esp
     8e0:	68 b1 13 00 00       	push   $0x13b1
     8e5:	e8 86 f8 ff ff       	call   170 <panic>
     8ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return parseblock(ps, es);
     8f0:	89 75 0c             	mov    %esi,0xc(%ebp)
     8f3:	89 5d 08             	mov    %ebx,0x8(%ebp)
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}
     8f6:	8d 65 f4             	lea    -0xc(%ebp),%esp
     8f9:	5b                   	pop    %ebx
     8fa:	5e                   	pop    %esi
     8fb:	5f                   	pop    %edi
     8fc:	5d                   	pop    %ebp
    return parseblock(ps, es);
     8fd:	e9 ae 01 00 00       	jmp    ab0 <parseblock>
     902:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  cmd->argv[argc] = 0;
     908:	8b 45 d0             	mov    -0x30(%ebp),%eax
     90b:	c7 44 b8 04 00 00 00 	movl   $0x0,0x4(%eax,%edi,4)
     912:	00 
  cmd->eargv[argc] = 0;
     913:	c7 44 b8 2c 00 00 00 	movl   $0x0,0x2c(%eax,%edi,4)
     91a:	00 
}
     91b:	8b 45 d4             	mov    -0x2c(%ebp),%eax
     91e:	8d 65 f4             	lea    -0xc(%ebp),%esp
     921:	5b                   	pop    %ebx
     922:	5e                   	pop    %esi
     923:	5f                   	pop    %edi
     924:	5d                   	pop    %ebp
     925:	c3                   	ret
      panic("syntax");
     926:	83 ec 0c             	sub    $0xc,%esp
     929:	68 aa 13 00 00       	push   $0x13aa
     92e:	e8 3d f8 ff ff       	call   170 <panic>
     933:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     93a:	00 
     93b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

00000940 <parsepipe>:
{
     940:	55                   	push   %ebp
     941:	89 e5                	mov    %esp,%ebp
     943:	57                   	push   %edi
     944:	56                   	push   %esi
     945:	53                   	push   %ebx
     946:	83 ec 14             	sub    $0x14,%esp
     949:	8b 75 08             	mov    0x8(%ebp),%esi
     94c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  cmd = parseexec(ps, es);
     94f:	57                   	push   %edi
     950:	56                   	push   %esi
     951:	e8 ca fe ff ff       	call   820 <parseexec>
  if(peek(ps, es, "|")){
     956:	83 c4 0c             	add    $0xc,%esp
     959:	68 c4 13 00 00       	push   $0x13c4
  cmd = parseexec(ps, es);
     95e:	89 c3                	mov    %eax,%ebx
  if(peek(ps, es, "|")){
     960:	57                   	push   %edi
     961:	56                   	push   %esi
     962:	e8 f9 fc ff ff       	call   660 <peek>
     967:	83 c4 10             	add    $0x10,%esp
     96a:	85 c0                	test   %eax,%eax
     96c:	75 12                	jne    980 <parsepipe+0x40>
}
     96e:	8d 65 f4             	lea    -0xc(%ebp),%esp
     971:	89 d8                	mov    %ebx,%eax
     973:	5b                   	pop    %ebx
     974:	5e                   	pop    %esi
     975:	5f                   	pop    %edi
     976:	5d                   	pop    %ebp
     977:	c3                   	ret
     978:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     97f:	00 
    gettoken(ps, es, 0, 0);
     980:	6a 00                	push   $0x0
     982:	6a 00                	push   $0x0
     984:	57                   	push   %edi
     985:	56                   	push   %esi
     986:	e8 65 fb ff ff       	call   4f0 <gettoken>
    cmd = pipecmd(cmd, parsepipe(ps, es));
     98b:	58                   	pop    %eax
     98c:	5a                   	pop    %edx
     98d:	57                   	push   %edi
     98e:	56                   	push   %esi
     98f:	e8 ac ff ff ff       	call   940 <parsepipe>
  cmd = malloc(sizeof(*cmd));
     994:	c7 04 24 0c 00 00 00 	movl   $0xc,(%esp)
    cmd = pipecmd(cmd, parsepipe(ps, es));
     99b:	89 c7                	mov    %eax,%edi
  cmd = malloc(sizeof(*cmd));
     99d:	e8 ae 08 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     9a2:	83 c4 0c             	add    $0xc,%esp
     9a5:	6a 0c                	push   $0xc
  cmd = malloc(sizeof(*cmd));
     9a7:	89 c6                	mov    %eax,%esi
  memset(cmd, 0, sizeof(*cmd));
     9a9:	6a 00                	push   $0x0
     9ab:	50                   	push   %eax
     9ac:	e8 5f 03 00 00       	call   d10 <memset>
  cmd->left = left;
     9b1:	89 5e 04             	mov    %ebx,0x4(%esi)
  cmd->right = right;
     9b4:	83 c4 10             	add    $0x10,%esp
    cmd = pipecmd(cmd, parsepipe(ps, es));
     9b7:	89 f3                	mov    %esi,%ebx
  cmd->type = PIPE;
     9b9:	c7 06 03 00 00 00    	movl   $0x3,(%esi)
}
     9bf:	89 d8                	mov    %ebx,%eax
  cmd->right = right;
     9c1:	89 7e 08             	mov    %edi,0x8(%esi)
}
     9c4:	8d 65 f4             	lea    -0xc(%ebp),%esp
     9c7:	5b                   	pop    %ebx
     9c8:	5e                   	pop    %esi
     9c9:	5f                   	pop    %edi
     9ca:	5d                   	pop    %ebp
     9cb:	c3                   	ret
     9cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000009d0 <parseline>:
{
     9d0:	55                   	push   %ebp
     9d1:	89 e5                	mov    %esp,%ebp
     9d3:	57                   	push   %edi
     9d4:	56                   	push   %esi
     9d5:	53                   	push   %ebx
     9d6:	83 ec 24             	sub    $0x24,%esp
     9d9:	8b 75 08             	mov    0x8(%ebp),%esi
     9dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  cmd = parsepipe(ps, es);
     9df:	57                   	push   %edi
     9e0:	56                   	push   %esi
     9e1:	e8 5a ff ff ff       	call   940 <parsepipe>
  while(peek(ps, es, "&")){
     9e6:	83 c4 10             	add    $0x10,%esp
  cmd = parsepipe(ps, es);
     9e9:	89 c3                	mov    %eax,%ebx
  while(peek(ps, es, "&")){
     9eb:	eb 3b                	jmp    a28 <parseline+0x58>
     9ed:	8d 76 00             	lea    0x0(%esi),%esi
    gettoken(ps, es, 0, 0);
     9f0:	6a 00                	push   $0x0
     9f2:	6a 00                	push   $0x0
     9f4:	57                   	push   %edi
     9f5:	56                   	push   %esi
     9f6:	e8 f5 fa ff ff       	call   4f0 <gettoken>
  cmd = malloc(sizeof(*cmd));
     9fb:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
     a02:	e8 49 08 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     a07:	83 c4 0c             	add    $0xc,%esp
     a0a:	6a 08                	push   $0x8
     a0c:	6a 00                	push   $0x0
     a0e:	50                   	push   %eax
     a0f:	89 45 e4             	mov    %eax,-0x1c(%ebp)
     a12:	e8 f9 02 00 00       	call   d10 <memset>
  cmd->type = BACK;
     a17:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  cmd->cmd = subcmd;
     a1a:	83 c4 10             	add    $0x10,%esp
  cmd->type = BACK;
     a1d:	c7 02 05 00 00 00    	movl   $0x5,(%edx)
  cmd->cmd = subcmd;
     a23:	89 5a 04             	mov    %ebx,0x4(%edx)
    cmd = backcmd(cmd);
     a26:	89 d3                	mov    %edx,%ebx
  while(peek(ps, es, "&")){
     a28:	83 ec 04             	sub    $0x4,%esp
     a2b:	68 c6 13 00 00       	push   $0x13c6
     a30:	57                   	push   %edi
     a31:	56                   	push   %esi
     a32:	e8 29 fc ff ff       	call   660 <peek>
     a37:	83 c4 10             	add    $0x10,%esp
     a3a:	85 c0                	test   %eax,%eax
     a3c:	75 b2                	jne    9f0 <parseline+0x20>
  if(peek(ps, es, ";")){
     a3e:	83 ec 04             	sub    $0x4,%esp
     a41:	68 c2 13 00 00       	push   $0x13c2
     a46:	57                   	push   %edi
     a47:	56                   	push   %esi
     a48:	e8 13 fc ff ff       	call   660 <peek>
     a4d:	83 c4 10             	add    $0x10,%esp
     a50:	85 c0                	test   %eax,%eax
     a52:	75 0c                	jne    a60 <parseline+0x90>
}
     a54:	8d 65 f4             	lea    -0xc(%ebp),%esp
     a57:	89 d8                	mov    %ebx,%eax
     a59:	5b                   	pop    %ebx
     a5a:	5e                   	pop    %esi
     a5b:	5f                   	pop    %edi
     a5c:	5d                   	pop    %ebp
     a5d:	c3                   	ret
     a5e:	66 90                	xchg   %ax,%ax
    gettoken(ps, es, 0, 0);
     a60:	6a 00                	push   $0x0
     a62:	6a 00                	push   $0x0
     a64:	57                   	push   %edi
     a65:	56                   	push   %esi
     a66:	e8 85 fa ff ff       	call   4f0 <gettoken>
    cmd = listcmd(cmd, parseline(ps, es));
     a6b:	58                   	pop    %eax
     a6c:	5a                   	pop    %edx
     a6d:	57                   	push   %edi
     a6e:	56                   	push   %esi
     a6f:	e8 5c ff ff ff       	call   9d0 <parseline>
  cmd = malloc(sizeof(*cmd));
     a74:	c7 04 24 0c 00 00 00 	movl   $0xc,(%esp)
    cmd = listcmd(cmd, parseline(ps, es));
     a7b:	89 c7                	mov    %eax,%edi
  cmd = malloc(sizeof(*cmd));
     a7d:	e8 ce 07 00 00       	call   1250 <malloc>
  memset(cmd, 0, sizeof(*cmd));
     a82:	83 c4 0c             	add    $0xc,%esp
     a85:	6a 0c                	push   $0xc
  cmd = malloc(sizeof(*cmd));
     a87:	89 c6                	mov    %eax,%esi
  memset(cmd, 0, sizeof(*cmd));
     a89:	6a 00                	push   $0x0
     a8b:	50                   	push   %eax
     a8c:	e8 7f 02 00 00       	call   d10 <memset>
  cmd->left = left;
     a91:	89 5e 04             	mov    %ebx,0x4(%esi)
  cmd->right = right;
     a94:	83 c4 10             	add    $0x10,%esp
    cmd = listcmd(cmd, parseline(ps, es));
     a97:	89 f3                	mov    %esi,%ebx
  cmd->type = LIST;
     a99:	c7 06 04 00 00 00    	movl   $0x4,(%esi)
}
     a9f:	89 d8                	mov    %ebx,%eax
  cmd->right = right;
     aa1:	89 7e 08             	mov    %edi,0x8(%esi)
}
     aa4:	8d 65 f4             	lea    -0xc(%ebp),%esp
     aa7:	5b                   	pop    %ebx
     aa8:	5e                   	pop    %esi
     aa9:	5f                   	pop    %edi
     aaa:	5d                   	pop    %ebp
     aab:	c3                   	ret
     aac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000ab0 <parseblock>:
{
     ab0:	55                   	push   %ebp
     ab1:	89 e5                	mov    %esp,%ebp
     ab3:	57                   	push   %edi
     ab4:	56                   	push   %esi
     ab5:	53                   	push   %ebx
     ab6:	83 ec 10             	sub    $0x10,%esp
     ab9:	8b 5d 08             	mov    0x8(%ebp),%ebx
     abc:	8b 75 0c             	mov    0xc(%ebp),%esi
  if(!peek(ps, es, "("))
     abf:	68 a8 13 00 00       	push   $0x13a8
     ac4:	56                   	push   %esi
     ac5:	53                   	push   %ebx
     ac6:	e8 95 fb ff ff       	call   660 <peek>
     acb:	83 c4 10             	add    $0x10,%esp
     ace:	85 c0                	test   %eax,%eax
     ad0:	74 4a                	je     b1c <parseblock+0x6c>
  gettoken(ps, es, 0, 0);
     ad2:	6a 00                	push   $0x0
     ad4:	6a 00                	push   $0x0
     ad6:	56                   	push   %esi
     ad7:	53                   	push   %ebx
     ad8:	e8 13 fa ff ff       	call   4f0 <gettoken>
  cmd = parseline(ps, es);
     add:	58                   	pop    %eax
     ade:	5a                   	pop    %edx
     adf:	56                   	push   %esi
     ae0:	53                   	push   %ebx
     ae1:	e8 ea fe ff ff       	call   9d0 <parseline>
  if(!peek(ps, es, ")"))
     ae6:	83 c4 0c             	add    $0xc,%esp
     ae9:	68 e4 13 00 00       	push   $0x13e4
  cmd = parseline(ps, es);
     aee:	89 c7                	mov    %eax,%edi
  if(!peek(ps, es, ")"))
     af0:	56                   	push   %esi
     af1:	53                   	push   %ebx
     af2:	e8 69 fb ff ff       	call   660 <peek>
     af7:	83 c4 10             	add    $0x10,%esp
     afa:	85 c0                	test   %eax,%eax
     afc:	74 2b                	je     b29 <parseblock+0x79>
  gettoken(ps, es, 0, 0);
     afe:	6a 00                	push   $0x0
     b00:	6a 00                	push   $0x0
     b02:	56                   	push   %esi
     b03:	53                   	push   %ebx
     b04:	e8 e7 f9 ff ff       	call   4f0 <gettoken>
  cmd = parseredirs(cmd, ps, es);
     b09:	83 c4 0c             	add    $0xc,%esp
     b0c:	56                   	push   %esi
     b0d:	53                   	push   %ebx
     b0e:	57                   	push   %edi
     b0f:	e8 cc fb ff ff       	call   6e0 <parseredirs>
}
     b14:	8d 65 f4             	lea    -0xc(%ebp),%esp
     b17:	5b                   	pop    %ebx
     b18:	5e                   	pop    %esi
     b19:	5f                   	pop    %edi
     b1a:	5d                   	pop    %ebp
     b1b:	c3                   	ret
    panic("parseblock");
     b1c:	83 ec 0c             	sub    $0xc,%esp
     b1f:	68 c8 13 00 00       	push   $0x13c8
     b24:	e8 47 f6 ff ff       	call   170 <panic>
    panic("syntax - missing )");
     b29:	83 ec 0c             	sub    $0xc,%esp
     b2c:	68 d3 13 00 00       	push   $0x13d3
     b31:	e8 3a f6 ff ff       	call   170 <panic>
     b36:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     b3d:	00 
     b3e:	66 90                	xchg   %ax,%ax

00000b40 <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
     b40:	55                   	push   %ebp
     b41:	89 e5                	mov    %esp,%ebp
     b43:	53                   	push   %ebx
     b44:	83 ec 04             	sub    $0x4,%esp
     b47:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
     b4a:	85 db                	test   %ebx,%ebx
     b4c:	74 29                	je     b77 <nulterminate+0x37>
    return 0;

  switch(cmd->type){
     b4e:	83 3b 05             	cmpl   $0x5,(%ebx)
     b51:	77 24                	ja     b77 <nulterminate+0x37>
     b53:	8b 03                	mov    (%ebx),%eax
     b55:	ff 24 85 dc 14 00 00 	jmp    *0x14dc(,%eax,4)
     b5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    nulterminate(pcmd->right);
    break;

  case LIST:
    lcmd = (struct listcmd*)cmd;
    nulterminate(lcmd->left);
     b60:	83 ec 0c             	sub    $0xc,%esp
     b63:	ff 73 04             	push   0x4(%ebx)
     b66:	e8 d5 ff ff ff       	call   b40 <nulterminate>
    nulterminate(lcmd->right);
     b6b:	58                   	pop    %eax
     b6c:	ff 73 08             	push   0x8(%ebx)
     b6f:	e8 cc ff ff ff       	call   b40 <nulterminate>
    break;
     b74:	83 c4 10             	add    $0x10,%esp
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
     b77:	89 d8                	mov    %ebx,%eax
     b79:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     b7c:	c9                   	leave
     b7d:	c3                   	ret
     b7e:	66 90                	xchg   %ax,%ax
    nulterminate(bcmd->cmd);
     b80:	83 ec 0c             	sub    $0xc,%esp
     b83:	ff 73 04             	push   0x4(%ebx)
     b86:	e8 b5 ff ff ff       	call   b40 <nulterminate>
}
     b8b:	89 d8                	mov    %ebx,%eax
    break;
     b8d:	83 c4 10             	add    $0x10,%esp
}
     b90:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     b93:	c9                   	leave
     b94:	c3                   	ret
     b95:	8d 76 00             	lea    0x0(%esi),%esi
    for(i=0; ecmd->argv[i]; i++)
     b98:	8b 4b 04             	mov    0x4(%ebx),%ecx
     b9b:	85 c9                	test   %ecx,%ecx
     b9d:	74 d8                	je     b77 <nulterminate+0x37>
     b9f:	8d 43 08             	lea    0x8(%ebx),%eax
     ba2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      *ecmd->eargv[i] = 0;
     ba8:	8b 50 24             	mov    0x24(%eax),%edx
    for(i=0; ecmd->argv[i]; i++)
     bab:	83 c0 04             	add    $0x4,%eax
      *ecmd->eargv[i] = 0;
     bae:	c6 02 00             	movb   $0x0,(%edx)
    for(i=0; ecmd->argv[i]; i++)
     bb1:	8b 50 fc             	mov    -0x4(%eax),%edx
     bb4:	85 d2                	test   %edx,%edx
     bb6:	75 f0                	jne    ba8 <nulterminate+0x68>
}
     bb8:	89 d8                	mov    %ebx,%eax
     bba:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     bbd:	c9                   	leave
     bbe:	c3                   	ret
     bbf:	90                   	nop
    nulterminate(rcmd->cmd);
     bc0:	83 ec 0c             	sub    $0xc,%esp
     bc3:	ff 73 04             	push   0x4(%ebx)
     bc6:	e8 75 ff ff ff       	call   b40 <nulterminate>
    *rcmd->efile = 0;
     bcb:	8b 43 0c             	mov    0xc(%ebx),%eax
    break;
     bce:	83 c4 10             	add    $0x10,%esp
    *rcmd->efile = 0;
     bd1:	c6 00 00             	movb   $0x0,(%eax)
}
     bd4:	89 d8                	mov    %ebx,%eax
     bd6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     bd9:	c9                   	leave
     bda:	c3                   	ret
     bdb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

00000be0 <parsecmd>:
{
     be0:	55                   	push   %ebp
     be1:	89 e5                	mov    %esp,%ebp
     be3:	57                   	push   %edi
     be4:	56                   	push   %esi
  cmd = parseline(&s, es);
     be5:	8d 7d 08             	lea    0x8(%ebp),%edi
{
     be8:	53                   	push   %ebx
     be9:	83 ec 18             	sub    $0x18,%esp
  es = s + strlen(s);
     bec:	8b 5d 08             	mov    0x8(%ebp),%ebx
     bef:	53                   	push   %ebx
     bf0:	e8 eb 00 00 00       	call   ce0 <strlen>
  cmd = parseline(&s, es);
     bf5:	59                   	pop    %ecx
     bf6:	5e                   	pop    %esi
  es = s + strlen(s);
     bf7:	01 c3                	add    %eax,%ebx
  cmd = parseline(&s, es);
     bf9:	53                   	push   %ebx
     bfa:	57                   	push   %edi
     bfb:	e8 d0 fd ff ff       	call   9d0 <parseline>
  peek(&s, es, "");
     c00:	83 c4 0c             	add    $0xc,%esp
     c03:	68 82 13 00 00       	push   $0x1382
  cmd = parseline(&s, es);
     c08:	89 c6                	mov    %eax,%esi
  peek(&s, es, "");
     c0a:	53                   	push   %ebx
     c0b:	57                   	push   %edi
     c0c:	e8 4f fa ff ff       	call   660 <peek>
  if(s != es){
     c11:	8b 45 08             	mov    0x8(%ebp),%eax
     c14:	83 c4 10             	add    $0x10,%esp
     c17:	39 d8                	cmp    %ebx,%eax
     c19:	75 13                	jne    c2e <parsecmd+0x4e>
  nulterminate(cmd);
     c1b:	83 ec 0c             	sub    $0xc,%esp
     c1e:	56                   	push   %esi
     c1f:	e8 1c ff ff ff       	call   b40 <nulterminate>
}
     c24:	8d 65 f4             	lea    -0xc(%ebp),%esp
     c27:	89 f0                	mov    %esi,%eax
     c29:	5b                   	pop    %ebx
     c2a:	5e                   	pop    %esi
     c2b:	5f                   	pop    %edi
     c2c:	5d                   	pop    %ebp
     c2d:	c3                   	ret
    printf(2, "leftovers: %s\n", s);
     c2e:	52                   	push   %edx
     c2f:	50                   	push   %eax
     c30:	68 e6 13 00 00       	push   $0x13e6
     c35:	6a 02                	push   $0x2
     c37:	e8 f4 03 00 00       	call   1030 <printf>
    panic("syntax");
     c3c:	c7 04 24 aa 13 00 00 	movl   $0x13aa,(%esp)
     c43:	e8 28 f5 ff ff       	call   170 <panic>
     c48:	66 90                	xchg   %ax,%ax
     c4a:	66 90                	xchg   %ax,%ax
     c4c:	66 90                	xchg   %ax,%ax
     c4e:	66 90                	xchg   %ax,%ax

00000c50 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
     c50:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     c51:	31 c0                	xor    %eax,%eax
{
     c53:	89 e5                	mov    %esp,%ebp
     c55:	53                   	push   %ebx
     c56:	8b 4d 08             	mov    0x8(%ebp),%ecx
     c59:	8b 5d 0c             	mov    0xc(%ebp),%ebx
     c5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
     c60:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
     c64:	88 14 01             	mov    %dl,(%ecx,%eax,1)
     c67:	83 c0 01             	add    $0x1,%eax
     c6a:	84 d2                	test   %dl,%dl
     c6c:	75 f2                	jne    c60 <strcpy+0x10>
    ;
  return os;
}
     c6e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     c71:	89 c8                	mov    %ecx,%eax
     c73:	c9                   	leave
     c74:	c3                   	ret
     c75:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     c7c:	00 
     c7d:	8d 76 00             	lea    0x0(%esi),%esi

00000c80 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     c80:	55                   	push   %ebp
     c81:	89 e5                	mov    %esp,%ebp
     c83:	53                   	push   %ebx
     c84:	8b 55 08             	mov    0x8(%ebp),%edx
     c87:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
     c8a:	0f b6 02             	movzbl (%edx),%eax
     c8d:	84 c0                	test   %al,%al
     c8f:	75 17                	jne    ca8 <strcmp+0x28>
     c91:	eb 3a                	jmp    ccd <strcmp+0x4d>
     c93:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     c98:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
     c9c:	83 c2 01             	add    $0x1,%edx
     c9f:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
     ca2:	84 c0                	test   %al,%al
     ca4:	74 1a                	je     cc0 <strcmp+0x40>
     ca6:	89 d9                	mov    %ebx,%ecx
     ca8:	0f b6 19             	movzbl (%ecx),%ebx
     cab:	38 c3                	cmp    %al,%bl
     cad:	74 e9                	je     c98 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
     caf:	29 d8                	sub    %ebx,%eax
}
     cb1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     cb4:	c9                   	leave
     cb5:	c3                   	ret
     cb6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     cbd:	00 
     cbe:	66 90                	xchg   %ax,%ax
  return (uchar)*p - (uchar)*q;
     cc0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
     cc4:	31 c0                	xor    %eax,%eax
     cc6:	29 d8                	sub    %ebx,%eax
}
     cc8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     ccb:	c9                   	leave
     ccc:	c3                   	ret
  return (uchar)*p - (uchar)*q;
     ccd:	0f b6 19             	movzbl (%ecx),%ebx
     cd0:	31 c0                	xor    %eax,%eax
     cd2:	eb db                	jmp    caf <strcmp+0x2f>
     cd4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     cdb:	00 
     cdc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000ce0 <strlen>:

uint
strlen(const char *s)
{
     ce0:	55                   	push   %ebp
     ce1:	89 e5                	mov    %esp,%ebp
     ce3:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
     ce6:	80 3a 00             	cmpb   $0x0,(%edx)
     ce9:	74 15                	je     d00 <strlen+0x20>
     ceb:	31 c0                	xor    %eax,%eax
     ced:	8d 76 00             	lea    0x0(%esi),%esi
     cf0:	83 c0 01             	add    $0x1,%eax
     cf3:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
     cf7:	89 c1                	mov    %eax,%ecx
     cf9:	75 f5                	jne    cf0 <strlen+0x10>
    ;
  return n;
}
     cfb:	89 c8                	mov    %ecx,%eax
     cfd:	5d                   	pop    %ebp
     cfe:	c3                   	ret
     cff:	90                   	nop
  for(n = 0; s[n]; n++)
     d00:	31 c9                	xor    %ecx,%ecx
}
     d02:	5d                   	pop    %ebp
     d03:	89 c8                	mov    %ecx,%eax
     d05:	c3                   	ret
     d06:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d0d:	00 
     d0e:	66 90                	xchg   %ax,%ax

00000d10 <memset>:

void*
memset(void *dst, int c, uint n)
{
     d10:	55                   	push   %ebp
     d11:	89 e5                	mov    %esp,%ebp
     d13:	57                   	push   %edi
     d14:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
     d17:	8b 4d 10             	mov    0x10(%ebp),%ecx
     d1a:	8b 45 0c             	mov    0xc(%ebp),%eax
     d1d:	89 d7                	mov    %edx,%edi
     d1f:	fc                   	cld
     d20:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
     d22:	8b 7d fc             	mov    -0x4(%ebp),%edi
     d25:	89 d0                	mov    %edx,%eax
     d27:	c9                   	leave
     d28:	c3                   	ret
     d29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000d30 <strchr>:

char*
strchr(const char *s, char c)
{
     d30:	55                   	push   %ebp
     d31:	89 e5                	mov    %esp,%ebp
     d33:	8b 45 08             	mov    0x8(%ebp),%eax
     d36:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
     d3a:	0f b6 10             	movzbl (%eax),%edx
     d3d:	84 d2                	test   %dl,%dl
     d3f:	75 12                	jne    d53 <strchr+0x23>
     d41:	eb 1d                	jmp    d60 <strchr+0x30>
     d43:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     d48:	0f b6 50 01          	movzbl 0x1(%eax),%edx
     d4c:	83 c0 01             	add    $0x1,%eax
     d4f:	84 d2                	test   %dl,%dl
     d51:	74 0d                	je     d60 <strchr+0x30>
    if(*s == c)
     d53:	38 d1                	cmp    %dl,%cl
     d55:	75 f1                	jne    d48 <strchr+0x18>
      return (char*)s;
  return 0;
}
     d57:	5d                   	pop    %ebp
     d58:	c3                   	ret
     d59:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
     d60:	31 c0                	xor    %eax,%eax
}
     d62:	5d                   	pop    %ebp
     d63:	c3                   	ret
     d64:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d6b:	00 
     d6c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000d70 <gets>:

char*
gets(char *buf, int max)
{
     d70:	55                   	push   %ebp
     d71:	89 e5                	mov    %esp,%ebp
     d73:	57                   	push   %edi
     d74:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
     d75:	8d 75 e7             	lea    -0x19(%ebp),%esi
{
     d78:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
     d79:	31 db                	xor    %ebx,%ebx
{
     d7b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
     d7e:	eb 27                	jmp    da7 <gets+0x37>
    cc = read(0, &c, 1);
     d80:	83 ec 04             	sub    $0x4,%esp
     d83:	6a 01                	push   $0x1
     d85:	56                   	push   %esi
     d86:	6a 00                	push   $0x0
     d88:	e8 1e 01 00 00       	call   eab <read>
    if(cc < 1)
     d8d:	83 c4 10             	add    $0x10,%esp
     d90:	85 c0                	test   %eax,%eax
     d92:	7e 1d                	jle    db1 <gets+0x41>
      break;
    buf[i++] = c;
     d94:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
     d98:	8b 55 08             	mov    0x8(%ebp),%edx
     d9b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
     d9f:	3c 0a                	cmp    $0xa,%al
     da1:	74 10                	je     db3 <gets+0x43>
     da3:	3c 0d                	cmp    $0xd,%al
     da5:	74 0c                	je     db3 <gets+0x43>
  for(i=0; i+1 < max; ){
     da7:	89 df                	mov    %ebx,%edi
     da9:	83 c3 01             	add    $0x1,%ebx
     dac:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
     daf:	7c cf                	jl     d80 <gets+0x10>
     db1:	89 fb                	mov    %edi,%ebx
      break;
  }
  buf[i] = '\0';
     db3:	8b 45 08             	mov    0x8(%ebp),%eax
     db6:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
  return buf;
}
     dba:	8d 65 f4             	lea    -0xc(%ebp),%esp
     dbd:	5b                   	pop    %ebx
     dbe:	5e                   	pop    %esi
     dbf:	5f                   	pop    %edi
     dc0:	5d                   	pop    %ebp
     dc1:	c3                   	ret
     dc2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     dc9:	00 
     dca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000dd0 <stat>:

int
stat(const char *n, struct stat *st)
{
     dd0:	55                   	push   %ebp
     dd1:	89 e5                	mov    %esp,%ebp
     dd3:	56                   	push   %esi
     dd4:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     dd5:	83 ec 08             	sub    $0x8,%esp
     dd8:	6a 00                	push   $0x0
     dda:	ff 75 08             	push   0x8(%ebp)
     ddd:	e8 f1 00 00 00       	call   ed3 <open>
  if(fd < 0)
     de2:	83 c4 10             	add    $0x10,%esp
     de5:	85 c0                	test   %eax,%eax
     de7:	78 27                	js     e10 <stat+0x40>
    return -1;
  r = fstat(fd, st);
     de9:	83 ec 08             	sub    $0x8,%esp
     dec:	ff 75 0c             	push   0xc(%ebp)
     def:	89 c3                	mov    %eax,%ebx
     df1:	50                   	push   %eax
     df2:	e8 f4 00 00 00       	call   eeb <fstat>
  close(fd);
     df7:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
     dfa:	89 c6                	mov    %eax,%esi
  close(fd);
     dfc:	e8 ba 00 00 00       	call   ebb <close>
  return r;
     e01:	83 c4 10             	add    $0x10,%esp
}
     e04:	8d 65 f8             	lea    -0x8(%ebp),%esp
     e07:	89 f0                	mov    %esi,%eax
     e09:	5b                   	pop    %ebx
     e0a:	5e                   	pop    %esi
     e0b:	5d                   	pop    %ebp
     e0c:	c3                   	ret
     e0d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
     e10:	be ff ff ff ff       	mov    $0xffffffff,%esi
     e15:	eb ed                	jmp    e04 <stat+0x34>
     e17:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     e1e:	00 
     e1f:	90                   	nop

00000e20 <atoi>:

int
atoi(const char *s)
{
     e20:	55                   	push   %ebp
     e21:	89 e5                	mov    %esp,%ebp
     e23:	53                   	push   %ebx
     e24:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     e27:	0f be 02             	movsbl (%edx),%eax
     e2a:	8d 48 d0             	lea    -0x30(%eax),%ecx
     e2d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
     e30:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
     e35:	77 1e                	ja     e55 <atoi+0x35>
     e37:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     e3e:	00 
     e3f:	90                   	nop
    n = n*10 + *s++ - '0';
     e40:	83 c2 01             	add    $0x1,%edx
     e43:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
     e46:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
     e4a:	0f be 02             	movsbl (%edx),%eax
     e4d:	8d 58 d0             	lea    -0x30(%eax),%ebx
     e50:	80 fb 09             	cmp    $0x9,%bl
     e53:	76 eb                	jbe    e40 <atoi+0x20>
  return n;
}
     e55:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     e58:	89 c8                	mov    %ecx,%eax
     e5a:	c9                   	leave
     e5b:	c3                   	ret
     e5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000e60 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     e60:	55                   	push   %ebp
     e61:	89 e5                	mov    %esp,%ebp
     e63:	57                   	push   %edi
     e64:	8b 45 10             	mov    0x10(%ebp),%eax
     e67:	8b 55 08             	mov    0x8(%ebp),%edx
     e6a:	56                   	push   %esi
     e6b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
     e6e:	85 c0                	test   %eax,%eax
     e70:	7e 13                	jle    e85 <memmove+0x25>
     e72:	01 d0                	add    %edx,%eax
  dst = vdst;
     e74:	89 d7                	mov    %edx,%edi
     e76:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     e7d:	00 
     e7e:	66 90                	xchg   %ax,%ax
    *dst++ = *src++;
     e80:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
     e81:	39 f8                	cmp    %edi,%eax
     e83:	75 fb                	jne    e80 <memmove+0x20>
  return vdst;
}
     e85:	5e                   	pop    %esi
     e86:	89 d0                	mov    %edx,%eax
     e88:	5f                   	pop    %edi
     e89:	5d                   	pop    %ebp
     e8a:	c3                   	ret

00000e8b <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
     e8b:	b8 01 00 00 00       	mov    $0x1,%eax
     e90:	cd 40                	int    $0x40
     e92:	c3                   	ret

00000e93 <exit>:
SYSCALL(exit)
     e93:	b8 02 00 00 00       	mov    $0x2,%eax
     e98:	cd 40                	int    $0x40
     e9a:	c3                   	ret

00000e9b <wait>:
SYSCALL(wait)
     e9b:	b8 03 00 00 00       	mov    $0x3,%eax
     ea0:	cd 40                	int    $0x40
     ea2:	c3                   	ret

00000ea3 <pipe>:
SYSCALL(pipe)
     ea3:	b8 04 00 00 00       	mov    $0x4,%eax
     ea8:	cd 40                	int    $0x40
     eaa:	c3                   	ret

00000eab <read>:
SYSCALL(read)
     eab:	b8 05 00 00 00       	mov    $0x5,%eax
     eb0:	cd 40                	int    $0x40
     eb2:	c3                   	ret

00000eb3 <write>:
SYSCALL(write)
     eb3:	b8 10 00 00 00       	mov    $0x10,%eax
     eb8:	cd 40                	int    $0x40
     eba:	c3                   	ret

00000ebb <close>:
SYSCALL(close)
     ebb:	b8 15 00 00 00       	mov    $0x15,%eax
     ec0:	cd 40                	int    $0x40
     ec2:	c3                   	ret

00000ec3 <kill>:
SYSCALL(kill)
     ec3:	b8 06 00 00 00       	mov    $0x6,%eax
     ec8:	cd 40                	int    $0x40
     eca:	c3                   	ret

00000ecb <exec>:
SYSCALL(exec)
     ecb:	b8 07 00 00 00       	mov    $0x7,%eax
     ed0:	cd 40                	int    $0x40
     ed2:	c3                   	ret

00000ed3 <open>:
SYSCALL(open)
     ed3:	b8 0f 00 00 00       	mov    $0xf,%eax
     ed8:	cd 40                	int    $0x40
     eda:	c3                   	ret

00000edb <mknod>:
SYSCALL(mknod)
     edb:	b8 11 00 00 00       	mov    $0x11,%eax
     ee0:	cd 40                	int    $0x40
     ee2:	c3                   	ret

00000ee3 <unlink>:
SYSCALL(unlink)
     ee3:	b8 12 00 00 00       	mov    $0x12,%eax
     ee8:	cd 40                	int    $0x40
     eea:	c3                   	ret

00000eeb <fstat>:
SYSCALL(fstat)
     eeb:	b8 08 00 00 00       	mov    $0x8,%eax
     ef0:	cd 40                	int    $0x40
     ef2:	c3                   	ret

00000ef3 <link>:
SYSCALL(link)
     ef3:	b8 13 00 00 00       	mov    $0x13,%eax
     ef8:	cd 40                	int    $0x40
     efa:	c3                   	ret

00000efb <mkdir>:
SYSCALL(mkdir)
     efb:	b8 14 00 00 00       	mov    $0x14,%eax
     f00:	cd 40                	int    $0x40
     f02:	c3                   	ret

00000f03 <chdir>:
SYSCALL(chdir)
     f03:	b8 09 00 00 00       	mov    $0x9,%eax
     f08:	cd 40                	int    $0x40
     f0a:	c3                   	ret

00000f0b <dup>:
SYSCALL(dup)
     f0b:	b8 0a 00 00 00       	mov    $0xa,%eax
     f10:	cd 40                	int    $0x40
     f12:	c3                   	ret

00000f13 <getpid>:
SYSCALL(getpid)
     f13:	b8 0b 00 00 00       	mov    $0xb,%eax
     f18:	cd 40                	int    $0x40
     f1a:	c3                   	ret

00000f1b <sbrk>:
SYSCALL(sbrk)
     f1b:	b8 0c 00 00 00       	mov    $0xc,%eax
     f20:	cd 40                	int    $0x40
     f22:	c3                   	ret

00000f23 <sleep>:
SYSCALL(sleep)
     f23:	b8 0d 00 00 00       	mov    $0xd,%eax
     f28:	cd 40                	int    $0x40
     f2a:	c3                   	ret

00000f2b <uptime>:
SYSCALL(uptime)
     f2b:	b8 0e 00 00 00       	mov    $0xe,%eax
     f30:	cd 40                	int    $0x40
     f32:	c3                   	ret

00000f33 <strrev>:
SYSCALL(strrev)
     f33:	b8 16 00 00 00       	mov    $0x16,%eax
     f38:	cd 40                	int    $0x40
     f3a:	c3                   	ret

00000f3b <setflag>:
SYSCALL(setflag)
     f3b:	b8 17 00 00 00       	mov    $0x17,%eax
     f40:	cd 40                	int    $0x40
     f42:	c3                   	ret

00000f43 <getflag>:
SYSCALL(getflag)
     f43:	b8 18 00 00 00       	mov    $0x18,%eax
     f48:	cd 40                	int    $0x40
     f4a:	c3                   	ret

00000f4b <getstats>:
SYSCALL(getstats)
     f4b:	b8 19 00 00 00       	mov    $0x19,%eax
     f50:	cd 40                	int    $0x40
     f52:	c3                   	ret

00000f53 <get_proc_info>:
SYSCALL(get_proc_info)
     f53:	b8 1a 00 00 00       	mov    $0x1a,%eax
     f58:	cd 40                	int    $0x40
     f5a:	c3                   	ret

00000f5b <numvp>:
SYSCALL(numvp)
     f5b:	b8 1b 00 00 00       	mov    $0x1b,%eax
     f60:	cd 40                	int    $0x40
     f62:	c3                   	ret

00000f63 <numpp>:
SYSCALL(numpp)
     f63:	b8 1c 00 00 00       	mov    $0x1c,%eax
     f68:	cd 40                	int    $0x40
     f6a:	c3                   	ret

00000f6b <getptsize>:
SYSCALL(getptsize)
     f6b:	b8 1d 00 00 00       	mov    $0x1d,%eax
     f70:	cd 40                	int    $0x40
     f72:	c3                   	ret

00000f73 <setpriority>:
SYSCALL(setpriority)
     f73:	b8 1e 00 00 00       	mov    $0x1e,%eax
     f78:	cd 40                	int    $0x40
     f7a:	c3                   	ret

00000f7b <getpagefaults>:
     f7b:	b8 1f 00 00 00       	mov    $0x1f,%eax
     f80:	cd 40                	int    $0x40
     f82:	c3                   	ret
     f83:	66 90                	xchg   %ax,%ax
     f85:	66 90                	xchg   %ax,%ax
     f87:	66 90                	xchg   %ax,%ax
     f89:	66 90                	xchg   %ax,%ax
     f8b:	66 90                	xchg   %ax,%ax
     f8d:	66 90                	xchg   %ax,%ax
     f8f:	90                   	nop

00000f90 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
     f90:	55                   	push   %ebp
     f91:	89 e5                	mov    %esp,%ebp
     f93:	57                   	push   %edi
     f94:	56                   	push   %esi
     f95:	53                   	push   %ebx
     f96:	89 cb                	mov    %ecx,%ebx
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
     f98:	89 d1                	mov    %edx,%ecx
{
     f9a:	83 ec 3c             	sub    $0x3c,%esp
     f9d:	89 45 c0             	mov    %eax,-0x40(%ebp)
  if(sgn && xx < 0){
     fa0:	85 d2                	test   %edx,%edx
     fa2:	0f 89 80 00 00 00    	jns    1028 <printint+0x98>
     fa8:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
     fac:	74 7a                	je     1028 <printint+0x98>
    x = -xx;
     fae:	f7 d9                	neg    %ecx
    neg = 1;
     fb0:	b8 01 00 00 00       	mov    $0x1,%eax
  } else {
    x = xx;
  }

  i = 0;
     fb5:	89 45 c4             	mov    %eax,-0x3c(%ebp)
     fb8:	31 f6                	xor    %esi,%esi
     fba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
     fc0:	89 c8                	mov    %ecx,%eax
     fc2:	31 d2                	xor    %edx,%edx
     fc4:	89 f7                	mov    %esi,%edi
     fc6:	f7 f3                	div    %ebx
     fc8:	8d 76 01             	lea    0x1(%esi),%esi
     fcb:	0f b6 92 4c 15 00 00 	movzbl 0x154c(%edx),%edx
     fd2:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
     fd6:	89 ca                	mov    %ecx,%edx
     fd8:	89 c1                	mov    %eax,%ecx
     fda:	39 da                	cmp    %ebx,%edx
     fdc:	73 e2                	jae    fc0 <printint+0x30>
  if(neg)
     fde:	8b 45 c4             	mov    -0x3c(%ebp),%eax
     fe1:	85 c0                	test   %eax,%eax
     fe3:	74 07                	je     fec <printint+0x5c>
    buf[i++] = '-';
     fe5:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)

  while(--i >= 0)
     fea:	89 f7                	mov    %esi,%edi
     fec:	8d 5d d8             	lea    -0x28(%ebp),%ebx
     fef:	8b 75 c0             	mov    -0x40(%ebp),%esi
     ff2:	01 df                	add    %ebx,%edi
     ff4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    putc(fd, buf[i]);
     ff8:	0f b6 07             	movzbl (%edi),%eax
  write(fd, &c, 1);
     ffb:	83 ec 04             	sub    $0x4,%esp
     ffe:	88 45 d7             	mov    %al,-0x29(%ebp)
    1001:	8d 45 d7             	lea    -0x29(%ebp),%eax
    1004:	6a 01                	push   $0x1
    1006:	50                   	push   %eax
    1007:	56                   	push   %esi
    1008:	e8 a6 fe ff ff       	call   eb3 <write>
  while(--i >= 0)
    100d:	89 f8                	mov    %edi,%eax
    100f:	83 c4 10             	add    $0x10,%esp
    1012:	83 ef 01             	sub    $0x1,%edi
    1015:	39 c3                	cmp    %eax,%ebx
    1017:	75 df                	jne    ff8 <printint+0x68>
}
    1019:	8d 65 f4             	lea    -0xc(%ebp),%esp
    101c:	5b                   	pop    %ebx
    101d:	5e                   	pop    %esi
    101e:	5f                   	pop    %edi
    101f:	5d                   	pop    %ebp
    1020:	c3                   	ret
    1021:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
    1028:	31 c0                	xor    %eax,%eax
    102a:	eb 89                	jmp    fb5 <printint+0x25>
    102c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00001030 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
    1030:	55                   	push   %ebp
    1031:	89 e5                	mov    %esp,%ebp
    1033:	57                   	push   %edi
    1034:	56                   	push   %esi
    1035:	53                   	push   %ebx
    1036:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
    1039:	8b 75 0c             	mov    0xc(%ebp),%esi
{
    103c:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i = 0; fmt[i]; i++){
    103f:	0f b6 1e             	movzbl (%esi),%ebx
    1042:	83 c6 01             	add    $0x1,%esi
    1045:	84 db                	test   %bl,%bl
    1047:	74 67                	je     10b0 <printf+0x80>
    1049:	8d 4d 10             	lea    0x10(%ebp),%ecx
    104c:	31 d2                	xor    %edx,%edx
    104e:	89 4d d0             	mov    %ecx,-0x30(%ebp)
    1051:	eb 34                	jmp    1087 <printf+0x57>
    1053:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    1058:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
    105b:	ba 25 00 00 00       	mov    $0x25,%edx
      if(c == '%'){
    1060:	83 f8 25             	cmp    $0x25,%eax
    1063:	74 18                	je     107d <printf+0x4d>
  write(fd, &c, 1);
    1065:	83 ec 04             	sub    $0x4,%esp
    1068:	8d 45 e7             	lea    -0x19(%ebp),%eax
    106b:	88 5d e7             	mov    %bl,-0x19(%ebp)
    106e:	6a 01                	push   $0x1
    1070:	50                   	push   %eax
    1071:	57                   	push   %edi
    1072:	e8 3c fe ff ff       	call   eb3 <write>
    1077:	8b 55 d4             	mov    -0x2c(%ebp),%edx
      } else {
        putc(fd, c);
    107a:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
    107d:	0f b6 1e             	movzbl (%esi),%ebx
    1080:	83 c6 01             	add    $0x1,%esi
    1083:	84 db                	test   %bl,%bl
    1085:	74 29                	je     10b0 <printf+0x80>
    c = fmt[i] & 0xff;
    1087:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
    108a:	85 d2                	test   %edx,%edx
    108c:	74 ca                	je     1058 <printf+0x28>
      }
    } else if(state == '%'){
    108e:	83 fa 25             	cmp    $0x25,%edx
    1091:	75 ea                	jne    107d <printf+0x4d>
      if(c == 'd'){
    1093:	83 f8 25             	cmp    $0x25,%eax
    1096:	0f 84 04 01 00 00    	je     11a0 <printf+0x170>
    109c:	83 e8 63             	sub    $0x63,%eax
    109f:	83 f8 15             	cmp    $0x15,%eax
    10a2:	77 1c                	ja     10c0 <printf+0x90>
    10a4:	ff 24 85 f4 14 00 00 	jmp    *0x14f4(,%eax,4)
    10ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        putc(fd, c);
      }
      state = 0;
    }
  }
}
    10b0:	8d 65 f4             	lea    -0xc(%ebp),%esp
    10b3:	5b                   	pop    %ebx
    10b4:	5e                   	pop    %esi
    10b5:	5f                   	pop    %edi
    10b6:	5d                   	pop    %ebp
    10b7:	c3                   	ret
    10b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
    10bf:	00 
  write(fd, &c, 1);
    10c0:	83 ec 04             	sub    $0x4,%esp
    10c3:	8d 55 e7             	lea    -0x19(%ebp),%edx
    10c6:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
    10ca:	6a 01                	push   $0x1
    10cc:	52                   	push   %edx
    10cd:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    10d0:	57                   	push   %edi
    10d1:	e8 dd fd ff ff       	call   eb3 <write>
    10d6:	83 c4 0c             	add    $0xc,%esp
    10d9:	88 5d e7             	mov    %bl,-0x19(%ebp)
    10dc:	6a 01                	push   $0x1
    10de:	8b 55 d4             	mov    -0x2c(%ebp),%edx
    10e1:	52                   	push   %edx
    10e2:	57                   	push   %edi
    10e3:	e8 cb fd ff ff       	call   eb3 <write>
        putc(fd, c);
    10e8:	83 c4 10             	add    $0x10,%esp
      state = 0;
    10eb:	31 d2                	xor    %edx,%edx
    10ed:	eb 8e                	jmp    107d <printf+0x4d>
    10ef:	90                   	nop
        printint(fd, *ap, 16, 0);
    10f0:	8b 5d d0             	mov    -0x30(%ebp),%ebx
    10f3:	83 ec 0c             	sub    $0xc,%esp
    10f6:	b9 10 00 00 00       	mov    $0x10,%ecx
    10fb:	8b 13                	mov    (%ebx),%edx
    10fd:	6a 00                	push   $0x0
    10ff:	89 f8                	mov    %edi,%eax
        ap++;
    1101:	83 c3 04             	add    $0x4,%ebx
        printint(fd, *ap, 16, 0);
    1104:	e8 87 fe ff ff       	call   f90 <printint>
        ap++;
    1109:	89 5d d0             	mov    %ebx,-0x30(%ebp)
    110c:	83 c4 10             	add    $0x10,%esp
      state = 0;
    110f:	31 d2                	xor    %edx,%edx
    1111:	e9 67 ff ff ff       	jmp    107d <printf+0x4d>
        s = (char*)*ap;
    1116:	8b 45 d0             	mov    -0x30(%ebp),%eax
    1119:	8b 18                	mov    (%eax),%ebx
        ap++;
    111b:	83 c0 04             	add    $0x4,%eax
    111e:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
    1121:	85 db                	test   %ebx,%ebx
    1123:	0f 84 87 00 00 00    	je     11b0 <printf+0x180>
        while(*s != 0){
    1129:	0f b6 03             	movzbl (%ebx),%eax
      state = 0;
    112c:	31 d2                	xor    %edx,%edx
        while(*s != 0){
    112e:	84 c0                	test   %al,%al
    1130:	0f 84 47 ff ff ff    	je     107d <printf+0x4d>
    1136:	8d 55 e7             	lea    -0x19(%ebp),%edx
    1139:	89 75 d4             	mov    %esi,-0x2c(%ebp)
    113c:	89 de                	mov    %ebx,%esi
    113e:	89 d3                	mov    %edx,%ebx
  write(fd, &c, 1);
    1140:	83 ec 04             	sub    $0x4,%esp
    1143:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
    1146:	83 c6 01             	add    $0x1,%esi
  write(fd, &c, 1);
    1149:	6a 01                	push   $0x1
    114b:	53                   	push   %ebx
    114c:	57                   	push   %edi
    114d:	e8 61 fd ff ff       	call   eb3 <write>
        while(*s != 0){
    1152:	0f b6 06             	movzbl (%esi),%eax
    1155:	83 c4 10             	add    $0x10,%esp
    1158:	84 c0                	test   %al,%al
    115a:	75 e4                	jne    1140 <printf+0x110>
      state = 0;
    115c:	8b 75 d4             	mov    -0x2c(%ebp),%esi
    115f:	31 d2                	xor    %edx,%edx
    1161:	e9 17 ff ff ff       	jmp    107d <printf+0x4d>
        printint(fd, *ap, 10, 1);
    1166:	8b 5d d0             	mov    -0x30(%ebp),%ebx
    1169:	83 ec 0c             	sub    $0xc,%esp
    116c:	b9 0a 00 00 00       	mov    $0xa,%ecx
    1171:	8b 13                	mov    (%ebx),%edx
    1173:	6a 01                	push   $0x1
    1175:	eb 88                	jmp    10ff <printf+0xcf>
        putc(fd, *ap);
    1177:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  write(fd, &c, 1);
    117a:	83 ec 04             	sub    $0x4,%esp
    117d:	8d 55 e7             	lea    -0x19(%ebp),%edx
        putc(fd, *ap);
    1180:	8b 03                	mov    (%ebx),%eax
        ap++;
    1182:	83 c3 04             	add    $0x4,%ebx
        putc(fd, *ap);
    1185:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
    1188:	6a 01                	push   $0x1
    118a:	52                   	push   %edx
    118b:	57                   	push   %edi
    118c:	e8 22 fd ff ff       	call   eb3 <write>
        ap++;
    1191:	89 5d d0             	mov    %ebx,-0x30(%ebp)
    1194:	83 c4 10             	add    $0x10,%esp
      state = 0;
    1197:	31 d2                	xor    %edx,%edx
    1199:	e9 df fe ff ff       	jmp    107d <printf+0x4d>
    119e:	66 90                	xchg   %ax,%ax
  write(fd, &c, 1);
    11a0:	83 ec 04             	sub    $0x4,%esp
    11a3:	88 5d e7             	mov    %bl,-0x19(%ebp)
    11a6:	8d 55 e7             	lea    -0x19(%ebp),%edx
    11a9:	6a 01                	push   $0x1
    11ab:	e9 31 ff ff ff       	jmp    10e1 <printf+0xb1>
    11b0:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
    11b5:	bb 0b 14 00 00       	mov    $0x140b,%ebx
    11ba:	e9 77 ff ff ff       	jmp    1136 <printf+0x106>
    11bf:	90                   	nop

000011c0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    11c0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    11c1:	a1 a4 1b 00 00       	mov    0x1ba4,%eax
{
    11c6:	89 e5                	mov    %esp,%ebp
    11c8:	57                   	push   %edi
    11c9:	56                   	push   %esi
    11ca:	53                   	push   %ebx
    11cb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
    11ce:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    11d1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    11d8:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    11da:	39 c8                	cmp    %ecx,%eax
    11dc:	73 32                	jae    1210 <free+0x50>
    11de:	39 d1                	cmp    %edx,%ecx
    11e0:	72 04                	jb     11e6 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    11e2:	39 d0                	cmp    %edx,%eax
    11e4:	72 32                	jb     1218 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
    11e6:	8b 73 fc             	mov    -0x4(%ebx),%esi
    11e9:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
    11ec:	39 fa                	cmp    %edi,%edx
    11ee:	74 30                	je     1220 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    11f0:	89 53 f8             	mov    %edx,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    11f3:	8b 50 04             	mov    0x4(%eax),%edx
    11f6:	8d 34 d0             	lea    (%eax,%edx,8),%esi
    11f9:	39 f1                	cmp    %esi,%ecx
    11fb:	74 3a                	je     1237 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    11fd:	89 08                	mov    %ecx,(%eax)
  } else
    p->s.ptr = bp;
  freep = p;
}
    11ff:	5b                   	pop    %ebx
  freep = p;
    1200:	a3 a4 1b 00 00       	mov    %eax,0x1ba4
}
    1205:	5e                   	pop    %esi
    1206:	5f                   	pop    %edi
    1207:	5d                   	pop    %ebp
    1208:	c3                   	ret
    1209:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1210:	39 d0                	cmp    %edx,%eax
    1212:	72 04                	jb     1218 <free+0x58>
    1214:	39 d1                	cmp    %edx,%ecx
    1216:	72 ce                	jb     11e6 <free+0x26>
{
    1218:	89 d0                	mov    %edx,%eax
    121a:	eb bc                	jmp    11d8 <free+0x18>
    121c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
    1220:	03 72 04             	add    0x4(%edx),%esi
    1223:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
    1226:	8b 10                	mov    (%eax),%edx
    1228:	8b 12                	mov    (%edx),%edx
    122a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
    122d:	8b 50 04             	mov    0x4(%eax),%edx
    1230:	8d 34 d0             	lea    (%eax,%edx,8),%esi
    1233:	39 f1                	cmp    %esi,%ecx
    1235:	75 c6                	jne    11fd <free+0x3d>
    p->s.size += bp->s.size;
    1237:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
    123a:	a3 a4 1b 00 00       	mov    %eax,0x1ba4
    p->s.size += bp->s.size;
    123f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
    1242:	8b 4b f8             	mov    -0x8(%ebx),%ecx
    1245:	89 08                	mov    %ecx,(%eax)
}
    1247:	5b                   	pop    %ebx
    1248:	5e                   	pop    %esi
    1249:	5f                   	pop    %edi
    124a:	5d                   	pop    %ebp
    124b:	c3                   	ret
    124c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00001250 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1250:	55                   	push   %ebp
    1251:	89 e5                	mov    %esp,%ebp
    1253:	57                   	push   %edi
    1254:	56                   	push   %esi
    1255:	53                   	push   %ebx
    1256:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1259:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
    125c:	8b 15 a4 1b 00 00    	mov    0x1ba4,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1262:	8d 78 07             	lea    0x7(%eax),%edi
    1265:	c1 ef 03             	shr    $0x3,%edi
    1268:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
    126b:	85 d2                	test   %edx,%edx
    126d:	0f 84 8d 00 00 00    	je     1300 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1273:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
    1275:	8b 48 04             	mov    0x4(%eax),%ecx
    1278:	39 f9                	cmp    %edi,%ecx
    127a:	73 64                	jae    12e0 <malloc+0x90>
  if(nu < 4096)
    127c:	bb 00 10 00 00       	mov    $0x1000,%ebx
    1281:	39 df                	cmp    %ebx,%edi
    1283:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
    1286:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
    128d:	eb 0a                	jmp    1299 <malloc+0x49>
    128f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1290:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
    1292:	8b 48 04             	mov    0x4(%eax),%ecx
    1295:	39 f9                	cmp    %edi,%ecx
    1297:	73 47                	jae    12e0 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    1299:	89 c2                	mov    %eax,%edx
    129b:	3b 05 a4 1b 00 00    	cmp    0x1ba4,%eax
    12a1:	75 ed                	jne    1290 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
    12a3:	83 ec 0c             	sub    $0xc,%esp
    12a6:	56                   	push   %esi
    12a7:	e8 6f fc ff ff       	call   f1b <sbrk>
  if(p == (char*)-1)
    12ac:	83 c4 10             	add    $0x10,%esp
    12af:	83 f8 ff             	cmp    $0xffffffff,%eax
    12b2:	74 1c                	je     12d0 <malloc+0x80>
  hp->s.size = nu;
    12b4:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
    12b7:	83 ec 0c             	sub    $0xc,%esp
    12ba:	83 c0 08             	add    $0x8,%eax
    12bd:	50                   	push   %eax
    12be:	e8 fd fe ff ff       	call   11c0 <free>
  return freep;
    12c3:	8b 15 a4 1b 00 00    	mov    0x1ba4,%edx
      if((p = morecore(nunits)) == 0)
    12c9:	83 c4 10             	add    $0x10,%esp
    12cc:	85 d2                	test   %edx,%edx
    12ce:	75 c0                	jne    1290 <malloc+0x40>
        return 0;
  }
}
    12d0:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
    12d3:	31 c0                	xor    %eax,%eax
}
    12d5:	5b                   	pop    %ebx
    12d6:	5e                   	pop    %esi
    12d7:	5f                   	pop    %edi
    12d8:	5d                   	pop    %ebp
    12d9:	c3                   	ret
    12da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
    12e0:	39 cf                	cmp    %ecx,%edi
    12e2:	74 4c                	je     1330 <malloc+0xe0>
        p->s.size -= nunits;
    12e4:	29 f9                	sub    %edi,%ecx
    12e6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
    12e9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
    12ec:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
    12ef:	89 15 a4 1b 00 00    	mov    %edx,0x1ba4
}
    12f5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
    12f8:	83 c0 08             	add    $0x8,%eax
}
    12fb:	5b                   	pop    %ebx
    12fc:	5e                   	pop    %esi
    12fd:	5f                   	pop    %edi
    12fe:	5d                   	pop    %ebp
    12ff:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
    1300:	c7 05 a4 1b 00 00 a8 	movl   $0x1ba8,0x1ba4
    1307:	1b 00 00 
    base.s.size = 0;
    130a:	b8 a8 1b 00 00       	mov    $0x1ba8,%eax
    base.s.ptr = freep = prevp = &base;
    130f:	c7 05 a8 1b 00 00 a8 	movl   $0x1ba8,0x1ba8
    1316:	1b 00 00 
    base.s.size = 0;
    1319:	c7 05 ac 1b 00 00 00 	movl   $0x0,0x1bac
    1320:	00 00 00 
    if(p->s.size >= nunits){
    1323:	e9 54 ff ff ff       	jmp    127c <malloc+0x2c>
    1328:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
    132f:	00 
        prevp->s.ptr = p->s.ptr;
    1330:	8b 08                	mov    (%eax),%ecx
    1332:	89 0a                	mov    %ecx,(%edx)
    1334:	eb b9                	jmp    12ef <malloc+0x9f>
