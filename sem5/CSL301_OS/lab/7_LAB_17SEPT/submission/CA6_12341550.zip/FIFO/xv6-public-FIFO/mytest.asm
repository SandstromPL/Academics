
_mytest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
#include "user.h"
#define MAX_PAGES 5
// Number of physical pages available
#define TOTAL_ACCESSES 15 // Total virtual pages to access
int main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	8d 7d ac             	lea    -0x54(%ebp),%edi
    int fifo[MAX_PAGES];
    // Stores allocated virtual pages
    int next_to_replace = 0; // FIFO pointer
  12:	31 f6                	xor    %esi,%esi
{
  14:	53                   	push   %ebx
        {
            miss++;
            printf(1, "Access page %d: MISS, replacing page %d\n", page,
                   fifo[next_to_replace]);
            fifo[next_to_replace] = page;
            next_to_replace = (next_to_replace + 1) % MAX_PAGES;
  15:	89 f3                	mov    %esi,%ebx
  17:	89 fe                	mov    %edi,%esi
{
  19:	51                   	push   %ecx
  1a:	83 ec 70             	sub    $0x70,%esp
        fifo[i] = -1;
  1d:	c7 45 98 ff ff ff ff 	movl   $0xffffffff,-0x68(%ebp)
    printf(1, "Starting FIFO page replacement simulation...\n");
  24:	68 78 08 00 00       	push   $0x878
  29:	6a 01                	push   $0x1
        fifo[i] = -1;
  2b:	c7 45 9c ff ff ff ff 	movl   $0xffffffff,-0x64(%ebp)
  32:	c7 45 a0 ff ff ff ff 	movl   $0xffffffff,-0x60(%ebp)
  39:	c7 45 a4 ff ff ff ff 	movl   $0xffffffff,-0x5c(%ebp)
  40:	c7 45 a8 ff ff ff ff 	movl   $0xffffffff,-0x58(%ebp)
    printf(1, "Starting FIFO page replacement simulation...\n");
  47:	e8 24 05 00 00       	call   570 <printf>
    int accesses[TOTAL_ACCESSES] = {0, 1, 2, 3, 4, 1, 5, 0, 6, 1, 2, 7, 3, 8, 4};
  4c:	83 c4 10             	add    $0x10,%esp
  4f:	c7 45 ac 00 00 00 00 	movl   $0x0,-0x54(%ebp)
  56:	c7 45 b0 01 00 00 00 	movl   $0x1,-0x50(%ebp)
  5d:	c7 45 b4 02 00 00 00 	movl   $0x2,-0x4c(%ebp)
  64:	c7 45 b8 03 00 00 00 	movl   $0x3,-0x48(%ebp)
  6b:	c7 45 bc 04 00 00 00 	movl   $0x4,-0x44(%ebp)
  72:	c7 45 c0 01 00 00 00 	movl   $0x1,-0x40(%ebp)
  79:	c7 45 c4 05 00 00 00 	movl   $0x5,-0x3c(%ebp)
  80:	c7 45 c8 00 00 00 00 	movl   $0x0,-0x38(%ebp)
  87:	c7 45 cc 06 00 00 00 	movl   $0x6,-0x34(%ebp)
  8e:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
  95:	c7 45 d4 02 00 00 00 	movl   $0x2,-0x2c(%ebp)
  9c:	c7 45 d8 07 00 00 00 	movl   $0x7,-0x28(%ebp)
  a3:	c7 45 dc 03 00 00 00 	movl   $0x3,-0x24(%ebp)
  aa:	c7 45 e0 08 00 00 00 	movl   $0x8,-0x20(%ebp)
  b1:	c7 45 e4 04 00 00 00 	movl   $0x4,-0x1c(%ebp)
    miss = 0;
  b8:	c7 45 8c 00 00 00 00 	movl   $0x0,-0x74(%ebp)
    hit = 0;
  bf:	c7 45 90 00 00 00 00 	movl   $0x0,-0x70(%ebp)
  c6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
  cd:	00 
  ce:	66 90                	xchg   %ax,%ax
        page = accesses[i];
  d0:	8b 0e                	mov    (%esi),%ecx
        for (j = 0; j < MAX_PAGES; j++)
  d2:	8d 45 98             	lea    -0x68(%ebp),%eax
            if (fifo[j] == page)
  d5:	39 08                	cmp    %ecx,(%eax)
  d7:	0f 84 8b 00 00 00    	je     168 <main+0x168>
        for (j = 0; j < MAX_PAGES; j++)
  dd:	83 c0 04             	add    $0x4,%eax
  e0:	39 c7                	cmp    %eax,%edi
  e2:	75 f1                	jne    d5 <main+0xd5>
            printf(1, "Access page %d: MISS, replacing page %d\n", page,
  e4:	ff 74 9d 98          	push   -0x68(%ebp,%ebx,4)
  e8:	51                   	push   %ecx
  e9:	68 a8 08 00 00       	push   $0x8a8
  ee:	6a 01                	push   $0x1
  f0:	89 4d 94             	mov    %ecx,-0x6c(%ebp)
            miss++;
  f3:	83 45 8c 01          	addl   $0x1,-0x74(%ebp)
            printf(1, "Access page %d: MISS, replacing page %d\n", page,
  f7:	e8 74 04 00 00       	call   570 <printf>
            fifo[next_to_replace] = page;
  fc:	8b 4d 94             	mov    -0x6c(%ebp),%ecx
            next_to_replace = (next_to_replace + 1) % MAX_PAGES;
  ff:	b8 67 66 66 66       	mov    $0x66666667,%eax
 104:	83 c4 10             	add    $0x10,%esp
            fifo[next_to_replace] = page;
 107:	89 4c 9d 98          	mov    %ecx,-0x68(%ebp,%ebx,4)
            next_to_replace = (next_to_replace + 1) % MAX_PAGES;
 10b:	8d 4b 01             	lea    0x1(%ebx),%ecx
 10e:	f7 e9                	imul   %ecx
 110:	89 c8                	mov    %ecx,%eax
 112:	89 cb                	mov    %ecx,%ebx
 114:	c1 f8 1f             	sar    $0x1f,%eax
 117:	d1 fa                	sar    $1,%edx
 119:	29 c2                	sub    %eax,%edx
 11b:	8d 04 92             	lea    (%edx,%edx,4),%eax
 11e:	29 c3                	sub    %eax,%ebx
    for (i = 0; i < TOTAL_ACCESSES; i++)
 120:	83 c6 04             	add    $0x4,%esi
 123:	8d 45 e8             	lea    -0x18(%ebp),%eax
 126:	39 f0                	cmp    %esi,%eax
 128:	75 a6                	jne    d0 <main+0xd0>
        }
    }
    printf(1, "FIFO simulation completed.\n");
 12a:	83 ec 08             	sub    $0x8,%esp
 12d:	68 d1 08 00 00       	push   $0x8d1
 132:	6a 01                	push   $0x1
 134:	e8 37 04 00 00       	call   570 <printf>
    printf(1, "Total hits: %d\n", hit);
 139:	83 c4 0c             	add    $0xc,%esp
 13c:	ff 75 90             	push   -0x70(%ebp)
 13f:	68 ed 08 00 00       	push   $0x8ed
 144:	6a 01                	push   $0x1
 146:	e8 25 04 00 00       	call   570 <printf>
    printf(1, "Total misses: %d\n", miss);
 14b:	83 c4 0c             	add    $0xc,%esp
 14e:	ff 75 8c             	push   -0x74(%ebp)
 151:	68 fd 08 00 00       	push   $0x8fd
 156:	6a 01                	push   $0x1
 158:	e8 13 04 00 00       	call   570 <printf>
    exit();
 15d:	e8 71 02 00 00       	call   3d3 <exit>
 162:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
            printf(1, "Access page %d: HIT\n", page);
 168:	83 ec 04             	sub    $0x4,%esp
            hit++;
 16b:	83 45 90 01          	addl   $0x1,-0x70(%ebp)
            printf(1, "Access page %d: HIT\n", page);
 16f:	51                   	push   %ecx
 170:	68 0f 09 00 00       	push   $0x90f
 175:	6a 01                	push   $0x1
 177:	e8 f4 03 00 00       	call   570 <printf>
 17c:	83 c4 10             	add    $0x10,%esp
 17f:	eb 9f                	jmp    120 <main+0x120>
 181:	66 90                	xchg   %ax,%ax
 183:	66 90                	xchg   %ax,%ax
 185:	66 90                	xchg   %ax,%ax
 187:	66 90                	xchg   %ax,%ax
 189:	66 90                	xchg   %ax,%ax
 18b:	66 90                	xchg   %ax,%ax
 18d:	66 90                	xchg   %ax,%ax
 18f:	90                   	nop

00000190 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 190:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 191:	31 c0                	xor    %eax,%eax
{
 193:	89 e5                	mov    %esp,%ebp
 195:	53                   	push   %ebx
 196:	8b 4d 08             	mov    0x8(%ebp),%ecx
 199:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 19c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 1a0:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 1a4:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 1a7:	83 c0 01             	add    $0x1,%eax
 1aa:	84 d2                	test   %dl,%dl
 1ac:	75 f2                	jne    1a0 <strcpy+0x10>
    ;
  return os;
}
 1ae:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1b1:	89 c8                	mov    %ecx,%eax
 1b3:	c9                   	leave
 1b4:	c3                   	ret
 1b5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1bc:	00 
 1bd:	8d 76 00             	lea    0x0(%esi),%esi

000001c0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1c0:	55                   	push   %ebp
 1c1:	89 e5                	mov    %esp,%ebp
 1c3:	53                   	push   %ebx
 1c4:	8b 55 08             	mov    0x8(%ebp),%edx
 1c7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 1ca:	0f b6 02             	movzbl (%edx),%eax
 1cd:	84 c0                	test   %al,%al
 1cf:	75 17                	jne    1e8 <strcmp+0x28>
 1d1:	eb 3a                	jmp    20d <strcmp+0x4d>
 1d3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 1d8:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 1dc:	83 c2 01             	add    $0x1,%edx
 1df:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
 1e2:	84 c0                	test   %al,%al
 1e4:	74 1a                	je     200 <strcmp+0x40>
 1e6:	89 d9                	mov    %ebx,%ecx
 1e8:	0f b6 19             	movzbl (%ecx),%ebx
 1eb:	38 c3                	cmp    %al,%bl
 1ed:	74 e9                	je     1d8 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
 1ef:	29 d8                	sub    %ebx,%eax
}
 1f1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1f4:	c9                   	leave
 1f5:	c3                   	ret
 1f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1fd:	00 
 1fe:	66 90                	xchg   %ax,%ax
  return (uchar)*p - (uchar)*q;
 200:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 204:	31 c0                	xor    %eax,%eax
 206:	29 d8                	sub    %ebx,%eax
}
 208:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 20b:	c9                   	leave
 20c:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 20d:	0f b6 19             	movzbl (%ecx),%ebx
 210:	31 c0                	xor    %eax,%eax
 212:	eb db                	jmp    1ef <strcmp+0x2f>
 214:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 21b:	00 
 21c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000220 <strlen>:

uint
strlen(const char *s)
{
 220:	55                   	push   %ebp
 221:	89 e5                	mov    %esp,%ebp
 223:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 226:	80 3a 00             	cmpb   $0x0,(%edx)
 229:	74 15                	je     240 <strlen+0x20>
 22b:	31 c0                	xor    %eax,%eax
 22d:	8d 76 00             	lea    0x0(%esi),%esi
 230:	83 c0 01             	add    $0x1,%eax
 233:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 237:	89 c1                	mov    %eax,%ecx
 239:	75 f5                	jne    230 <strlen+0x10>
    ;
  return n;
}
 23b:	89 c8                	mov    %ecx,%eax
 23d:	5d                   	pop    %ebp
 23e:	c3                   	ret
 23f:	90                   	nop
  for(n = 0; s[n]; n++)
 240:	31 c9                	xor    %ecx,%ecx
}
 242:	5d                   	pop    %ebp
 243:	89 c8                	mov    %ecx,%eax
 245:	c3                   	ret
 246:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 24d:	00 
 24e:	66 90                	xchg   %ax,%ax

00000250 <memset>:

void*
memset(void *dst, int c, uint n)
{
 250:	55                   	push   %ebp
 251:	89 e5                	mov    %esp,%ebp
 253:	57                   	push   %edi
 254:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 257:	8b 4d 10             	mov    0x10(%ebp),%ecx
 25a:	8b 45 0c             	mov    0xc(%ebp),%eax
 25d:	89 d7                	mov    %edx,%edi
 25f:	fc                   	cld
 260:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 262:	8b 7d fc             	mov    -0x4(%ebp),%edi
 265:	89 d0                	mov    %edx,%eax
 267:	c9                   	leave
 268:	c3                   	ret
 269:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000270 <strchr>:

char*
strchr(const char *s, char c)
{
 270:	55                   	push   %ebp
 271:	89 e5                	mov    %esp,%ebp
 273:	8b 45 08             	mov    0x8(%ebp),%eax
 276:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 27a:	0f b6 10             	movzbl (%eax),%edx
 27d:	84 d2                	test   %dl,%dl
 27f:	75 12                	jne    293 <strchr+0x23>
 281:	eb 1d                	jmp    2a0 <strchr+0x30>
 283:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 288:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 28c:	83 c0 01             	add    $0x1,%eax
 28f:	84 d2                	test   %dl,%dl
 291:	74 0d                	je     2a0 <strchr+0x30>
    if(*s == c)
 293:	38 d1                	cmp    %dl,%cl
 295:	75 f1                	jne    288 <strchr+0x18>
      return (char*)s;
  return 0;
}
 297:	5d                   	pop    %ebp
 298:	c3                   	ret
 299:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 2a0:	31 c0                	xor    %eax,%eax
}
 2a2:	5d                   	pop    %ebp
 2a3:	c3                   	ret
 2a4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2ab:	00 
 2ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000002b0 <gets>:

char*
gets(char *buf, int max)
{
 2b0:	55                   	push   %ebp
 2b1:	89 e5                	mov    %esp,%ebp
 2b3:	57                   	push   %edi
 2b4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 2b5:	8d 75 e7             	lea    -0x19(%ebp),%esi
{
 2b8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 2b9:	31 db                	xor    %ebx,%ebx
{
 2bb:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 2be:	eb 27                	jmp    2e7 <gets+0x37>
    cc = read(0, &c, 1);
 2c0:	83 ec 04             	sub    $0x4,%esp
 2c3:	6a 01                	push   $0x1
 2c5:	56                   	push   %esi
 2c6:	6a 00                	push   $0x0
 2c8:	e8 1e 01 00 00       	call   3eb <read>
    if(cc < 1)
 2cd:	83 c4 10             	add    $0x10,%esp
 2d0:	85 c0                	test   %eax,%eax
 2d2:	7e 1d                	jle    2f1 <gets+0x41>
      break;
    buf[i++] = c;
 2d4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 2d8:	8b 55 08             	mov    0x8(%ebp),%edx
 2db:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 2df:	3c 0a                	cmp    $0xa,%al
 2e1:	74 10                	je     2f3 <gets+0x43>
 2e3:	3c 0d                	cmp    $0xd,%al
 2e5:	74 0c                	je     2f3 <gets+0x43>
  for(i=0; i+1 < max; ){
 2e7:	89 df                	mov    %ebx,%edi
 2e9:	83 c3 01             	add    $0x1,%ebx
 2ec:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 2ef:	7c cf                	jl     2c0 <gets+0x10>
 2f1:	89 fb                	mov    %edi,%ebx
      break;
  }
  buf[i] = '\0';
 2f3:	8b 45 08             	mov    0x8(%ebp),%eax
 2f6:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
  return buf;
}
 2fa:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2fd:	5b                   	pop    %ebx
 2fe:	5e                   	pop    %esi
 2ff:	5f                   	pop    %edi
 300:	5d                   	pop    %ebp
 301:	c3                   	ret
 302:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 309:	00 
 30a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000310 <stat>:

int
stat(const char *n, struct stat *st)
{
 310:	55                   	push   %ebp
 311:	89 e5                	mov    %esp,%ebp
 313:	56                   	push   %esi
 314:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 315:	83 ec 08             	sub    $0x8,%esp
 318:	6a 00                	push   $0x0
 31a:	ff 75 08             	push   0x8(%ebp)
 31d:	e8 f1 00 00 00       	call   413 <open>
  if(fd < 0)
 322:	83 c4 10             	add    $0x10,%esp
 325:	85 c0                	test   %eax,%eax
 327:	78 27                	js     350 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 329:	83 ec 08             	sub    $0x8,%esp
 32c:	ff 75 0c             	push   0xc(%ebp)
 32f:	89 c3                	mov    %eax,%ebx
 331:	50                   	push   %eax
 332:	e8 f4 00 00 00       	call   42b <fstat>
  close(fd);
 337:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 33a:	89 c6                	mov    %eax,%esi
  close(fd);
 33c:	e8 ba 00 00 00       	call   3fb <close>
  return r;
 341:	83 c4 10             	add    $0x10,%esp
}
 344:	8d 65 f8             	lea    -0x8(%ebp),%esp
 347:	89 f0                	mov    %esi,%eax
 349:	5b                   	pop    %ebx
 34a:	5e                   	pop    %esi
 34b:	5d                   	pop    %ebp
 34c:	c3                   	ret
 34d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 350:	be ff ff ff ff       	mov    $0xffffffff,%esi
 355:	eb ed                	jmp    344 <stat+0x34>
 357:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 35e:	00 
 35f:	90                   	nop

00000360 <atoi>:

int
atoi(const char *s)
{
 360:	55                   	push   %ebp
 361:	89 e5                	mov    %esp,%ebp
 363:	53                   	push   %ebx
 364:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 367:	0f be 02             	movsbl (%edx),%eax
 36a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 36d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 370:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 375:	77 1e                	ja     395 <atoi+0x35>
 377:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 37e:	00 
 37f:	90                   	nop
    n = n*10 + *s++ - '0';
 380:	83 c2 01             	add    $0x1,%edx
 383:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 386:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 38a:	0f be 02             	movsbl (%edx),%eax
 38d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 390:	80 fb 09             	cmp    $0x9,%bl
 393:	76 eb                	jbe    380 <atoi+0x20>
  return n;
}
 395:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 398:	89 c8                	mov    %ecx,%eax
 39a:	c9                   	leave
 39b:	c3                   	ret
 39c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003a0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3a0:	55                   	push   %ebp
 3a1:	89 e5                	mov    %esp,%ebp
 3a3:	57                   	push   %edi
 3a4:	8b 45 10             	mov    0x10(%ebp),%eax
 3a7:	8b 55 08             	mov    0x8(%ebp),%edx
 3aa:	56                   	push   %esi
 3ab:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 3ae:	85 c0                	test   %eax,%eax
 3b0:	7e 13                	jle    3c5 <memmove+0x25>
 3b2:	01 d0                	add    %edx,%eax
  dst = vdst;
 3b4:	89 d7                	mov    %edx,%edi
 3b6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3bd:	00 
 3be:	66 90                	xchg   %ax,%ax
    *dst++ = *src++;
 3c0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 3c1:	39 f8                	cmp    %edi,%eax
 3c3:	75 fb                	jne    3c0 <memmove+0x20>
  return vdst;
}
 3c5:	5e                   	pop    %esi
 3c6:	89 d0                	mov    %edx,%eax
 3c8:	5f                   	pop    %edi
 3c9:	5d                   	pop    %ebp
 3ca:	c3                   	ret

000003cb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 3cb:	b8 01 00 00 00       	mov    $0x1,%eax
 3d0:	cd 40                	int    $0x40
 3d2:	c3                   	ret

000003d3 <exit>:
SYSCALL(exit)
 3d3:	b8 02 00 00 00       	mov    $0x2,%eax
 3d8:	cd 40                	int    $0x40
 3da:	c3                   	ret

000003db <wait>:
SYSCALL(wait)
 3db:	b8 03 00 00 00       	mov    $0x3,%eax
 3e0:	cd 40                	int    $0x40
 3e2:	c3                   	ret

000003e3 <pipe>:
SYSCALL(pipe)
 3e3:	b8 04 00 00 00       	mov    $0x4,%eax
 3e8:	cd 40                	int    $0x40
 3ea:	c3                   	ret

000003eb <read>:
SYSCALL(read)
 3eb:	b8 05 00 00 00       	mov    $0x5,%eax
 3f0:	cd 40                	int    $0x40
 3f2:	c3                   	ret

000003f3 <write>:
SYSCALL(write)
 3f3:	b8 10 00 00 00       	mov    $0x10,%eax
 3f8:	cd 40                	int    $0x40
 3fa:	c3                   	ret

000003fb <close>:
SYSCALL(close)
 3fb:	b8 15 00 00 00       	mov    $0x15,%eax
 400:	cd 40                	int    $0x40
 402:	c3                   	ret

00000403 <kill>:
SYSCALL(kill)
 403:	b8 06 00 00 00       	mov    $0x6,%eax
 408:	cd 40                	int    $0x40
 40a:	c3                   	ret

0000040b <exec>:
SYSCALL(exec)
 40b:	b8 07 00 00 00       	mov    $0x7,%eax
 410:	cd 40                	int    $0x40
 412:	c3                   	ret

00000413 <open>:
SYSCALL(open)
 413:	b8 0f 00 00 00       	mov    $0xf,%eax
 418:	cd 40                	int    $0x40
 41a:	c3                   	ret

0000041b <mknod>:
SYSCALL(mknod)
 41b:	b8 11 00 00 00       	mov    $0x11,%eax
 420:	cd 40                	int    $0x40
 422:	c3                   	ret

00000423 <unlink>:
SYSCALL(unlink)
 423:	b8 12 00 00 00       	mov    $0x12,%eax
 428:	cd 40                	int    $0x40
 42a:	c3                   	ret

0000042b <fstat>:
SYSCALL(fstat)
 42b:	b8 08 00 00 00       	mov    $0x8,%eax
 430:	cd 40                	int    $0x40
 432:	c3                   	ret

00000433 <link>:
SYSCALL(link)
 433:	b8 13 00 00 00       	mov    $0x13,%eax
 438:	cd 40                	int    $0x40
 43a:	c3                   	ret

0000043b <mkdir>:
SYSCALL(mkdir)
 43b:	b8 14 00 00 00       	mov    $0x14,%eax
 440:	cd 40                	int    $0x40
 442:	c3                   	ret

00000443 <chdir>:
SYSCALL(chdir)
 443:	b8 09 00 00 00       	mov    $0x9,%eax
 448:	cd 40                	int    $0x40
 44a:	c3                   	ret

0000044b <dup>:
SYSCALL(dup)
 44b:	b8 0a 00 00 00       	mov    $0xa,%eax
 450:	cd 40                	int    $0x40
 452:	c3                   	ret

00000453 <getpid>:
SYSCALL(getpid)
 453:	b8 0b 00 00 00       	mov    $0xb,%eax
 458:	cd 40                	int    $0x40
 45a:	c3                   	ret

0000045b <sbrk>:
SYSCALL(sbrk)
 45b:	b8 0c 00 00 00       	mov    $0xc,%eax
 460:	cd 40                	int    $0x40
 462:	c3                   	ret

00000463 <sleep>:
SYSCALL(sleep)
 463:	b8 0d 00 00 00       	mov    $0xd,%eax
 468:	cd 40                	int    $0x40
 46a:	c3                   	ret

0000046b <uptime>:
SYSCALL(uptime)
 46b:	b8 0e 00 00 00       	mov    $0xe,%eax
 470:	cd 40                	int    $0x40
 472:	c3                   	ret

00000473 <strrev>:
SYSCALL(strrev)
 473:	b8 16 00 00 00       	mov    $0x16,%eax
 478:	cd 40                	int    $0x40
 47a:	c3                   	ret

0000047b <setflag>:
SYSCALL(setflag)
 47b:	b8 17 00 00 00       	mov    $0x17,%eax
 480:	cd 40                	int    $0x40
 482:	c3                   	ret

00000483 <getflag>:
SYSCALL(getflag)
 483:	b8 18 00 00 00       	mov    $0x18,%eax
 488:	cd 40                	int    $0x40
 48a:	c3                   	ret

0000048b <getstats>:
SYSCALL(getstats)
 48b:	b8 19 00 00 00       	mov    $0x19,%eax
 490:	cd 40                	int    $0x40
 492:	c3                   	ret

00000493 <get_proc_info>:
SYSCALL(get_proc_info)
 493:	b8 1a 00 00 00       	mov    $0x1a,%eax
 498:	cd 40                	int    $0x40
 49a:	c3                   	ret

0000049b <numvp>:
SYSCALL(numvp)
 49b:	b8 1b 00 00 00       	mov    $0x1b,%eax
 4a0:	cd 40                	int    $0x40
 4a2:	c3                   	ret

000004a3 <numpp>:
SYSCALL(numpp)
 4a3:	b8 1c 00 00 00       	mov    $0x1c,%eax
 4a8:	cd 40                	int    $0x40
 4aa:	c3                   	ret

000004ab <getptsize>:
SYSCALL(getptsize)
 4ab:	b8 1d 00 00 00       	mov    $0x1d,%eax
 4b0:	cd 40                	int    $0x40
 4b2:	c3                   	ret

000004b3 <setpriority>:
SYSCALL(setpriority)
 4b3:	b8 1e 00 00 00       	mov    $0x1e,%eax
 4b8:	cd 40                	int    $0x40
 4ba:	c3                   	ret

000004bb <getpagefaults>:
 4bb:	b8 1f 00 00 00       	mov    $0x1f,%eax
 4c0:	cd 40                	int    $0x40
 4c2:	c3                   	ret
 4c3:	66 90                	xchg   %ax,%ax
 4c5:	66 90                	xchg   %ax,%ax
 4c7:	66 90                	xchg   %ax,%ax
 4c9:	66 90                	xchg   %ax,%ax
 4cb:	66 90                	xchg   %ax,%ax
 4cd:	66 90                	xchg   %ax,%ax
 4cf:	90                   	nop

000004d0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 4d0:	55                   	push   %ebp
 4d1:	89 e5                	mov    %esp,%ebp
 4d3:	57                   	push   %edi
 4d4:	56                   	push   %esi
 4d5:	53                   	push   %ebx
 4d6:	89 cb                	mov    %ecx,%ebx
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 4d8:	89 d1                	mov    %edx,%ecx
{
 4da:	83 ec 3c             	sub    $0x3c,%esp
 4dd:	89 45 c0             	mov    %eax,-0x40(%ebp)
  if(sgn && xx < 0){
 4e0:	85 d2                	test   %edx,%edx
 4e2:	0f 89 80 00 00 00    	jns    568 <printint+0x98>
 4e8:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 4ec:	74 7a                	je     568 <printint+0x98>
    x = -xx;
 4ee:	f7 d9                	neg    %ecx
    neg = 1;
 4f0:	b8 01 00 00 00       	mov    $0x1,%eax
  } else {
    x = xx;
  }

  i = 0;
 4f5:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 4f8:	31 f6                	xor    %esi,%esi
 4fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 500:	89 c8                	mov    %ecx,%eax
 502:	31 d2                	xor    %edx,%edx
 504:	89 f7                	mov    %esi,%edi
 506:	f7 f3                	div    %ebx
 508:	8d 76 01             	lea    0x1(%esi),%esi
 50b:	0f b6 92 84 09 00 00 	movzbl 0x984(%edx),%edx
 512:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 516:	89 ca                	mov    %ecx,%edx
 518:	89 c1                	mov    %eax,%ecx
 51a:	39 da                	cmp    %ebx,%edx
 51c:	73 e2                	jae    500 <printint+0x30>
  if(neg)
 51e:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 521:	85 c0                	test   %eax,%eax
 523:	74 07                	je     52c <printint+0x5c>
    buf[i++] = '-';
 525:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)

  while(--i >= 0)
 52a:	89 f7                	mov    %esi,%edi
 52c:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 52f:	8b 75 c0             	mov    -0x40(%ebp),%esi
 532:	01 df                	add    %ebx,%edi
 534:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    putc(fd, buf[i]);
 538:	0f b6 07             	movzbl (%edi),%eax
  write(fd, &c, 1);
 53b:	83 ec 04             	sub    $0x4,%esp
 53e:	88 45 d7             	mov    %al,-0x29(%ebp)
 541:	8d 45 d7             	lea    -0x29(%ebp),%eax
 544:	6a 01                	push   $0x1
 546:	50                   	push   %eax
 547:	56                   	push   %esi
 548:	e8 a6 fe ff ff       	call   3f3 <write>
  while(--i >= 0)
 54d:	89 f8                	mov    %edi,%eax
 54f:	83 c4 10             	add    $0x10,%esp
 552:	83 ef 01             	sub    $0x1,%edi
 555:	39 c3                	cmp    %eax,%ebx
 557:	75 df                	jne    538 <printint+0x68>
}
 559:	8d 65 f4             	lea    -0xc(%ebp),%esp
 55c:	5b                   	pop    %ebx
 55d:	5e                   	pop    %esi
 55e:	5f                   	pop    %edi
 55f:	5d                   	pop    %ebp
 560:	c3                   	ret
 561:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 568:	31 c0                	xor    %eax,%eax
 56a:	eb 89                	jmp    4f5 <printint+0x25>
 56c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000570 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 570:	55                   	push   %ebp
 571:	89 e5                	mov    %esp,%ebp
 573:	57                   	push   %edi
 574:	56                   	push   %esi
 575:	53                   	push   %ebx
 576:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 579:	8b 75 0c             	mov    0xc(%ebp),%esi
{
 57c:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i = 0; fmt[i]; i++){
 57f:	0f b6 1e             	movzbl (%esi),%ebx
 582:	83 c6 01             	add    $0x1,%esi
 585:	84 db                	test   %bl,%bl
 587:	74 67                	je     5f0 <printf+0x80>
 589:	8d 4d 10             	lea    0x10(%ebp),%ecx
 58c:	31 d2                	xor    %edx,%edx
 58e:	89 4d d0             	mov    %ecx,-0x30(%ebp)
 591:	eb 34                	jmp    5c7 <printf+0x57>
 593:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 598:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 59b:	ba 25 00 00 00       	mov    $0x25,%edx
      if(c == '%'){
 5a0:	83 f8 25             	cmp    $0x25,%eax
 5a3:	74 18                	je     5bd <printf+0x4d>
  write(fd, &c, 1);
 5a5:	83 ec 04             	sub    $0x4,%esp
 5a8:	8d 45 e7             	lea    -0x19(%ebp),%eax
 5ab:	88 5d e7             	mov    %bl,-0x19(%ebp)
 5ae:	6a 01                	push   $0x1
 5b0:	50                   	push   %eax
 5b1:	57                   	push   %edi
 5b2:	e8 3c fe ff ff       	call   3f3 <write>
 5b7:	8b 55 d4             	mov    -0x2c(%ebp),%edx
      } else {
        putc(fd, c);
 5ba:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 5bd:	0f b6 1e             	movzbl (%esi),%ebx
 5c0:	83 c6 01             	add    $0x1,%esi
 5c3:	84 db                	test   %bl,%bl
 5c5:	74 29                	je     5f0 <printf+0x80>
    c = fmt[i] & 0xff;
 5c7:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 5ca:	85 d2                	test   %edx,%edx
 5cc:	74 ca                	je     598 <printf+0x28>
      }
    } else if(state == '%'){
 5ce:	83 fa 25             	cmp    $0x25,%edx
 5d1:	75 ea                	jne    5bd <printf+0x4d>
      if(c == 'd'){
 5d3:	83 f8 25             	cmp    $0x25,%eax
 5d6:	0f 84 04 01 00 00    	je     6e0 <printf+0x170>
 5dc:	83 e8 63             	sub    $0x63,%eax
 5df:	83 f8 15             	cmp    $0x15,%eax
 5e2:	77 1c                	ja     600 <printf+0x90>
 5e4:	ff 24 85 2c 09 00 00 	jmp    *0x92c(,%eax,4)
 5eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 5f0:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5f3:	5b                   	pop    %ebx
 5f4:	5e                   	pop    %esi
 5f5:	5f                   	pop    %edi
 5f6:	5d                   	pop    %ebp
 5f7:	c3                   	ret
 5f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 5ff:	00 
  write(fd, &c, 1);
 600:	83 ec 04             	sub    $0x4,%esp
 603:	8d 55 e7             	lea    -0x19(%ebp),%edx
 606:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 60a:	6a 01                	push   $0x1
 60c:	52                   	push   %edx
 60d:	89 55 d4             	mov    %edx,-0x2c(%ebp)
 610:	57                   	push   %edi
 611:	e8 dd fd ff ff       	call   3f3 <write>
 616:	83 c4 0c             	add    $0xc,%esp
 619:	88 5d e7             	mov    %bl,-0x19(%ebp)
 61c:	6a 01                	push   $0x1
 61e:	8b 55 d4             	mov    -0x2c(%ebp),%edx
 621:	52                   	push   %edx
 622:	57                   	push   %edi
 623:	e8 cb fd ff ff       	call   3f3 <write>
        putc(fd, c);
 628:	83 c4 10             	add    $0x10,%esp
      state = 0;
 62b:	31 d2                	xor    %edx,%edx
 62d:	eb 8e                	jmp    5bd <printf+0x4d>
 62f:	90                   	nop
        printint(fd, *ap, 16, 0);
 630:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 633:	83 ec 0c             	sub    $0xc,%esp
 636:	b9 10 00 00 00       	mov    $0x10,%ecx
 63b:	8b 13                	mov    (%ebx),%edx
 63d:	6a 00                	push   $0x0
 63f:	89 f8                	mov    %edi,%eax
        ap++;
 641:	83 c3 04             	add    $0x4,%ebx
        printint(fd, *ap, 16, 0);
 644:	e8 87 fe ff ff       	call   4d0 <printint>
        ap++;
 649:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 64c:	83 c4 10             	add    $0x10,%esp
      state = 0;
 64f:	31 d2                	xor    %edx,%edx
 651:	e9 67 ff ff ff       	jmp    5bd <printf+0x4d>
        s = (char*)*ap;
 656:	8b 45 d0             	mov    -0x30(%ebp),%eax
 659:	8b 18                	mov    (%eax),%ebx
        ap++;
 65b:	83 c0 04             	add    $0x4,%eax
 65e:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 661:	85 db                	test   %ebx,%ebx
 663:	0f 84 87 00 00 00    	je     6f0 <printf+0x180>
        while(*s != 0){
 669:	0f b6 03             	movzbl (%ebx),%eax
      state = 0;
 66c:	31 d2                	xor    %edx,%edx
        while(*s != 0){
 66e:	84 c0                	test   %al,%al
 670:	0f 84 47 ff ff ff    	je     5bd <printf+0x4d>
 676:	8d 55 e7             	lea    -0x19(%ebp),%edx
 679:	89 75 d4             	mov    %esi,-0x2c(%ebp)
 67c:	89 de                	mov    %ebx,%esi
 67e:	89 d3                	mov    %edx,%ebx
  write(fd, &c, 1);
 680:	83 ec 04             	sub    $0x4,%esp
 683:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 686:	83 c6 01             	add    $0x1,%esi
  write(fd, &c, 1);
 689:	6a 01                	push   $0x1
 68b:	53                   	push   %ebx
 68c:	57                   	push   %edi
 68d:	e8 61 fd ff ff       	call   3f3 <write>
        while(*s != 0){
 692:	0f b6 06             	movzbl (%esi),%eax
 695:	83 c4 10             	add    $0x10,%esp
 698:	84 c0                	test   %al,%al
 69a:	75 e4                	jne    680 <printf+0x110>
      state = 0;
 69c:	8b 75 d4             	mov    -0x2c(%ebp),%esi
 69f:	31 d2                	xor    %edx,%edx
 6a1:	e9 17 ff ff ff       	jmp    5bd <printf+0x4d>
        printint(fd, *ap, 10, 1);
 6a6:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 6a9:	83 ec 0c             	sub    $0xc,%esp
 6ac:	b9 0a 00 00 00       	mov    $0xa,%ecx
 6b1:	8b 13                	mov    (%ebx),%edx
 6b3:	6a 01                	push   $0x1
 6b5:	eb 88                	jmp    63f <printf+0xcf>
        putc(fd, *ap);
 6b7:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  write(fd, &c, 1);
 6ba:	83 ec 04             	sub    $0x4,%esp
 6bd:	8d 55 e7             	lea    -0x19(%ebp),%edx
        putc(fd, *ap);
 6c0:	8b 03                	mov    (%ebx),%eax
        ap++;
 6c2:	83 c3 04             	add    $0x4,%ebx
        putc(fd, *ap);
 6c5:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6c8:	6a 01                	push   $0x1
 6ca:	52                   	push   %edx
 6cb:	57                   	push   %edi
 6cc:	e8 22 fd ff ff       	call   3f3 <write>
        ap++;
 6d1:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 6d4:	83 c4 10             	add    $0x10,%esp
      state = 0;
 6d7:	31 d2                	xor    %edx,%edx
 6d9:	e9 df fe ff ff       	jmp    5bd <printf+0x4d>
 6de:	66 90                	xchg   %ax,%ax
  write(fd, &c, 1);
 6e0:	83 ec 04             	sub    $0x4,%esp
 6e3:	88 5d e7             	mov    %bl,-0x19(%ebp)
 6e6:	8d 55 e7             	lea    -0x19(%ebp),%edx
 6e9:	6a 01                	push   $0x1
 6eb:	e9 31 ff ff ff       	jmp    621 <printf+0xb1>
 6f0:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 6f5:	bb 24 09 00 00       	mov    $0x924,%ebx
 6fa:	e9 77 ff ff ff       	jmp    676 <printf+0x106>
 6ff:	90                   	nop

00000700 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 700:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 701:	a1 30 0c 00 00       	mov    0xc30,%eax
{
 706:	89 e5                	mov    %esp,%ebp
 708:	57                   	push   %edi
 709:	56                   	push   %esi
 70a:	53                   	push   %ebx
 70b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 70e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 711:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 718:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 71a:	39 c8                	cmp    %ecx,%eax
 71c:	73 32                	jae    750 <free+0x50>
 71e:	39 d1                	cmp    %edx,%ecx
 720:	72 04                	jb     726 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 722:	39 d0                	cmp    %edx,%eax
 724:	72 32                	jb     758 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
 726:	8b 73 fc             	mov    -0x4(%ebx),%esi
 729:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 72c:	39 fa                	cmp    %edi,%edx
 72e:	74 30                	je     760 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 730:	89 53 f8             	mov    %edx,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 733:	8b 50 04             	mov    0x4(%eax),%edx
 736:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 739:	39 f1                	cmp    %esi,%ecx
 73b:	74 3a                	je     777 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 73d:	89 08                	mov    %ecx,(%eax)
  } else
    p->s.ptr = bp;
  freep = p;
}
 73f:	5b                   	pop    %ebx
  freep = p;
 740:	a3 30 0c 00 00       	mov    %eax,0xc30
}
 745:	5e                   	pop    %esi
 746:	5f                   	pop    %edi
 747:	5d                   	pop    %ebp
 748:	c3                   	ret
 749:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 750:	39 d0                	cmp    %edx,%eax
 752:	72 04                	jb     758 <free+0x58>
 754:	39 d1                	cmp    %edx,%ecx
 756:	72 ce                	jb     726 <free+0x26>
{
 758:	89 d0                	mov    %edx,%eax
 75a:	eb bc                	jmp    718 <free+0x18>
 75c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 760:	03 72 04             	add    0x4(%edx),%esi
 763:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 766:	8b 10                	mov    (%eax),%edx
 768:	8b 12                	mov    (%edx),%edx
 76a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 76d:	8b 50 04             	mov    0x4(%eax),%edx
 770:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 773:	39 f1                	cmp    %esi,%ecx
 775:	75 c6                	jne    73d <free+0x3d>
    p->s.size += bp->s.size;
 777:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 77a:	a3 30 0c 00 00       	mov    %eax,0xc30
    p->s.size += bp->s.size;
 77f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 782:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 785:	89 08                	mov    %ecx,(%eax)
}
 787:	5b                   	pop    %ebx
 788:	5e                   	pop    %esi
 789:	5f                   	pop    %edi
 78a:	5d                   	pop    %ebp
 78b:	c3                   	ret
 78c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000790 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 790:	55                   	push   %ebp
 791:	89 e5                	mov    %esp,%ebp
 793:	57                   	push   %edi
 794:	56                   	push   %esi
 795:	53                   	push   %ebx
 796:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 799:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 79c:	8b 15 30 0c 00 00    	mov    0xc30,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7a2:	8d 78 07             	lea    0x7(%eax),%edi
 7a5:	c1 ef 03             	shr    $0x3,%edi
 7a8:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 7ab:	85 d2                	test   %edx,%edx
 7ad:	0f 84 8d 00 00 00    	je     840 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7b3:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 7b5:	8b 48 04             	mov    0x4(%eax),%ecx
 7b8:	39 f9                	cmp    %edi,%ecx
 7ba:	73 64                	jae    820 <malloc+0x90>
  if(nu < 4096)
 7bc:	bb 00 10 00 00       	mov    $0x1000,%ebx
 7c1:	39 df                	cmp    %ebx,%edi
 7c3:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 7c6:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 7cd:	eb 0a                	jmp    7d9 <malloc+0x49>
 7cf:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7d0:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 7d2:	8b 48 04             	mov    0x4(%eax),%ecx
 7d5:	39 f9                	cmp    %edi,%ecx
 7d7:	73 47                	jae    820 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7d9:	89 c2                	mov    %eax,%edx
 7db:	3b 05 30 0c 00 00    	cmp    0xc30,%eax
 7e1:	75 ed                	jne    7d0 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 7e3:	83 ec 0c             	sub    $0xc,%esp
 7e6:	56                   	push   %esi
 7e7:	e8 6f fc ff ff       	call   45b <sbrk>
  if(p == (char*)-1)
 7ec:	83 c4 10             	add    $0x10,%esp
 7ef:	83 f8 ff             	cmp    $0xffffffff,%eax
 7f2:	74 1c                	je     810 <malloc+0x80>
  hp->s.size = nu;
 7f4:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 7f7:	83 ec 0c             	sub    $0xc,%esp
 7fa:	83 c0 08             	add    $0x8,%eax
 7fd:	50                   	push   %eax
 7fe:	e8 fd fe ff ff       	call   700 <free>
  return freep;
 803:	8b 15 30 0c 00 00    	mov    0xc30,%edx
      if((p = morecore(nunits)) == 0)
 809:	83 c4 10             	add    $0x10,%esp
 80c:	85 d2                	test   %edx,%edx
 80e:	75 c0                	jne    7d0 <malloc+0x40>
        return 0;
  }
}
 810:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 813:	31 c0                	xor    %eax,%eax
}
 815:	5b                   	pop    %ebx
 816:	5e                   	pop    %esi
 817:	5f                   	pop    %edi
 818:	5d                   	pop    %ebp
 819:	c3                   	ret
 81a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 820:	39 cf                	cmp    %ecx,%edi
 822:	74 4c                	je     870 <malloc+0xe0>
        p->s.size -= nunits;
 824:	29 f9                	sub    %edi,%ecx
 826:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 829:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 82c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 82f:	89 15 30 0c 00 00    	mov    %edx,0xc30
}
 835:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 838:	83 c0 08             	add    $0x8,%eax
}
 83b:	5b                   	pop    %ebx
 83c:	5e                   	pop    %esi
 83d:	5f                   	pop    %edi
 83e:	5d                   	pop    %ebp
 83f:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 840:	c7 05 30 0c 00 00 34 	movl   $0xc34,0xc30
 847:	0c 00 00 
    base.s.size = 0;
 84a:	b8 34 0c 00 00       	mov    $0xc34,%eax
    base.s.ptr = freep = prevp = &base;
 84f:	c7 05 34 0c 00 00 34 	movl   $0xc34,0xc34
 856:	0c 00 00 
    base.s.size = 0;
 859:	c7 05 38 0c 00 00 00 	movl   $0x0,0xc38
 860:	00 00 00 
    if(p->s.size >= nunits){
 863:	e9 54 ff ff ff       	jmp    7bc <malloc+0x2c>
 868:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 86f:	00 
        prevp->s.ptr = p->s.ptr;
 870:	8b 08                	mov    (%eax),%ecx
 872:	89 0a                	mov    %ecx,(%edx)
 874:	eb b9                	jmp    82f <malloc+0x9f>
