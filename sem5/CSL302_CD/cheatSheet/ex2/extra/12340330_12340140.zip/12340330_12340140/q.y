%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *s);
int yylex(void);
extern FILE* yyin;
extern int yylineno;
int has_main = 0;
%}

%token TYPE
%token FOR
%token IF
%token ELSE
%token DO WHILE
%token BOOLEAN
%token IDENTIFIER
%token KEYWORD
%token RETURN BREAK CLASS NEW NEW_ARRAY
%token DOT COMMA
%token SINGLE_COMMENT MULTI_COMMENT
%token STRING INTEGER DOUBLE
%token COLON SEMICOLON
%token AND OR
%token ADD SUBTRACT MULTIPLY DIVIDE REM ASSGN NEG
%token LT GT LE GE EQ NE
%token LEFT_BRAC RIGHT_BRAC
%token LEFT_PAREN RIGHT_PAREN
%token LEFT_SQUARE RIGHT_SQUARE

%union {
    char* str;
}

%start PROGRAM
%type <str> IDENTIFIER
%type <str> KEYWORD
%type <str> STRING
%type <str> INTEGER
%type <str> DOUBLE
%type <str> BOOLEAN
%type <str> TYPE
%type <str> EXPRESSION
%type <str> LEFT_BRAC
%type <str> RIGHT_BRAC
%type <str> LEFT_PAREN
%type <str> RIGHT_PAREN
%type <str> LEFT_SQUARE
%type <str> RIGHT_SQUARE

%right ASSGN

%left OR
%left AND
%nonassoc EQ NE
%nonassoc LT GT LE GE
%left ADD SUBTRACT
%left MULTIPLY DIVIDE REM
%right UMINUS NEGATE
%left DOT LEFT_SQUARE RIGHT_SQUARE

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%
PROGRAM:
    DECLARATIONS {
        if (!has_main) {
            fprintf(stderr, "Error: no main function defined\n");
            YYABORT;
        }
    }
    ;

DECLARATIONS:
    DECLARATIONS DECLARATION
    | DECLARATION
    ;

DECLARATION:
    VarDecl
    | FunDecl
    | ClassDecl
    ;

VarDecl:
    TYPE IDENTIFIER SEMICOLON
    | IDENTIFIER IDENTIFIER NEW LEFT_BRAC IDENTIFIER RIGHT_BRAC SEMICOLON
    | IDENTIFIER NEW_ARRAY LEFT_BRAC INTEGER COMMA TYPE RIGHT_BRAC SEMICOLON
    ;

FunDecl:
    TYPE IDENTIFIER LEFT_BRAC FORMAL_PARAMETERS RIGHT_BRAC STMT_BLOCK
    | TYPE IDENTIFIER LEFT_BRAC RIGHT_BRAC STMT_BLOCK {
        if (strcmp($2, "main") == 0 && strcmp($1, "void") == 0 ){
            has_main = 1;
        }
    }
    ;

FORMAL_PARAMETERS:
    FORMAL_PARAMETERS COMMA FORMAL_PARAMETER
    | FORMAL_PARAMETER
    ;

FORMAL_PARAMETER:
    TYPE IDENTIFIER
    | IDENTIFIER NEW_ARRAY LEFT_BRAC INTEGER COMMA TYPE RIGHT_BRAC
    ;

ClassDecl:
    CLASS IDENTIFIER LEFT_PAREN FIELDS RIGHT_PAREN
    ;

FIELDS:
      FIELDS FIELD
      | FIELD;

FIELD:
     VarDecl
     | FunDecl
     ;

STMT_BLOCK:
    LEFT_PAREN STMTS RIGHT_PAREN
    | LEFT_PAREN RIGHT_PAREN
    ;

STMTS:
     STMTS STMT
     | STMT
     ;

STMT:
    VarDecl
    | STATEMENT
    ;

STATEMENT:
    EXPRESSION SEMICOLON
    | IF_STMT
    | WHILE_STMT
    | DO_WHILE_STMT
    | FOR_STMT
    | BREAK_STMT
    | RETURN_STMT
    | STMT_BLOCK
    ;

EXPRESSION:
    LVAL ASSGN EXPRESSION
    | EXPRESSION OR EXPRESSION
    | EXPRESSION AND EXPRESSION
    | EXPRESSION EQ EXPRESSION
    | EXPRESSION NE EXPRESSION
    | EXPRESSION LT EXPRESSION
    | EXPRESSION GT EXPRESSION
    | EXPRESSION LE EXPRESSION
    | EXPRESSION GE EXPRESSION
    | EXPRESSION ADD EXPRESSION
    | EXPRESSION SUBTRACT EXPRESSION
    | EXPRESSION MULTIPLY EXPRESSION
    | EXPRESSION DIVIDE EXPRESSION
    | EXPRESSION REM EXPRESSION
    | SUBTRACT EXPRESSION %prec UMINUS
    | NEG EXPRESSION %prec NEGATE
    | EXPRESSION DOT IDENTIFIER
    | EXPRESSION LEFT_SQUARE EXPRESSION RIGHT_SQUARE
    | '(' EXPRESSION ')'
    | NEW LEFT_BRAC IDENTIFIER RIGHT_BRAC
    | IDENTIFIER LEFT_BRAC ACTUAL_PARAMETERS RIGHT_BRAC
    | EXPRESSION DOT IDENTIFIER LEFT_BRAC ACTUAL_PARAMETERS RIGHT_BRAC
    | IDENTIFIER
    | INTEGER
    | DOUBLE
    | STRING
    | BOOLEAN
    ;

LVAL:
    IDENTIFIER
    | EXPRESSION DOT IDENTIFIER
    | EXPRESSION LEFT_SQUARE EXPRESSION RIGHT_SQUARE
    ;

ACTUAL_PARAMETERS:
    ACTUAL_PARAMETERS COMMA ACTUAL_PARAMETER
    | ACTUAL_PARAMETER
    ;

ACTUAL_PARAMETER:
    EXPRESSION
    ;

IF_STMT:
    IF LEFT_BRAC EXPRESSION RIGHT_BRAC STMT ELSE STMT
    | IF LEFT_BRAC EXPRESSION RIGHT_BRAC STMT %prec LOWER_THAN_ELSE
    ;

WHILE_STMT:
    WHILE LEFT_BRAC EXPRESSION RIGHT_BRAC STMT
    ;

FOR_STMT:
    FOR LEFT_BRAC EXPRESSION SEMICOLON EXPRESSION SEMICOLON EXPRESSION RIGHT_BRAC STMT
    ;

RETURN_STMT:
    RETURN EXPRESSION SEMICOLON
    ;

BREAK_STMT:
    BREAK SEMICOLON
    ;

DO_WHILE_STMT:
    DO STMT WHILE LEFT_BRAC EXPRESSION RIGHT_BRAC SEMICOLON
    ;

%%

int main(int argc, char* argv[]) {
    if (argc == 2){
        FILE* fp = fopen(argv[1],"r");
        if (!fp) {
            perror(argv[1]);
            return 1;
        }
        yyin = fp;
    }else{
        printf("Enter code here:\n");
    }
    int result = yyparse();
    if (result == 0){
        printf("Parsing successful\n");
    }else{
        printf("Parsing failed\n");
    }
    if (argc == 2){
        fclose(yyin);
    }
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error at line %d: %s\n", yylineno, s);
}