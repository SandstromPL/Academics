Name: Agastya Nath
Roll No.: 12340140
Course: CSL302 – Compiler Design

Lab 10 Assignment:

I. Files included:
    1. symbol.c (source file for implementing symbol table and static scoping)
    2. symbol.h (header file for implementing symbol table and static scoping)
    3. ast.h (for definitions of list, exprStruct and arglist)
    4. analyzer.l (Lex/Flex analyzer)
    5. parser.y (Yacc/Bison parser)
    6. exp.txt (for demo)
    7. README.txt (this file; for further instructions and knowledge)

II. Instructions to generate the parser:
    1. Compile ./analyzer.l with lex as follows:
        lex ./analyzer.l
    2. Compile ./parser.y with yacc (with option -d) as follows:
        yacc -d ./parser.y
    3. Compile the resultant ./lex.yy.c and ./y.tab.c with gcc along with ./symbol.c as follows:
        gcc ./lex.yy.c ./y.tab.c ./symbol.c
    4. The resultant executable from gcc (./a.out) is the parser.

III. How to use:
    It can be used either interactively (i.e. without any commandline arguments) or with an argument (as source file name passed as argument).
    
    1. If used interactively, enter ./a.out. After that, Enter source code line-by-line until an error is detected (then it detects it with an error and exits). If you 
    want to manually exit the parser, just press Ctrl-C. 

    IMP: Unfortunately, this will not show the generated TAC code.

    2. If used with a source file, enter ./a.out file_name.txt (eg. ./a.out ./exp.txt). Then it prints all the lines of information and then
    at the end it tells you whether the code is syntactically correct or not.

    IMP: Only to use this method to show generated TAC code.

IV. Assumptions:
    1. Only int and float are supported.
    2. No function scopes implemented.
    3. TAC generation is printed directly; not stored.
    4. Scope management and symbol table implemented.
    5. Memory for symbols freed only on scope exit.
    6. Static scope implemented.
    7. If, if-else and while loops handled well.
    8. Backpatching implemented for boolean relation operators, if-then, if-then-else and while loops.
    9. TAC code generation for function invocation with argument list (with zero or non-zero parameter arguments in it) implemented.

V. Example:

Example file: ./exp.txt


int a, b, c;
float d, e, f;

a = b + c * d - e/f *g -h;
if a < b then
{
    c = a + b;
    d = not c or d >= f;
}
else
{
    c = a - b;
}

while a < b and c >= d do
{
    a = a + 1;
    d = e or f >= g and not f;
}

if o and not p <= q and l != m then {r = k/q - b*d - e + f*g; l = m > n and o <= p;} else {q = s-t/d*r; k = o and not p or q >= w;}

d = f and g > h or k <= u or not t;

a = 10;
b = 20;
add(a, b);

functionZeroParameters();
print(x, y*4, a+b);
printf(x-y, y*z-a+b+d/e-f*g+q, p-r);

Enter: ./a.out ./exp.txt

Output: 

Declared a of type int in scope 1
Declared b of type int in scope 1
Declared c of type int in scope 1
Declared d of type float in scope 1
Declared e of type float in scope 1
Declared f of type float in scope 1
100: t1 = g - h
101: t2 = f * t1
102: t3 = e / t2
103: t4 = d - t3
104: t5 = c * t4
105: t6 = b + t5
106: a = t6
107: if a < b goto _
108: goto _
Entered new scope 2
109: t7 = a + b
110: c = t7
111: if c != 0 goto _
112: goto _
113: if d >= f goto _
114: goto _
Backpatching quad 112 with 115
Backpatching quad 114 with 115
115: d = 1
116: goto _
Backpatching quad 111 with 117
Backpatching quad 113 with 117
117: d = 0
Backpatching quad 116 with 118
Exited scope
118: goto _
Entered new scope 3
119: t8 = a - b
120: c = t8
Exited scope
Backpatching quad 107 with 109
Backpatching quad 108 with 119
121: if a < b goto _
122: goto _
123: if c >= d goto _
124: goto _
Backpatching quad 121 with 125
Entered new scope 4
125: t9 = a + 1
126: a = t9
127: if e != 0 goto _
128: goto _
129: if f >= g goto _
130: goto _
Backpatching quad 128 with 131
131: if f != 0 goto _
132: goto _
Backpatching quad 127 with 133
Backpatching quad 129 with 133
Backpatching quad 132 with 133
133: d = 1
134: goto _
Backpatching quad 130 with 135
Backpatching quad 131 with 135
135: d = 0
Backpatching quad 134 with 136
Exited scope
Backpatching quad 123 with 125
136: goto 121
137: if o != 0 goto _
138: goto _
139: if p <= q goto _
140: goto _
141: if l != m goto _
142: goto _
Backpatching quad 139 with 143
Backpatching quad 137 with 143
Entered new scope 5
143: t10 = f * g
144: t11 = e + t10
145: t12 = d - t11
146: t13 = b * t12
147: t14 = q - t13
148: t15 = k / t14
149: r = t15
150: if m > n goto _
151: goto _
152: if o <= p goto _
153: goto _
Backpatching quad 150 with 154
Backpatching quad 152 with 154
154: l = 1
155: goto _
Backpatching quad 151 with 156
Backpatching quad 153 with 156
156: l = 0
Backpatching quad 155 with 157
Exited scope
157: goto _
Entered new scope 6
158: t16 = d * r
159: t17 = t / t16
160: t18 = s - t17
161: q = t18
162: if o != 0 goto _
163: goto _
164: if p != 0 goto _
165: goto _
166: if q >= w goto _
167: goto _
Backpatching quad 165 with 168
Backpatching quad 162 with 168
Backpatching quad 167 with 168
168: k = 1
169: goto _
Backpatching quad 163 with 170
Backpatching quad 164 with 170
Backpatching quad 166 with 170
170: k = 0
Backpatching quad 169 with 171
Exited scope
Backpatching quad 140 with 143
Backpatching quad 142 with 143
Backpatching quad 138 with 158
Backpatching quad 141 with 158
171: if f != 0 goto _
172: goto _
173: if g > h goto _
174: goto _
175: if k <= u goto _
176: goto _
Backpatching quad 174 with 177
177: if t != 0 goto _
178: goto _
Backpatching quad 176 with 179
Backpatching quad 171 with 179
Backpatching quad 173 with 179
Backpatching quad 175 with 179
Backpatching quad 178 with 179
179: d = 1
180: goto _
Backpatching quad 172 with 181
Backpatching quad 177 with 181
181: d = 0
Backpatching quad 180 with 182
182: a = 10
183: b = 20
184: param a
185: param b
186: t19 = call add, 2
187: t20 = call functionZeroParameters, 0
188: t21 = y * 4
189: t22 = a + b
190: param x
191: param t21
192: param t22
193: t23 = call print, 3
194: t24 = x - y
195: t25 = g + q
196: t26 = f * t25
197: t27 = e - t26
198: t28 = d / t27
199: t29 = b + t28
200: t30 = a + t29
201: t31 = z - t30
202: t32 = y * t31
203: t33 = p - r
204: param t24
205: param t32
206: param t33
207: t34 = call printf, 3

Generated Three-Address Code:
The above program is syntactically correct
