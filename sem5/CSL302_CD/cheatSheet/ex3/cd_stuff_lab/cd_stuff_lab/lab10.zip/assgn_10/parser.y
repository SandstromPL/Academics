%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol.h"
#include "ast.h"

int yylex(void);
void yyerror(const char *s);

int nextquad = 100;

void backpatch(list *l, int target) {
    char* tmp = (char*)malloc(1024);
    while(l) {
        printf("Backpatching quad %d with %d\n", l->quad, target);
        l = l->next;
    }
}

void emit(const char *s) {
    printf("%d: %s\n", nextquad++, s);
}

list *makelist(int i) {
    list *temp = (list*)malloc(sizeof(list));
    temp->quad = i;
    temp->next = NULL;
    return temp;
}

list *merge(list *l1, list *l2) {
    if(!l1) return l2;
    list *t = l1;
    while(t->next) t = t->next;
    t->next = l2;
    return l1;
}

arglist *make_arglist(char *place) {
    arglist *a = malloc(sizeof(arglist));
    a->place = strdup(place);
    a->count = 1;
    a->next = NULL;
    return a;
}

arglist *append_arg(arglist *list, char *place) {
    arglist *a = make_arglist(place);
    if (!list) return a;
    arglist *p = list;
    while (p->next) p = p->next;
    p->next = a;
    list->count++;
    return list;
}

void emit_param(const char *arg) {
    char buf[64];
    sprintf(buf, "param %s", arg);
    emit(buf);
}


int temp_count = 1;
char* new_temp() {
    char *temp = (char*)malloc(16);
    sprintf(temp, "t%d", temp_count++);
    return temp;
}

int label_count = 1;
int new_label(){
    return label_count++;
}

char currentType[20];

int line_count = 1;
extern FILE* yyin;
extern int yylineno;

%}
%union {
    struct {
        list *truelist;
        list *falselist;
        list *nextlist;
        int quad;
    } boolattr;
    arglist *claire;
    int quilty;
    char *place;
}

%token INT FLOAT
%token FOR IF THEN ELSE ELIF SWITCH CASE DO WHILE
%token <place> ID
%token <place> RELOP
%token <place> NUM
%token EQUAL
%token AND OR NOT TRUE FALSE
%token SEMICOLON COMMA COLON
%token LEFT_BRAC RIGHT_BRAC
%token LEFT_PAREN RIGHT_PAREN
%token ADD SUBTRACT MUL DIV REM

%type <place> expr
%type <boolattr> declaration
%type <boolattr> stmt stmts BLOCK assgn_stmt
%type <boolattr> bool_expr
%type <boolattr> IF_LOOP WHILE_LOOP matched_if unmatched_if
%type <place> func_call
%type <claire> arg_list
%type <quilty> M
%type <boolattr> N

%right NOT
%left AND
%left OR

%start input

%%

input: stmts
       ;

stmts: stmt {$$ = $1;}
       | stmts stmt {$$ = $2;}
       ;

stmt: assgn_stmt { $$.nextlist = NULL; }
    | declaration { $$.nextlist = NULL; }
    | IF_LOOP { $$ = $1; }
    | WHILE_LOOP { $$ = $1; }
    | BLOCK { $$ = $1; }
    | func_call SEMICOLON { $$.nextlist = NULL; }
    ;

assgn_stmt: ID EQUAL expr SEMICOLON {
        char buf[128]; sprintf(buf, "%s = %s", $1, $3); emit(buf);
        $$.nextlist = NULL;        
    }
    | ID EQUAL bool_expr SEMICOLON {
        backpatch($3.truelist, nextquad);
    char buf1[64];
    sprintf(buf1, "%s = 1", $1);
    emit(buf1);

    list *skip = makelist(nextquad);
    emit("goto _");

    backpatch($3.falselist, nextquad);
    char buf2[64];
    sprintf(buf2, "%s = 0", $1);
    emit(buf2);

    backpatch(skip, nextquad);
    $$.nextlist = NULL;
        
    }
    ;

BLOCK:
     LEFT_PAREN { enterScope(); } stmts RIGHT_PAREN { $$ = $3; exitScope(); }
     ;

declaration:
        type id_list SEMICOLON {
            $$.nextlist = NULL;
        }
        ;

type:
        INT   { strcpy(currentType, "int"); }
      | FLOAT { strcpy(currentType, "float"); }
      ;

id_list:
        ID  { 
            addSymbol($1, currentType);
        }
        | id_list COMMA ID   { 
            addSymbol($3, currentType);
        }
        ;

expr: expr ADD expr {

		    char* temp = new_temp();
            char buf[64];
            sprintf(buf, "%s = %s + %s", temp, $1, $3);
            emit(buf);
            $$ = strdup(temp);
      }
      | expr SUBTRACT expr {
        char* temp = new_temp();
            char buf[64];
            sprintf(buf, "%s = %s - %s", temp, $1, $3);
            emit(buf);
            $$ = strdup(temp);

      }
      |expr MUL expr {
        char* temp = new_temp();
            char buf[64];
            sprintf(buf, "%s = %s * %s", temp, $1, $3);
            emit(buf);
            $$ = strdup(temp);

      }
      |expr DIV expr {
        char* temp = new_temp();
            char buf[64];
            sprintf(buf, "%s = %s / %s", temp, $1, $3);
            emit(buf);
            $$ = strdup(temp);

      }
      |expr REM expr {
        char* temp = new_temp();
            char buf[64];
            sprintf(buf, "%s = %s %% %s", temp, $1, $3);
            emit(buf);
            $$ = strdup(temp);

      }
      | LEFT_BRAC expr RIGHT_BRAC {
		$$ = strdup($2);
      }
      | ID {
            $$ = strdup($1);

     }
     | NUM {
            $$ = strdup($1);

     }
     ;

bool_expr: expr RELOP expr {

            $$.truelist = makelist(nextquad);
            $$.falselist = makelist(nextquad + 1);
            char buf1[128], buf2[32];
            sprintf(buf1, "if %s %s %s goto _", $1, $2, $3);
            sprintf(buf2, "goto _");
            emit(buf1); emit(buf2);

      }
    | bool_expr AND bool_expr {
            int m = nextquad; 
            backpatch($1.truelist, m);
            $$.truelist = $3.truelist;
            $$.falselist = merge($1.falselist, $3.falselist);

     }
     | bool_expr OR bool_expr {
            int m = nextquad;
            backpatch($1.falselist, m);
            $$.truelist = merge($1.truelist, $3.truelist);
            $$.falselist = $3.falselist;

     }
     | NOT bool_expr {
            $$.truelist = $2.falselist;
            $$.falselist = $2.truelist;
     }
     | TRUE {
            $$.truelist = makelist(nextquad);
            $$.falselist = NULL;
            emit("goto _");

    }
     | FALSE {
            $$.truelist = NULL;
            $$.falselist = makelist(nextquad);
            emit("goto _");

     }
     | LEFT_BRAC bool_expr RIGHT_BRAC {
		$$ = $2;

    }
    | expr {
        $$.truelist = makelist(nextquad);
        $$.falselist = makelist(nextquad + 1);
        char buf1[64], buf2[64];
        sprintf(buf1, "if %s != 0 goto _", $1);
        sprintf(buf2, "goto _");
        emit(buf1);
        emit(buf2);
    
    }
     ;

IF_LOOP:
      matched_if  { $$.nextlist = $1.nextlist; } 
    | unmatched_if { $$.nextlist = $1.nextlist; }
    ;

matched_if:
      IF bool_expr THEN M matched_if N ELSE M matched_if
        {
            backpatch($2.truelist, $4);   
            backpatch($2.falselist, $8);  
            $$.nextlist = merge($6.nextlist, merge($5.nextlist, $9.nextlist));
        }
    | assgn_stmt { $$.nextlist = $1.nextlist; }
    | BLOCK     { $$.nextlist = $1.nextlist; }
    ;

unmatched_if:
      IF bool_expr THEN M stmt
        {
            backpatch($2.truelist, $4);
            $$.nextlist = merge($2.falselist, $5.nextlist);
        }
    | IF bool_expr THEN M matched_if N ELSE M unmatched_if
        {
            backpatch($2.truelist, $4);
            backpatch($2.falselist, $8);
            $$.nextlist = merge($6.nextlist, merge($5.nextlist, $9.nextlist));
        }
    ;

WHILE_LOOP:
     WHILE M bool_expr DO M stmt  {
            backpatch($3.truelist, $5);   
        backpatch($6.nextlist, $2);   
        $$.nextlist = $3.falselist;          
        char buf[32]; sprintf(buf, "goto %d", $2);
        emit(buf);                          
            
     }
     ;

M : 
        { $$ = nextquad; }
    ;

N : 
        {
            $$.nextlist = makelist(nextquad);
            emit("goto _");        

        }
    ;

func_call: ID LEFT_BRAC arg_list RIGHT_BRAC 
         {
            for (arglist *p = $3; p != NULL; p = p->next)
              emit_param(p->place);

          char *temp = new_temp();
          char buf[128];
          sprintf(buf, "%s = call %s, %d", temp, $1, $3 ? $3->count : 0);
          emit(buf);

          $$ = strdup(temp);
         }

arg_list:
      /* empty */ { $$ = NULL; }
    | expr { $$ = make_arglist($1); }
    | arg_list COMMA expr { $$ = append_arg($1, $3); }
    ;

%%

int main(int argc, char* argv[]) {
    if (argc == 2){
        FILE* fp = fopen(argv[1],"r");
        if (!fp) {
            perror(argv[1]);
            return 1;
        }
        yyin = fp;
    }else{
        printf("Parser is in interactive mode\n");
        printf("Add code sequentially and if at any point code comes out to be wrong then the user is immediately alerted with Syntax Error\n");
        printf("Here's some example code: ");
        printf("int a, b, c;\n");
        printf("float d, e, f;\n");
        printf("\n");
        printf("a = b + c * d - e/f *g -h;\n");
        printf("if a < b then\n");
        printf("{\n");
        printf("    c = a + b;\n");
        printf("    d = not c or d >= f;\n");
        printf("}\n");
        printf("else\n");
        printf("{\n");
        printf("    c = a - b;\n");
        printf("}\n");
        printf("\n");
        printf("while a < b and c >= d do\n");
        printf("{\n");
        printf("    a = a + 1;\n");
        printf("    d = e or f >= g and not f;\n");
        printf("}\n");
        printf("\n");
        printf("if o and not p <= q and l != m then {r = k/q - b*d - e + f*g; l = m > n and o <= p;} else {q = s-t/d*r; k = o and not p or q >= w;}\n");
        printf("\n");
        printf("d = f and g > h or k <= u or not t;\n");
        printf("\n");
        printf("a = 10;\n");
        printf("b = 20;\n");
        printf("add(a, b);\n");
        printf("\n");
        printf("functionZeroParameters();\n");
        printf("printf(x, y*4, a+b);\n");
        printf("printf(x-y, y*z-a+b+d/e-f*g+q, p-r);\n");
        printf("Now enter: \n");
    }
    int result = yyparse();
    printf("\nGenerated Three-Address Code:\n");
    if (result == 0){
        printf("The above program is syntactically correct\n");
    }else{
        printf("The above program is syntactically not correct\n");
    }
    if (argc == 2){
        fclose(yyin);
    }
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}


