#ifndef AST_H
#define AST_H

typedef struct list {
    int quad;
    struct list *next;
} list;

typedef struct exprStruct {
    char *express;
    char *true_val;
    char *code;
    char *begin;
    char *next;
} exprStruct;

typedef struct arglist {
    char *place;
    int count;
    struct arglist *next;
} arglist;

#endif

