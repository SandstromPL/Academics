%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *s);
int yylex(void);
extern FILE* yyin;
extern int yylineno;
%}

%token ARITHMETIC_OPCODE
%token MEMORY_OPCODE
%token HALT
%token JUMP
%token COMPARE
%token LABEL
%token REGISTER
%token IMMEDIATE
%token COMMA COLON
%token ERROR

%union {
    char* str;
}

%start PROGRAM
%type <str> ARITHMETIC_OPCODE
%type <str> MEMORY_OPCODE
%type <str> LABEL
%type <str> REGISTER
%type <str> IMMEDIATE

%%

PROGRAM:
       STATEMENTS
       ;
       
STATEMENTS:
        STATEMENTS STATEMENT
        | STATEMENT;

STATEMENT:
        LABELLED_STATEMENT
        | UNLABELLED_STATEMENT
        | ERROR {
            fprintf(stderr, "Fatal lexical error at line %d\n", yylineno); 
            YYABORT;
        }
        ;

LABELLED_STATEMENT:
        LABEL COLON UNLABELLED_STATEMENT
        ;

UNLABELLED_STATEMENT:
        ARITHMETIC_STATEMENT
       | CONDITIONAL_STATEMENT
       | MEMORY_STATEMENT
       | HALT_STATEMENT
       ;

ARITHMETIC_STATEMENT:
        ARITHMETIC_OPCODE REGISTER COMMA REGISTER
        | ARITHMETIC_OPCODE REGISTER COMMA IMMEDIATE
        ;

CONDITIONAL_STATEMENT:
        JUMP LABEL
        ;

MEMORY_STATEMENT:
        MEMORY_OPCODE REGISTER COMMA IMMEDIATE
        ;

HALT_STATEMENT:
        HALT
        ;

%%

int main(int argc, char* argv[]) {
    if (argc == 2){
        FILE* fp = fopen(argv[1],"r");
        if (!fp) {
            perror(argv[1]);
            return 1;
        }
        yyin = fp;
    }else{
        printf("Enter assembly code here:\n");
    }
    int result = yyparse();
    if (result == 0){
        printf("The above program is syntactically correct\n");
    }else{
        printf("The above program is syntactically not correct\n");
    }
    if (argc == 2){
        fclose(yyin);
    }
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

