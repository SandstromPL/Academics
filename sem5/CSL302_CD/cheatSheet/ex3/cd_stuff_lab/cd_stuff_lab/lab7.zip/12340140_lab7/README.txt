Q.2.

To prepare the lexical analyzer for question 1:

1. Compile analyzer_assembly.l with flex as follows:
lex ./analyzer_assembly.l

2. Compile parser_assembly.y with bison as follows:
yacc -d ./parser_assembly.y

3. Compile the resultant file lex.yy.c with y.tab.c (generated from previous step) with the help of gcc as follows:
gcc ./lex.yy.c ./y.tab.c

4. Execute the resultant executable a.out as follows (executable takes in file as input):
./a.out sample.txt

This parser takes in assembly code entered by user as input file and creates tokens out of them and according to rules of assembly, parses it and checks for syntactic correctness.

The executable prints out the following line at the beginning (if no command line argument passed):
"Enter Assembly Code:"

The user has to enter each line of assembly code into the executable one-by-one and then press "ENTER" after entering a full line. 

The parser tokenizes parts of the line and then parses the token stream till the very end. At the end it tells whether written code is syntactically correct or not.

