#ifndef AST_H
#define AST_H

typedef struct exprStruct {
    char *express;
    char *true_val;
    char *false_val;
    char *code;
    char *begin;
    char *next;
} exprStruct;

#endif

