%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol.h"
#include "ast.h"

int yylex(void);
void yyerror(const char *s);

int temp_count = 1;
char* new_temp() {
    char *temp = (char*)malloc(16);
    sprintf(temp, "t%d", temp_count++);
    return temp;
}

int label_count = 1;
char* new_label(){
    char* temp = (char*)malloc(16);
    sprintf(temp, "L%d", label_count++);
    return temp;
}

exprStruct *root = NULL;

exprStruct* make_expr(void) {
    exprStruct *e = (exprStruct*)malloc(sizeof(exprStruct));
    if (!e) { perror("malloc"); exit(1); }
    e->express   = calloc(256,1);
    e->true_val  = calloc(64,1);
    e->false_val = calloc(64,1);
    e->code      = calloc(1024,1);
    e->begin     = calloc(64,1);
    e->next      = calloc(64,1);
    return e;
}

char currentType[20];

int line_count = 1;
extern FILE* yyin;
extern int yylineno;

%}
%union {
    char* str;
    exprStruct* struct_info;
}


%token INT FLOAT
%token FOR IF THEN ELSE ELIF SWITCH CASE DO WHILE
%token <str> ID
%token <str> NUM
%token EQUAL
%token AND OR NOT TRUE FALSE
%token SEMICOLON COMMA COLON
%token GE GT LE LT EEQ NEQ
%token LEFT_BRAC RIGHT_BRAC
%token LEFT_PAREN RIGHT_PAREN
%token ADD SUBTRACT MUL DIV REM

%type <struct_info> declaration;
%type <struct_info> BLOCK;
%type <struct_info> stmt;
%type <struct_info> stmts;
%type <struct_info> expr bool_expr;
%type <struct_info> IF_LOOP;
%type <struct_info> WHILE_LOOP;

%right NOT
%left AND
%left OR

%start input

%%

input: stmts{ root = $1; }
       ;

stmts: stmt { $$ = $1; }
       | stmts stmt { 
            $$ = make_expr();
            snprintf($$->code, 1023, "%s%s", $1->code, $2->code);

        }
       ;

stmt: ID EQUAL expr SEMICOLON {
        $$ = make_expr();
        sprintf($$->code, "%s%s = %s\n", $3->code, $1, $3->express);

    }
    | ID EQUAL bool_expr SEMICOLON {
        $$ = make_expr();
        char *end = new_label();
        snprintf($$->code, 1023, "%s%s:\n%s = 1\ngoto %s\n%s:\n%s = 0\n%s:\n",
         $3->code, $3->true_val, $1, end, $3->false_val, $1, end);

    } 
    | declaration { $$ = $1; }
    | IF_LOOP { $$ = $1; }
    | WHILE_LOOP { $$ = $1; }
    | BLOCK { $$ = $1; }
    ;

BLOCK:
     LEFT_PAREN { enterScope(); } stmts RIGHT_PAREN { $$ = $3; exitScope(); }
     ;

declaration:
        type id_list SEMICOLON {
            $$ = make_expr();

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

        }
        ;

type:
        INT   { strcpy(currentType, "int"); }
      | FLOAT { strcpy(currentType, "float"); }
      ;

id_list:
        ID  { 
            addSymbol($1, currentType);
        }
        | id_list COMMA ID   { 
            addSymbol($3, currentType);
        }
        ;

expr: expr ADD expr {
        $$ = make_expr();

        if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
        if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);
            
		char *temp = new_temp();
        sprintf($$->express, "%s", temp);
        sprintf($$->code, "%s%s%s = %s + %s\n%s:\n%s:\n", $1->code, $3->code, temp, $1->express, $3->express, $$->true_val, $$->false_val);


      }
      | expr SUBTRACT expr {
        $$ = make_expr();

        if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
        if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);
            
		char *temp = new_temp();
        sprintf($$->express, "%s", temp);
        sprintf($$->code, "%s%s%s = %s - %s\n%s:\n%s:\n", $1->code, $3->code, temp, $1->express, $3->express, $$->true_val, $$->false_val);

      }
      |expr MUL expr {
        $$ = make_expr();

        if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
        if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);
            
		char *temp = new_temp();
        sprintf($$->express, "%s", temp);
        sprintf($$->code, "%s%s%s = %s * %s\n%s:\n%s:\n", $1->code, $3->code, temp, $1->express, $3->express, $$->true_val, $$->false_val);

      }
      |expr DIV expr {
        $$ = make_expr();

        if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
        if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);
            
		char *temp = new_temp();
        sprintf($$->express, "%s", temp);
        sprintf($$->code, "%s%s%s = %s / %s\n%s:\n%s:\n", $1->code, $3->code, temp, $1->express, $3->express, $$->true_val, $$->false_val);

      }
      |expr REM expr {
        $$ = make_expr();

        if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
        if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);
            
		char *temp = new_temp();
        sprintf($$->express, "%s", temp);
        sprintf($$->code, "%s%s%s = %s %% %s\n%s:\n%s:\n", $1->code, $3->code, temp, $1->express, $3->express, $$->true_val, $$->false_val);

      }
      | LEFT_BRAC expr RIGHT_BRAC {
		$$ = $2;
      }
      | ID {
            $$ = make_expr();
            snprintf($$->express, 255, "%s", $1);

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

     }
     | NUM {
            $$ = make_expr();
            snprintf($$->express, 255, "%s", $1);

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

     }
     ;

bool_expr: expr GT expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s > %s goto %s\ngoto %s\n%s:\n%s:\n",
                $1->code, $3->code,
                $1->express, $3->express,
                $$->true_val, $$->false_val,
                $$->true_val, $$->false_val);

      }
      | expr GE expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s >= %s goto %s\ngoto %s\n%s:\n%s:\n",
                $1->code, $3->code,
                $1->express, $3->express,
                $$->true_val, $$->false_val,
                $$->true_val, $$->false_val);

      }
      | expr LT expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s < %s goto %s\ngoto %s\n%s:\n%s:\n",
                $1->code, $3->code,
                $1->express, $3->express,
                $$->true_val, $$->false_val,
                $$->true_val, $$->false_val);

      }
      | expr LE expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s <= %s goto %s\ngoto %s\n%s:\n%s:\n",
                 $1->code, $3->code,
                 $1->express, $3->express,
                 $$->true_val, $$->false_val,
                 $$->true_val, $$->false_val);

            
      }
      | expr EEQ expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s == %s goto %s\ngoto %s\n%s:\n%s:\n",
                 $1->code, $3->code,
                 $1->express, $3->express,
                 $$->true_val, $$->false_val,
                 $$->true_val, $$->false_val);

      }
      | expr NEQ expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s%sif %s != %s goto %s\ngoto %s\n%s:\n%s:\n",
                 $1->code, $3->code,
                 $1->express, $3->express,
                 $$->true_val, $$->false_val,
                 $$->true_val, $$->false_val);

      }
      | bool_expr AND bool_expr {
            $$ = make_expr();

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            if (!strlen($1->true_val)) strncpy($1->true_val, new_label(), 63);
            if (!strlen($1->false_val)) strncpy($1->false_val, $$->false_val, 63);

            if (!strlen($3->true_val)) strncpy($3->true_val, $$->true_val, 63);
            if (!strlen($3->false_val)) strncpy($3->false_val, $$->false_val, 63);

            snprintf($$->code, 1023,
                "%s"        
                "%s:\n"     
                "%s",
                $1->code, $1->true_val, $3->code);

     }
     | bool_expr OR bool_expr {
            $$ = make_expr();

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            if (!strlen($1->true_val)) strncpy($1->true_val, $$->true_val, 63);
            if (!strlen($1->false_val)) strncpy($1->false_val, new_label(), 63);

            if (!strlen($3->true_val)) strncpy($3->true_val, $$->true_val, 63);
            if (!strlen($3->false_val)) strncpy($3->false_val, $$->false_val, 63);

            snprintf($$->code, 1023,
                "%s"    
                "%s:\n" 
                "%s",
                $1->code, $1->false_val, $3->code);

     }
     | NOT bool_expr {
            $$ = make_expr();
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "%s", $2->code);
     }
     | TRUE {
            $$ = make_expr();

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "goto %s\n", $$->true_val);
     }
     | FALSE {
            $$ = make_expr();

            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code, 1023, "goto %s\n", $$->false_val);

     }
     | LEFT_BRAC bool_expr RIGHT_BRAC {
		$$ = $2;
    }
    | expr {
    
            $$ = make_expr();

            snprintf($$->code, 1023, "%s", $1->code);
            if (!strlen($$->true_val)) strncpy($$->true_val, new_label(), 63);
            if (!strlen($$->false_val)) strncpy($$->false_val, new_label(), 63);

            snprintf($$->code + strlen($$->code),  1023 - strlen($$->code),
                     "if %s != 0 goto %s\ngoto %s\n%s:\n%s:\n",
                     $1->express, $$->true_val, $$->false_val,
                     $$->true_val, $$->false_val);
     }
     ;

IF_LOOP:
    IF bool_expr THEN BLOCK {
            $$ = make_expr();

            if (!strlen($$->next)) strncpy($$->next, new_label(), 63);

            if (!strlen($2->true_val)) strncpy($2->true_val, new_label(), 63);
            if (!strlen($2->false_val)) strncpy($2->false_val, $$->next, 63);
            if (!strlen($4->next)) strncpy($4->next, $$->next, 63);

            snprintf($$->code, 1023, "%s%s:\n%s", $2->code, $2->true_val, $4->code);

   } 
   | IF bool_expr THEN BLOCK ELSE BLOCK {
            $$ = make_expr();

            if (!strlen($$->next)) strncpy($$->next, new_label(), 63);

            if (!strlen($2->true_val)) strncpy($2->true_val, new_label(), 63);
            if (!strlen($2->false_val)) strncpy($2->false_val, new_label(), 63);
            if (!strlen($4->next)) strncpy($4->next, $$->next, 63);
            if (!strlen($6->next)) strncpy($6->next, $$->next, 63);

            snprintf($$->code, 1023, "%s%s:\n%sgoto %s\n%s:\n%s%s:\n", 
                    $2->code, $2->true_val, $4->code, 
                    $$->next, $2->false_val, $6->code, $$->next);
    }
    ;

WHILE_LOOP:
     WHILE bool_expr DO BLOCK  {
            $$ = make_expr();

            if (!strlen($$->next)) strncpy($$->next, new_label(), 63);
            if (!strlen($$->begin)) strncpy($$->begin, new_label(), 63);

            if (!strlen($2->true_val)) strncpy($2->true_val, new_label(), 63);
            if (!strlen($2->false_val)) strncpy($2->false_val, $$->next, 63);
            if (!strlen($4->next)) strncpy($4->next, $$->begin, 63);

            snprintf($$->code, 1023, "%s:\n%s%s:\n%sgoto %s\n", 
                    $$->begin, $2->code, $2->true_val, 
                    $4->code, $$->begin);

     }
     ;

%%

int main(int argc, char* argv[]) {
    if (argc == 2){
        FILE* fp = fopen(argv[1],"r");
        if (!fp) {
            perror(argv[1]);
            return 1;
        }
        yyin = fp;
    }else{
        printf("\nEnter Any Arithmetic Expression\n");
        printf("For eg:\n");
        printf("int a, b, c;\n");
        printf("float d, e, f;\n");
        printf("a = b * c - d / f;\n");
        printf("k = e or f >= g and h != i and not j;\n");
        printf("if k >= g then {a = k - b/d * e; l = m > n and o <= p;}\n");
        printf("if o and not p <= q and l != m then {r = k/q - b*d - e + f*g; l = m > n and o <= p;} else {q = s-t/d*r; k = o and not p or q >= w;}\n");
        printf("while j < t and not o do {n = p-q; r = s and t; m = r and t or u >= n;}\n");
        printf("Now enter: ");
    }
    int result = yyparse();
    if (root) {
        printf("\nGenerated Three-Address Code:\n%s\n", root->code);
    }
    if (result == 0){
        printf("The above program is syntactically correct\n");
    }else{
        printf("The above program is syntactically not correct\n");
    }
    if (argc == 2){
        fclose(yyin);
    }
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}


