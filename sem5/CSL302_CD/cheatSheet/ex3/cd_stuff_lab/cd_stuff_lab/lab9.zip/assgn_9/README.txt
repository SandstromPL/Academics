Name: Agastya Nath
Roll No.: 12340140
Course: CSL302 – Compiler Design

Lab 9 Assignment:

I. Files included:
    1. symbol.c
    2. symbol.h
    3. ast.h (for definitions of exprStruct)
    4. analyzer.l (Lex/Flex analyzer)
    5. parser.y (Yacc/Bison parser)
    6. sample.txt (for demo)
    7. README.txt (this file; for further instructions and knowledge)

II. Instructions to generate the parser:
    1. Compile ./analyzer.l with lex as follows:
        lex ./analyzer.l
    2. Compile ./parser.y with yacc (with option -d) as follows:
        yacc -d ./parser.y
    3. Compile the resultant ./lex.yy.c and ./y.tab.c with gcc along with ./symbol.c as follows:
        gcc ./lex.yy.c ./y.tab.c ./symbol.c
    4. The resultant executable from gcc (./a.out) is the parser.

III. How to use:
    It can be used either interactively (i.e. without any commandline arguments) or with an argument (as source file name passed as argument).
    
    1. If used interactively, enter ./a.out. After that, Enter source code line-by-line until an error is detected (then it detects it with an error and exits). If you 
    want to manually exit the parser, just press Ctrl-C. 

    Unfortunately, This will not show the generated TAC code.

    2. If used with a source file, enter ./a.out file_name.txt (eg. ./a.out ./sample.txt). Then it prints all the lines of information and then
    at the end it tells you whether the code is syntactically correct or not.

    Only to use this method to show generated TAC code.

IV. Assumptions:
    1. Only int and float are supported.
    2. No function scopes implemented.
    3. TAC generation is printed directly; not stored.
    4. Memory for symbols freed only on scope exit.
    5. Scope management added as well.
    6. If, if-else and while loops handled well.
    7. Short-circuting is added.

V. Example:

Example file: ./sample.txt

int a, b, c;
float d, e, f;
a = b * c - d / f;
k = e or f >= g and h != i and not j;
if k >= g then {a = k - b/d * e; l = m > n and o <= p;}
if o and not p <= q and l != m then {r = k/q - b*d - e + f*g; l = m > n and o <= p;} else {q = s-t/d*r; k = o and not p or q >= w;}
while j < t and not o do {n = p-q; r = s and t; m = r and t or u >= n;}

Enter: ./a.out ./sample.txt

Output: 


Declared a of type int in scope 1
Declared b of type int in scope 1
Declared c of type int in scope 1
Declared d of type float in scope 1
Declared e of type float in scope 1
Declared f of type float in scope 1
Entered new scope 2
Exited scope
Entered new scope 3
Exited scope
Entered new scope 4
Exited scope
Entered new scope 5
Exited scope

Generated Three-Address Code:
t1 = d / f
L13:
L14:
t2 = c - t1
L15:
L16:
t3 = b * t2
L17:
L18:
a = t3
if e != 0 goto L21
goto L22
L21:
L22:
L22:
if f >= g goto L27
goto L28
L27:
L28:
L29:
if h != i goto L35
goto L36
L35:
L36:
L37:
if j != 0 goto L41
goto L42
L41:
L42:
L45:
k = 1
goto L47
L46:
k = 0
L47:
if k >= g goto L52
goto L53
L52:
L53:
L52:
t4 = d * e
L62:
L63:
t5 = b / t4
L64:
L65:
t6 = k - t5
L66:
L67:
a = t6
if m > n goto L72
goto L73
L72:
L73:
L72:
if o <= p goto L78
goto L79
L78:
L79:
L80:
l = 1
goto L82
L81:
l = 0
L82:
if o != 0 goto L86
goto L87
L86:
L87:
L86:
if p <= q goto L92
goto L93
L92:
L93:
L92:
if l != m goto L98
goto L99
L98:
L99:
L104:
t7 = f * g
L120:
L121:
t8 = e + t7
L122:
L123:
t9 = d - t8
L124:
L125:
t10 = b * t9
L126:
L127:
t11 = q - t10
L128:
L129:
t12 = k / t11
L130:
L131:
r = t12
if m > n goto L136
goto L137
L136:
L137:
L136:
if o <= p goto L142
goto L143
L142:
L143:
L144:
l = 1
goto L146
L145:
l = 0
L146:
goto L182
L105:
t13 = d * r
L155:
L156:
t14 = t / t13
L157:
L158:
t15 = s - t14
L159:
L160:
q = t15
i
The above program is syntactically correct
