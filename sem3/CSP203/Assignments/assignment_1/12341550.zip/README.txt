First save all the content of zip files by unzipping it in your deire location then do as mention below...

Q1
>>>
	This folder contains dir.txt file made as per demand of question. It also contains dir.sh file to execute it first u need to make it executable using chmod then
	execute it by "./dir.sh".
<<<

Q2
>>>
	This folder contain digit.sh file according to question , to execute it first we need to make it execuatable same as above and execute it by typing "./digit.sh"
<<<

Q3
>>>
	This folder contains Account.txt , Credential.txt files as per deamnd of question and it also contain bash file shellATM.sh to execute it do same as above and 
	type "./shellATM.sh".
<<<
