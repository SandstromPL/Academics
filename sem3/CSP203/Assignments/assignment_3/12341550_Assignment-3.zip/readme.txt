>>>This folder contain a source data file in source data folder and a ,b ,c ... i folder are respective question folder as per assignment.

>>>I have used chatgpt for question d for shell scripting part and also for pie chart questions though i solved it by manual data filtering and  not by shell scripting.

>>>All folders contain .csv file as previous provided.

>>>To execute it first open respective question in terminal then write command gnuplot <file_name.p> and here we are done , for Q d first we need to run .sh fileafter making it executable which will give filtered data then again use gnuplot filename to get desired output.

  
