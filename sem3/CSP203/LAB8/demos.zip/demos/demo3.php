<html>
	<head>
		<title> PHP Test </title>
	</head>
	<body>
		<?php 
			echo "Hello"; 
			// This is a comment 
			/* This is a multi line
			comment */
		?>
	</body>
</html>
	
