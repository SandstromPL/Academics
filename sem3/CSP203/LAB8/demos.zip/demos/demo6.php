<!DOCTYPE html>
<html>
<body>

<?php
$cars[0] = "Volvo";
$cars[1] = "BMW";
$cars[2] = "Toyota";
echo $cars[0].".".$cars[1];
?>

</body>
</html>

