<html>
	<head>
		<title> PHP Test </title>
	</head>
	<body>
		<?php 
			echo "Hello"; 
			print "<br>";
			echo "<b> I am here </b>";
			$txt1 = "CSP";
			$txt2 = "203";
			echo $txt1.$txt2;
		?>
	</body>
</html>
	
