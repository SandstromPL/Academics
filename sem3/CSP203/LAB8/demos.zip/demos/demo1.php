<html>
	<head>
		<title> PHP Test </title>
	</head>
	<body>
		<?php echo "<strong> Hello World </strong>"; ?>
	</body>
</html>
	
