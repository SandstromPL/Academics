<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>PROBLEM 1</title>
    </head>
    <body>
        <?php
            $user = "paritosh";
            $pass = "paritosh";
            if($user == $pass){
                echo "User Authentication is Successful";
            }else{
                echo "User Authentication is not Successful";
            }
        ?>
    </body>
</html>